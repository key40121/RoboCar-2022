﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;
using System.Net;


using Zmp.Rcz.Communication;
using MjpegProcessor;


namespace RczControl
{

    public partial class MjpgSampleForm : Form
    {
        /// <summary>
        /// Connect
        /// </summary>
        private connectConfig _config = new connectConfig();
        private RczCommunication _comm = new RczCommunication();

        MjpegDecoder m_jpegdecoder;

        public MjpgSampleForm()
        {
            InitializeComponent();

            //インスタンスを作成する
            m_jpegdecoder = new MjpegDecoder();
            //フレーム取得ハンドラを設定する
            m_jpegdecoder.FrameReady += FrameReady;
        }

        public void FrameReady(object sender, FrameReadyEventArgs e)
        {
            //取得した画像をimageに設定する
            pictureBox1.Image = e.Bitmap;
            string str = "Connect";
            toolStripStatusLabel1.Text = str;
        }

/*
 * Connect
 */
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_comm.IsConnect)
            {
                return;
            }
            serializeConfig(false);

            OpenDialog dlg = new OpenDialog();
            if (_config.HostName == null)
                dlg.HostName = "192.168.1.35";
            else
                dlg.HostName = _config.HostName;

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                m_jpegdecoder.ParseStream(new Uri("http://" + dlg.HostName + ":8080/?action=stream"));
                _config.HostName = dlg.HostName;
                serializeConfig(true);
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_comm.IsConnect)
            {
                _comm.Close();
            }
        }

        private void onReceived(object sender)
        {
            string str = "Connect. (Data recieveing.)";
            toolStripStatusLabel1.Text = str;
        }

        private void onOpenedorClosed(object sender, bool bOpened)
        {
            string str;
            if (bOpened)
            {
                str = "Connect.";
                toolStripStatusLabel1.Text = str;
            }
            else
            {
                str = "Disonnect.";
            }
        }

        private void serializeConfig(bool save)
        {
            try
            {
                string path = Application.StartupPath + @"\PortOpenDialog.config.xml";
                XmlSerializer serializer = new XmlSerializer(typeof(connectConfig));
                if (save)
                {
                    FileStream fs = new FileStream(path, FileMode.Create);
                    serializer.Serialize(fs, _config);
                    fs.Close();
                }
                else
                {
                    FileStream fs = new FileStream(path, FileMode.Open);
                    _config = (connectConfig)serializer.Deserialize(fs);
                    fs.Close();
                }
            }
            catch (Exception)
            {
                // Ignore any.
            }

        }
	}

    public class connectConfig
    {
        public connectConfig() { }
        public string HostName { get; set; }
    }
}
