﻿namespace RczControl
{
    partial class DirectXSampleForm
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.comboBox_drv_backward = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.comboBox_drv_forward = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.comboBox_motor_off = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.comboBox_motor_on = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox_brk_max = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.comboBox_brk = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox_acc_max = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.comboBox_accel = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox_str_max = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox_str_min = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBox_str = new System.Windows.Forms.ComboBox();
            this.textBox_xinput_buttons = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_xinput_ARx = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_xinput_ARy = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_xinput_ARz = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_xinput_FRx = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_xinput_FRy = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_xinput_FRz = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_xinput_AX = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox_xinput_AY = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox_xinput_AZ = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox_xinput_FX = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_xinput_FY = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_xinput_FZ = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox_xinput_Z = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox_xinput_Y = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox_xinput_X = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.textBox_xinput_VZ = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox_xinput_VY = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox_xinput_VX = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.textBox_xinput_VRz = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox_xinput_VRy = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.textBox_xinput_VRx = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox_xinput_Rz = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox_xinput_Ry = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox_xinput_Rx = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox_xinput_vslider = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox_xinput_fslider = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox_xinput_aslider = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox_xinput_slider = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox_xinput_povs = new System.Windows.Forms.TextBox();
            this.timer_directX = new System.Windows.Forms.Timer(this.components);
            this.button_save = new System.Windows.Forms.Button();
            this.label42 = new System.Windows.Forms.Label();
            this.textBox_acc_min = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.textBox_brk_min = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox2.Controls.Add(this.label43);
            this.groupBox2.Controls.Add(this.textBox_brk_min);
            this.groupBox2.Controls.Add(this.label42);
            this.groupBox2.Controls.Add(this.textBox_acc_min);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.comboBox_drv_backward);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.comboBox_drv_forward);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.comboBox_motor_off);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.comboBox_motor_on);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.textBox_brk_max);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.comboBox_brk);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.textBox_acc_max);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.comboBox_accel);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.textBox_str_max);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.textBox_str_min);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.comboBox_str);
            this.groupBox2.Location = new System.Drawing.Point(327, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(291, 284);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "config";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(15, 260);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(106, 12);
            this.label24.TabIndex = 60;
            this.label24.Text = "assing to Backward";
            // 
            // comboBox_drv_backward
            // 
            this.comboBox_drv_backward.FormattingEnabled = true;
            this.comboBox_drv_backward.Items.AddRange(new object[] {
            "00",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.comboBox_drv_backward.Location = new System.Drawing.Point(141, 257);
            this.comboBox_drv_backward.Name = "comboBox_drv_backward";
            this.comboBox_drv_backward.Size = new System.Drawing.Size(143, 20);
            this.comboBox_drv_backward.TabIndex = 59;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(15, 234);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(97, 12);
            this.label23.TabIndex = 58;
            this.label23.Text = "assing to Forward";
            // 
            // comboBox_drv_forward
            // 
            this.comboBox_drv_forward.FormattingEnabled = true;
            this.comboBox_drv_forward.Items.AddRange(new object[] {
            "00",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.comboBox_drv_forward.Location = new System.Drawing.Point(141, 231);
            this.comboBox_drv_forward.Name = "comboBox_drv_forward";
            this.comboBox_drv_forward.Size = new System.Drawing.Size(143, 20);
            this.comboBox_drv_forward.TabIndex = 57;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(14, 208);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(111, 12);
            this.label22.TabIndex = 56;
            this.label22.Text = "assing to Motor OFF";
            // 
            // comboBox_motor_off
            // 
            this.comboBox_motor_off.FormattingEnabled = true;
            this.comboBox_motor_off.Items.AddRange(new object[] {
            "00",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.comboBox_motor_off.Location = new System.Drawing.Point(140, 205);
            this.comboBox_motor_off.Name = "comboBox_motor_off";
            this.comboBox_motor_off.Size = new System.Drawing.Size(143, 20);
            this.comboBox_motor_off.TabIndex = 55;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(14, 182);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(105, 12);
            this.label21.TabIndex = 54;
            this.label21.Text = "assing to Motor ON";
            // 
            // comboBox_motor_on
            // 
            this.comboBox_motor_on.FormattingEnabled = true;
            this.comboBox_motor_on.Items.AddRange(new object[] {
            "00",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.comboBox_motor_on.Location = new System.Drawing.Point(140, 179);
            this.comboBox_motor_on.Name = "comboBox_motor_on";
            this.comboBox_motor_on.Size = new System.Drawing.Size(143, 20);
            this.comboBox_motor_on.TabIndex = 53;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(179, 155);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(26, 12);
            this.label19.TabIndex = 52;
            this.label19.Text = "Max";
            // 
            // textBox_brk_max
            // 
            this.textBox_brk_max.Location = new System.Drawing.Point(212, 152);
            this.textBox_brk_max.Name = "textBox_brk_max";
            this.textBox_brk_max.Size = new System.Drawing.Size(72, 19);
            this.textBox_brk_max.TabIndex = 51;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(15, 129);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(84, 12);
            this.label20.TabIndex = 50;
            this.label20.Text = "assing to brake";
            // 
            // comboBox_brk
            // 
            this.comboBox_brk.FormattingEnabled = true;
            this.comboBox_brk.Items.AddRange(new object[] {
            "X angular acc",
            "Y angular acc",
            "Z angular acc",
            "X acc",
            "Y acc",
            "Z acc",
            "X torque",
            "Y torque",
            "Z torque",
            "X force",
            "Y force",
            "Z force",
            "X rotation",
            "Y rotation",
            "Z rotation",
            "X veloc",
            "Y veloc",
            "Z veloc",
            "X angular veloc",
            "Y angular veloc",
            "Z anglsular veloc",
            "X axis",
            "Y axis",
            "Z axis"});
            this.comboBox_brk.Location = new System.Drawing.Point(120, 126);
            this.comboBox_brk.Name = "comboBox_brk";
            this.comboBox_brk.Size = new System.Drawing.Size(164, 20);
            this.comboBox_brk.TabIndex = 49;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(179, 103);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(26, 12);
            this.label18.TabIndex = 48;
            this.label18.Text = "Max";
            // 
            // textBox_acc_max
            // 
            this.textBox_acc_max.Location = new System.Drawing.Point(212, 100);
            this.textBox_acc_max.Name = "textBox_acc_max";
            this.textBox_acc_max.Size = new System.Drawing.Size(72, 19);
            this.textBox_acc_max.TabIndex = 47;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(15, 78);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(83, 12);
            this.label17.TabIndex = 46;
            this.label17.Text = "assing to accel";
            // 
            // comboBox_accel
            // 
            this.comboBox_accel.FormattingEnabled = true;
            this.comboBox_accel.Items.AddRange(new object[] {
            "X angular acc",
            "Y angular acc",
            "Z angular acc",
            "X acc",
            "Y acc",
            "Z acc",
            "X torque",
            "Y torque",
            "Z torque",
            "X force",
            "Y force",
            "Z force",
            "X rotation",
            "Y rotation",
            "Z rotation",
            "X veloc",
            "Y veloc",
            "Z veloc",
            "X angular veloc",
            "Y angular veloc",
            "Z anglsular veloc",
            "X axis",
            "Y axis",
            "Z axis"});
            this.comboBox_accel.Location = new System.Drawing.Point(120, 75);
            this.comboBox_accel.Name = "comboBox_accel";
            this.comboBox_accel.Size = new System.Drawing.Size(164, 20);
            this.comboBox_accel.TabIndex = 45;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(147, 49);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(61, 12);
            this.label16.TabIndex = 44;
            this.label16.Text = "Max(Right)";
            // 
            // textBox_str_max
            // 
            this.textBox_str_max.Location = new System.Drawing.Point(212, 46);
            this.textBox_str_max.Name = "textBox_str_max";
            this.textBox_str_max.Size = new System.Drawing.Size(72, 19);
            this.textBox_str_max.TabIndex = 43;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(15, 49);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(51, 12);
            this.label15.TabIndex = 42;
            this.label15.Text = "Min(Left)";
            // 
            // textBox_str_min
            // 
            this.textBox_str_min.Location = new System.Drawing.Point(69, 46);
            this.textBox_str_min.Name = "textBox_str_min";
            this.textBox_str_min.Size = new System.Drawing.Size(72, 19);
            this.textBox_str_min.TabIndex = 41;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(15, 21);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(97, 12);
            this.label14.TabIndex = 1;
            this.label14.Text = "assing to steering";
            // 
            // comboBox_str
            // 
            this.comboBox_str.FormattingEnabled = true;
            this.comboBox_str.Items.AddRange(new object[] {
            "X angular acc",
            "Y angular acc",
            "Z angular acc",
            "X acc",
            "Y acc",
            "Z acc",
            "X torque",
            "Y torque",
            "Z torque",
            "X force",
            "Y force",
            "Z force",
            "X rotation",
            "Y rotation",
            "Z rotation",
            "X veloc",
            "Y veloc",
            "Z veloc",
            "X angular veloc",
            "Y angular veloc",
            "Z anglsular veloc",
            "X axis",
            "Y axis",
            "Z axis"});
            this.comboBox_str.Location = new System.Drawing.Point(120, 17);
            this.comboBox_str.Name = "comboBox_str";
            this.comboBox_str.Size = new System.Drawing.Size(164, 20);
            this.comboBox_str.TabIndex = 0;
            // 
            // textBox_xinput_buttons
            // 
            this.textBox_xinput_buttons.Location = new System.Drawing.Point(82, 18);
            this.textBox_xinput_buttons.Name = "textBox_xinput_buttons";
            this.textBox_xinput_buttons.Size = new System.Drawing.Size(211, 19);
            this.textBox_xinput_buttons.TabIndex = 37;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 12);
            this.label1.TabIndex = 38;
            this.label1.Text = "buttons";
            // 
            // textBox_xinput_ARx
            // 
            this.textBox_xinput_ARx.Location = new System.Drawing.Point(89, 168);
            this.textBox_xinput_ARx.Name = "textBox_xinput_ARx";
            this.textBox_xinput_ARx.Size = new System.Drawing.Size(58, 19);
            this.textBox_xinput_ARx.TabIndex = 39;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 12);
            this.label2.TabIndex = 40;
            this.label2.Text = "X angular acc";
            // 
            // textBox_xinput_ARy
            // 
            this.textBox_xinput_ARy.Location = new System.Drawing.Point(89, 193);
            this.textBox_xinput_ARy.Name = "textBox_xinput_ARy";
            this.textBox_xinput_ARy.Size = new System.Drawing.Size(58, 19);
            this.textBox_xinput_ARy.TabIndex = 41;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 196);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label3.Size = new System.Drawing.Size(75, 12);
            this.label3.TabIndex = 42;
            this.label3.Text = "Y angular acc";
            // 
            // textBox_xinput_ARz
            // 
            this.textBox_xinput_ARz.Location = new System.Drawing.Point(89, 218);
            this.textBox_xinput_ARz.Name = "textBox_xinput_ARz";
            this.textBox_xinput_ARz.Size = new System.Drawing.Size(58, 19);
            this.textBox_xinput_ARz.TabIndex = 43;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 221);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label4.Size = new System.Drawing.Size(75, 12);
            this.label4.TabIndex = 44;
            this.label4.Text = "Z angular acc";
            // 
            // textBox_xinput_FRx
            // 
            this.textBox_xinput_FRx.Location = new System.Drawing.Point(89, 242);
            this.textBox_xinput_FRx.Name = "textBox_xinput_FRx";
            this.textBox_xinput_FRx.Size = new System.Drawing.Size(58, 19);
            this.textBox_xinput_FRx.TabIndex = 45;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 246);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 12);
            this.label7.TabIndex = 46;
            this.label7.Text = "X torque";
            // 
            // textBox_xinput_FRy
            // 
            this.textBox_xinput_FRy.Location = new System.Drawing.Point(89, 265);
            this.textBox_xinput_FRy.Name = "textBox_xinput_FRy";
            this.textBox_xinput_FRy.Size = new System.Drawing.Size(58, 19);
            this.textBox_xinput_FRy.TabIndex = 47;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 271);
            this.label6.Name = "label6";
            this.label6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label6.Size = new System.Drawing.Size(48, 12);
            this.label6.TabIndex = 48;
            this.label6.Text = "Y torque";
            // 
            // textBox_xinput_FRz
            // 
            this.textBox_xinput_FRz.Location = new System.Drawing.Point(89, 290);
            this.textBox_xinput_FRz.Name = "textBox_xinput_FRz";
            this.textBox_xinput_FRz.Size = new System.Drawing.Size(58, 19);
            this.textBox_xinput_FRz.TabIndex = 49;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 296);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label5.Size = new System.Drawing.Size(48, 12);
            this.label5.TabIndex = 50;
            this.label5.Text = "Z torque";
            // 
            // textBox_xinput_AX
            // 
            this.textBox_xinput_AX.Location = new System.Drawing.Point(225, 171);
            this.textBox_xinput_AX.Name = "textBox_xinput_AX";
            this.textBox_xinput_AX.Size = new System.Drawing.Size(72, 19);
            this.textBox_xinput_AX.TabIndex = 51;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(167, 174);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(34, 12);
            this.label13.TabIndex = 52;
            this.label13.Text = "X acc";
            // 
            // textBox_xinput_AY
            // 
            this.textBox_xinput_AY.Location = new System.Drawing.Point(225, 196);
            this.textBox_xinput_AY.Name = "textBox_xinput_AY";
            this.textBox_xinput_AY.Size = new System.Drawing.Size(72, 19);
            this.textBox_xinput_AY.TabIndex = 53;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(167, 199);
            this.label12.Name = "label12";
            this.label12.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label12.Size = new System.Drawing.Size(34, 12);
            this.label12.TabIndex = 54;
            this.label12.Text = "Y acc";
            // 
            // textBox_xinput_AZ
            // 
            this.textBox_xinput_AZ.Location = new System.Drawing.Point(225, 221);
            this.textBox_xinput_AZ.Name = "textBox_xinput_AZ";
            this.textBox_xinput_AZ.Size = new System.Drawing.Size(72, 19);
            this.textBox_xinput_AZ.TabIndex = 55;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(167, 224);
            this.label11.Name = "label11";
            this.label11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label11.Size = new System.Drawing.Size(34, 12);
            this.label11.TabIndex = 56;
            this.label11.Text = "Z acc";
            // 
            // textBox_xinput_FX
            // 
            this.textBox_xinput_FX.Location = new System.Drawing.Point(225, 246);
            this.textBox_xinput_FX.Name = "textBox_xinput_FX";
            this.textBox_xinput_FX.Size = new System.Drawing.Size(72, 19);
            this.textBox_xinput_FX.TabIndex = 57;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(167, 249);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 12);
            this.label10.TabIndex = 58;
            this.label10.Text = "X force";
            // 
            // textBox_xinput_FY
            // 
            this.textBox_xinput_FY.Location = new System.Drawing.Point(225, 271);
            this.textBox_xinput_FY.Name = "textBox_xinput_FY";
            this.textBox_xinput_FY.Size = new System.Drawing.Size(72, 19);
            this.textBox_xinput_FY.TabIndex = 59;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(167, 274);
            this.label9.Name = "label9";
            this.label9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label9.Size = new System.Drawing.Size(42, 12);
            this.label9.TabIndex = 60;
            this.label9.Text = "Y force";
            // 
            // textBox_xinput_FZ
            // 
            this.textBox_xinput_FZ.Location = new System.Drawing.Point(225, 296);
            this.textBox_xinput_FZ.Name = "textBox_xinput_FZ";
            this.textBox_xinput_FZ.Size = new System.Drawing.Size(72, 19);
            this.textBox_xinput_FZ.TabIndex = 61;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(167, 299);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label8.Size = new System.Drawing.Size(42, 12);
            this.label8.TabIndex = 62;
            this.label8.Text = "Z force";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox1.Controls.Add(this.label39);
            this.groupBox1.Controls.Add(this.textBox_xinput_Z);
            this.groupBox1.Controls.Add(this.label40);
            this.groupBox1.Controls.Add(this.textBox_xinput_Y);
            this.groupBox1.Controls.Add(this.label41);
            this.groupBox1.Controls.Add(this.textBox_xinput_X);
            this.groupBox1.Controls.Add(this.label36);
            this.groupBox1.Controls.Add(this.textBox_xinput_VZ);
            this.groupBox1.Controls.Add(this.label37);
            this.groupBox1.Controls.Add(this.textBox_xinput_VY);
            this.groupBox1.Controls.Add(this.label38);
            this.groupBox1.Controls.Add(this.textBox_xinput_VX);
            this.groupBox1.Controls.Add(this.label33);
            this.groupBox1.Controls.Add(this.textBox_xinput_VRz);
            this.groupBox1.Controls.Add(this.label34);
            this.groupBox1.Controls.Add(this.textBox_xinput_VRy);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Controls.Add(this.textBox_xinput_VRx);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.textBox_xinput_Rz);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.textBox_xinput_Ry);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.textBox_xinput_Rx);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.textBox_xinput_vslider);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.textBox_xinput_fslider);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.textBox_xinput_aslider);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.textBox_xinput_slider);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.textBox_xinput_povs);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.textBox_xinput_FZ);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.textBox_xinput_FY);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.textBox_xinput_FX);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.textBox_xinput_AZ);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.textBox_xinput_AY);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.textBox_xinput_AX);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.textBox_xinput_FRz);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.textBox_xinput_FRy);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.textBox_xinput_FRx);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBox_xinput_ARz);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.textBox_xinput_ARy);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBox_xinput_ARx);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBox_xinput_buttons);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(306, 467);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Input";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(167, 445);
            this.label39.Name = "label39";
            this.label39.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label39.Size = new System.Drawing.Size(37, 12);
            this.label39.TabIndex = 96;
            this.label39.Text = "Z axis";
            // 
            // textBox_xinput_Z
            // 
            this.textBox_xinput_Z.Location = new System.Drawing.Point(225, 442);
            this.textBox_xinput_Z.Name = "textBox_xinput_Z";
            this.textBox_xinput_Z.Size = new System.Drawing.Size(72, 19);
            this.textBox_xinput_Z.TabIndex = 95;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(167, 420);
            this.label40.Name = "label40";
            this.label40.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label40.Size = new System.Drawing.Size(37, 12);
            this.label40.TabIndex = 94;
            this.label40.Text = "Y axis";
            // 
            // textBox_xinput_Y
            // 
            this.textBox_xinput_Y.Location = new System.Drawing.Point(225, 417);
            this.textBox_xinput_Y.Name = "textBox_xinput_Y";
            this.textBox_xinput_Y.Size = new System.Drawing.Size(72, 19);
            this.textBox_xinput_Y.TabIndex = 93;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(167, 395);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(37, 12);
            this.label41.TabIndex = 92;
            this.label41.Text = "X axis";
            // 
            // textBox_xinput_X
            // 
            this.textBox_xinput_X.Location = new System.Drawing.Point(225, 392);
            this.textBox_xinput_X.Name = "textBox_xinput_X";
            this.textBox_xinput_X.Size = new System.Drawing.Size(72, 19);
            this.textBox_xinput_X.TabIndex = 91;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(167, 372);
            this.label36.Name = "label36";
            this.label36.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label36.Size = new System.Drawing.Size(43, 12);
            this.label36.TabIndex = 90;
            this.label36.Text = "Z veloc";
            // 
            // textBox_xinput_VZ
            // 
            this.textBox_xinput_VZ.Location = new System.Drawing.Point(225, 369);
            this.textBox_xinput_VZ.Name = "textBox_xinput_VZ";
            this.textBox_xinput_VZ.Size = new System.Drawing.Size(72, 19);
            this.textBox_xinput_VZ.TabIndex = 89;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(167, 347);
            this.label37.Name = "label37";
            this.label37.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label37.Size = new System.Drawing.Size(43, 12);
            this.label37.TabIndex = 88;
            this.label37.Text = "Y veloc";
            // 
            // textBox_xinput_VY
            // 
            this.textBox_xinput_VY.Location = new System.Drawing.Point(225, 344);
            this.textBox_xinput_VY.Name = "textBox_xinput_VY";
            this.textBox_xinput_VY.Size = new System.Drawing.Size(72, 19);
            this.textBox_xinput_VY.TabIndex = 87;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(167, 322);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(43, 12);
            this.label38.TabIndex = 86;
            this.label38.Text = "X veloc";
            // 
            // textBox_xinput_VX
            // 
            this.textBox_xinput_VX.Location = new System.Drawing.Point(225, 319);
            this.textBox_xinput_VX.Name = "textBox_xinput_VX";
            this.textBox_xinput_VX.Size = new System.Drawing.Size(72, 19);
            this.textBox_xinput_VX.TabIndex = 85;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(7, 442);
            this.label33.Name = "label33";
            this.label33.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label33.Size = new System.Drawing.Size(84, 12);
            this.label33.TabIndex = 84;
            this.label33.Text = "Z angular veloc";
            // 
            // textBox_xinput_VRz
            // 
            this.textBox_xinput_VRz.Location = new System.Drawing.Point(92, 439);
            this.textBox_xinput_VRz.Name = "textBox_xinput_VRz";
            this.textBox_xinput_VRz.Size = new System.Drawing.Size(58, 19);
            this.textBox_xinput_VRz.TabIndex = 83;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(7, 417);
            this.label34.Name = "label34";
            this.label34.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label34.Size = new System.Drawing.Size(84, 12);
            this.label34.TabIndex = 82;
            this.label34.Text = "Y angular veloc";
            // 
            // textBox_xinput_VRy
            // 
            this.textBox_xinput_VRy.Location = new System.Drawing.Point(92, 414);
            this.textBox_xinput_VRy.Name = "textBox_xinput_VRy";
            this.textBox_xinput_VRy.Size = new System.Drawing.Size(58, 19);
            this.textBox_xinput_VRy.TabIndex = 81;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(7, 392);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(84, 12);
            this.label35.TabIndex = 80;
            this.label35.Text = "X angular veloc";
            // 
            // textBox_xinput_VRx
            // 
            this.textBox_xinput_VRx.Location = new System.Drawing.Point(92, 389);
            this.textBox_xinput_VRx.Name = "textBox_xinput_VRx";
            this.textBox_xinput_VRx.Size = new System.Drawing.Size(58, 19);
            this.textBox_xinput_VRx.TabIndex = 79;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(10, 369);
            this.label30.Name = "label30";
            this.label30.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label30.Size = new System.Drawing.Size(55, 12);
            this.label30.TabIndex = 78;
            this.label30.Text = "Z rotation";
            // 
            // textBox_xinput_Rz
            // 
            this.textBox_xinput_Rz.Location = new System.Drawing.Point(89, 363);
            this.textBox_xinput_Rz.Name = "textBox_xinput_Rz";
            this.textBox_xinput_Rz.Size = new System.Drawing.Size(58, 19);
            this.textBox_xinput_Rz.TabIndex = 77;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(10, 344);
            this.label31.Name = "label31";
            this.label31.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label31.Size = new System.Drawing.Size(55, 12);
            this.label31.TabIndex = 76;
            this.label31.Text = "Y rotation";
            // 
            // textBox_xinput_Ry
            // 
            this.textBox_xinput_Ry.Location = new System.Drawing.Point(89, 338);
            this.textBox_xinput_Ry.Name = "textBox_xinput_Ry";
            this.textBox_xinput_Ry.Size = new System.Drawing.Size(58, 19);
            this.textBox_xinput_Ry.TabIndex = 75;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(10, 319);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(55, 12);
            this.label32.TabIndex = 74;
            this.label32.Text = "X rotation";
            // 
            // textBox_xinput_Rx
            // 
            this.textBox_xinput_Rx.Location = new System.Drawing.Point(89, 315);
            this.textBox_xinput_Rx.Name = "textBox_xinput_Rx";
            this.textBox_xinput_Rx.Size = new System.Drawing.Size(58, 19);
            this.textBox_xinput_Rx.TabIndex = 73;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(6, 145);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(51, 12);
            this.label29.TabIndex = 72;
            this.label29.Text = "V sliders";
            // 
            // textBox_xinput_vslider
            // 
            this.textBox_xinput_vslider.Location = new System.Drawing.Point(82, 142);
            this.textBox_xinput_vslider.Name = "textBox_xinput_vslider";
            this.textBox_xinput_vslider.Size = new System.Drawing.Size(211, 19);
            this.textBox_xinput_vslider.TabIndex = 71;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(6, 120);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(50, 12);
            this.label28.TabIndex = 70;
            this.label28.Text = "F sliders";
            // 
            // textBox_xinput_fslider
            // 
            this.textBox_xinput_fslider.Location = new System.Drawing.Point(82, 117);
            this.textBox_xinput_fslider.Name = "textBox_xinput_fslider";
            this.textBox_xinput_fslider.Size = new System.Drawing.Size(211, 19);
            this.textBox_xinput_fslider.TabIndex = 69;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(6, 95);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(51, 12);
            this.label27.TabIndex = 68;
            this.label27.Text = "A sliders";
            // 
            // textBox_xinput_aslider
            // 
            this.textBox_xinput_aslider.Location = new System.Drawing.Point(82, 92);
            this.textBox_xinput_aslider.Name = "textBox_xinput_aslider";
            this.textBox_xinput_aslider.Size = new System.Drawing.Size(211, 19);
            this.textBox_xinput_aslider.TabIndex = 67;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(6, 70);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(39, 12);
            this.label26.TabIndex = 66;
            this.label26.Text = "sliders";
            // 
            // textBox_xinput_slider
            // 
            this.textBox_xinput_slider.Location = new System.Drawing.Point(82, 67);
            this.textBox_xinput_slider.Name = "textBox_xinput_slider";
            this.textBox_xinput_slider.Size = new System.Drawing.Size(211, 19);
            this.textBox_xinput_slider.TabIndex = 65;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 45);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(77, 12);
            this.label25.TabIndex = 64;
            this.label25.Text = "point of views";
            // 
            // textBox_xinput_povs
            // 
            this.textBox_xinput_povs.Location = new System.Drawing.Point(82, 42);
            this.textBox_xinput_povs.Name = "textBox_xinput_povs";
            this.textBox_xinput_povs.Size = new System.Drawing.Size(211, 19);
            this.textBox_xinput_povs.TabIndex = 63;
            // 
            // timer_directX
            // 
            this.timer_directX.Interval = 30;
            this.timer_directX.Tick += new System.EventHandler(this.timer_directX_Tick);
            // 
            // button_save
            // 
            this.button_save.Location = new System.Drawing.Point(539, 306);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(75, 23);
            this.button_save.TabIndex = 40;
            this.button_save.Text = "saveSetting";
            this.button_save.UseVisualStyleBackColor = true;
            this.button_save.Click += new System.EventHandler(this.button_save_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(36, 104);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(23, 12);
            this.label42.TabIndex = 62;
            this.label42.Text = "Min";
            // 
            // textBox_acc_min
            // 
            this.textBox_acc_min.Location = new System.Drawing.Point(69, 101);
            this.textBox_acc_min.Name = "textBox_acc_min";
            this.textBox_acc_min.Size = new System.Drawing.Size(72, 19);
            this.textBox_acc_min.TabIndex = 61;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(36, 155);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(23, 12);
            this.label43.TabIndex = 64;
            this.label43.Text = "Min";
            // 
            // textBox_brk_min
            // 
            this.textBox_brk_min.Location = new System.Drawing.Point(69, 152);
            this.textBox_brk_min.Name = "textBox_brk_min";
            this.textBox_brk_min.Size = new System.Drawing.Size(72, 19);
            this.textBox_brk_min.TabIndex = 63;
            // 
            // DirectXSampleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(630, 486);
            this.Controls.Add(this.button_save);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "DirectXSampleForm";
            this.Text = "DirectXSample";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboBox_str;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox_str_max;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox_str_min;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox comboBox_drv_backward;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox comboBox_drv_forward;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox comboBox_motor_off;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox comboBox_motor_on;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox_brk_max;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox comboBox_brk;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox_acc_max;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox comboBox_accel;
        private System.Windows.Forms.TextBox textBox_xinput_buttons;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_xinput_ARx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_xinput_ARy;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_xinput_ARz;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_xinput_FRx;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_xinput_FRy;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_xinput_FRz;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_xinput_AX;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox_xinput_AY;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox_xinput_AZ;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox_xinput_FX;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_xinput_FY;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_xinput_FZ;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox_xinput_Z;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox_xinput_Y;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox_xinput_X;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox textBox_xinput_VZ;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBox_xinput_VY;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox_xinput_VX;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBox_xinput_VRz;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox_xinput_VRy;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBox_xinput_VRx;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox_xinput_Rz;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox_xinput_Ry;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox_xinput_Rx;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox_xinput_vslider;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox_xinput_fslider;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox_xinput_aslider;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox_xinput_slider;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox_xinput_povs;
        private System.Windows.Forms.Timer timer_directX;
        private System.Windows.Forms.Button button_save;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox textBox_brk_min;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox textBox_acc_min;
    }
}

