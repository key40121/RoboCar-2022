﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;

using System.IO;
using Zmp.Rcz.Communication;
using Microsoft.DirectX.DirectInput;



namespace RczControl
{

    public partial class DirectXSampleForm : Form
    {

        Device _wheelCnt = null;
        private controlSetting _setting = new controlSetting();

        public DirectXSampleForm()
        {
            InitializeComponent();
            readSetting();
            directXInitial();
        }

        private void readSetting()
        {
            serializeSetting(false);
            comboBox_accel.SelectedIndex = _setting.acc_assing;
            comboBox_brk.SelectedIndex = _setting.brk_assing;
            comboBox_drv_backward.SelectedIndex = _setting.bwd_assing;
            comboBox_drv_forward.SelectedIndex = _setting.fwd_assing;
            comboBox_motor_off.SelectedIndex = _setting.mtrOff_assing;
            comboBox_motor_on.SelectedIndex = _setting.mtrOn_assing;
            comboBox_str.SelectedIndex = _setting.str_assing;
            textBox_acc_max.Text = _setting.acc_max.ToString();
            textBox_acc_min.Text = _setting.acc_min.ToString();
            textBox_brk_max.Text = _setting.brk_max.ToString();
            textBox_brk_min.Text = _setting.brk_min.ToString();
            textBox_str_max.Text = _setting.str_max.ToString();
            textBox_str_min.Text = _setting.str_min.ToString();
        }

        private void directXInitial()
        {
            DeviceList devList;

            devList = Manager.GetDevices(DeviceType.Driving, EnumDevicesFlags.AllDevices);

            foreach (DeviceInstance dev in devList)
            {
                _wheelCnt = new Device(dev.InstanceGuid);
                _wheelCnt.SetCooperativeLevel(this, CooperativeLevelFlags.Background | CooperativeLevelFlags.NonExclusive);
                break;
            }
            if (_wheelCnt == null)
                return;
            _wheelCnt.SetDataFormat(DeviceDataFormat.Joystick);

            _wheelCnt.Acquire();
            timer_directX.Start();

        }

        private void timer_directX_Tick(object sender, EventArgs e)
        {
            if (_wheelCnt == null)
            {
                return;
            }
            try
            {
                _wheelCnt.Poll();
                JoystickState state = _wheelCnt.CurrentJoystickState;
                textBox_xinput_ARx.Text = state.ARx.ToString();
                textBox_xinput_ARy.Text = state.ARy.ToString();
                textBox_xinput_ARz.Text = state.ARz.ToString();
                textBox_xinput_AX.Text = state.AX.ToString();
                textBox_xinput_AY.Text = state.AY.ToString();
                textBox_xinput_AZ.Text = state.AZ.ToString();
                textBox_xinput_FRx.Text = state.FRx.ToString();
                textBox_xinput_FRy.Text = state.FRy.ToString();
                textBox_xinput_FRz.Text = state.FRz.ToString();
                textBox_xinput_FX.Text = state.FX.ToString();
                textBox_xinput_FY.Text = state.FY.ToString();
                textBox_xinput_FZ.Text = state.FZ.ToString();
                textBox_xinput_Rx.Text = state.Rx.ToString();
                textBox_xinput_Ry.Text = state.Ry.ToString();
                textBox_xinput_Rz.Text = state.Rz.ToString();
                textBox_xinput_VRx.Text = state.VRx.ToString();
                textBox_xinput_VRy.Text = state.VRy.ToString();
                textBox_xinput_VRz.Text = state.VRz.ToString();
                textBox_xinput_VX.Text = state.VX.ToString();
                textBox_xinput_VY.Text = state.VY.ToString();
                textBox_xinput_VZ.Text = state.VZ.ToString();
                textBox_xinput_X.Text = state.X.ToString();
                textBox_xinput_Y.Text = state.Y.ToString();
                textBox_xinput_Z.Text = state.Z.ToString();

                string buttonStr = "";
                int count = 0;
                foreach (byte button in state.GetButtons())
                {
                    if (button != 0)
                    {
                        buttonStr += count.ToString("D2");
                        buttonStr += ", ";
                    }
                    count += 1;
                }
                textBox_xinput_buttons.Text = buttonStr;

                string povStr = "";
                foreach (int pov in state.GetPointOfView())
                {
                    if (pov != -1)
                    {
                        povStr += pov.ToString();
                        povStr += ", ";
                    }
                }
                textBox_xinput_povs.Text = povStr;

                string sliderStr = "";
                foreach (int slider in state.GetSlider())
                {
                    sliderStr += slider.ToString();
                    sliderStr += ", ";
                }
                textBox_xinput_slider.Text = sliderStr;

                string asliderStr = "";
                foreach (int aSlider in state.GetASlider())
                {
                    asliderStr += aSlider.ToString();
                    asliderStr += ", ";
                }
                textBox_xinput_aslider.Text = asliderStr;

                string fSliderStr = "";
                foreach (int fSlider in state.GetFSlider())
                {
                    fSliderStr += fSlider.ToString();
                    fSliderStr += ", ";
                }
                textBox_xinput_fslider.Text = fSliderStr;

                string vsliderStr = "";
                foreach (int vSlider in state.GetVSlider())
                {
                    vsliderStr += vSlider.ToString();
                    vsliderStr += ", ";
                }
                textBox_xinput_vslider.Text = vsliderStr;

            }
            catch (Exception) { }
        }

        private void serializeSetting(bool save)
        {
            try
            {
                string path = Application.StartupPath + @"\contSetting.xml";
                XmlSerializer serializer = new XmlSerializer(typeof(controlSetting));
                if (save)
                {
                    FileStream fs = new FileStream(path, FileMode.Create);
                    serializer.Serialize(fs, _setting);
                    fs.Close();
                }
                else
                {
                    FileStream fs = new FileStream(path, FileMode.Open);
                    _setting = (controlSetting)serializer.Deserialize(fs);
                    fs.Close();
                }
            }
            catch (Exception)
            {
                // Ignore any.
            }

        }

        private void button_save_Click(object sender, EventArgs e)
        {
            _setting.acc_assing = comboBox_accel.SelectedIndex;
            _setting.acc_min = int.Parse(textBox_acc_min.Text);
            _setting.acc_max = int.Parse(textBox_acc_max.Text);
            _setting.brk_assing = comboBox_brk.SelectedIndex;
            _setting.brk_min = int.Parse(textBox_brk_min.Text);
            _setting.brk_max = int.Parse(textBox_brk_max.Text);
            _setting.bwd_assing = comboBox_drv_backward.SelectedIndex;
            _setting.fwd_assing = comboBox_drv_forward.SelectedIndex;
            _setting.mtrOff_assing = comboBox_motor_off.SelectedIndex;
            _setting.mtrOn_assing = comboBox_motor_on.SelectedIndex;
            _setting.str_assing = comboBox_str.SelectedIndex;
            _setting.str_max = int.Parse(textBox_str_max.Text);
            _setting.str_min = int.Parse(textBox_str_min.Text);
            serializeSetting(true);
        }
    }

    public class controlSetting
    {
        public controlSetting() { }
        public int str_assing { get; set; }
        public int str_min { get; set; }
        public int str_max { get; set; }
        public int acc_assing { get; set; }
        public int acc_min { get; set; }
        public int acc_max { get; set; }
        public int brk_assing { get; set; }
        public int brk_min { get; set; }
        public int brk_max { get; set; }
        public int mtrOn_assing { get; set; }
        public int mtrOff_assing { get; set; }
        public int fwd_assing { get; set; }
        public int bwd_assing { get; set; }
    }

}
