﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RczControl
{
	public partial class OpenDialog : Form
	{
		public OpenDialog()
		{
			InitializeComponent();
		}

		public string HostName
		{
			get { return textBoxHostName.Text; }
			set { textBoxHostName.Text = value; }
		}

		private void buttonOK_Click(object sender, EventArgs e)
		{
			DialogResult = DialogResult.OK;
		}
	}
}
