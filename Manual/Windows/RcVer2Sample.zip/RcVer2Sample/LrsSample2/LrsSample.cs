﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;

using System.IO;
using Zmp.Rcz.Communication;

namespace RczControl
{

    public partial class LrsSampleForm : Form
    {
        /// <summary>
        /// Connect
        /// </summary>
        private connectConfig _config = new connectConfig();
        private RczCommunication _comm = new RczCommunication();

        /// <summary>
        /// config tab
        /// </summary>
//        ConfigTable _readConfTable;
        int _readConfLen;
        bool _readConfAll;

        public LrsSampleForm()
        {
            InitializeComponent();
//            textBox_drv_speed.Text = "0";

            writeLine();
            writeLine2();
            _readConfLen = 0;
            _readConfAll = false;
        }

        private void writeLine()
        {
            Bitmap canvas = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            Graphics g = Graphics.FromImage(canvas);

            Pen p = new Pen(Color.Black, 1);
            for (int i = 1; i < pictureBox1.Width / 50; i++)
            {
                g.DrawLine(p, 50*i, 0, 50*i, 250);
            }

            for (int i = 1; i < pictureBox1.Height / 50; i++)
            {
                g.DrawLine(p, 0, 50 * i, 500, 50 * i);
            }

            p.Color = Color.GreenYellow;

            g.DrawPie(p, 50, 0, 400, 400, 30, -240);
            p.Dispose();
            g.Dispose();
            pictureBox1.Image = canvas;
        }

        private void writeLine2()
        {
            Bitmap canvas = new Bitmap(pictureBox2.Width, pictureBox2.Height);
            Graphics g = Graphics.FromImage(canvas);

            Pen p = new Pen(Color.Black, 1);
            for (int i = 1; i < pictureBox2.Width / 50; i++)
            {
                g.DrawLine(p, 50 * i, 0, 50 * i, 250);
            }

            for (int i = 1; i < pictureBox2.Height / 50; i++)
            {
                g.DrawLine(p, 0, 50 * i, 500, 50 * i);
            }

            p.Color = Color.GreenYellow;

            g.DrawPie(p,50, -150, 400, 400, -30, 240);
            p.Dispose();
            g.Dispose();
            pictureBox2.Image = canvas;
        }

        private void onReceived(object sender, RczMsg msg)
        {
            try
            {
                switch ((RCZHMSG_ID)msg.id)
                {
//                    case RCZHMSG_ID.RCZHMSG_ID_GET_SENSOR_INFO_RES:
//                        ParseSensorInf(msg);
//                        break;
                    case RCZHMSG_ID.RCZHMSG_ID_GET_LRS_INFO_RES:
                        ParseLrsInf(msg);
                        break;
                    default: break;
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }


/*
 * Connect
 */
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_comm.IsConnect)
            {
                return;
            }
            serializeConfig(false);

            OpenDialog dlg = new OpenDialog();
            if (_config.HostName == null)
                dlg.HostName = "192.168.1.35";
            else
                dlg.HostName = _config.HostName;

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                _config.HostName = dlg.HostName;
                serializeConfig(true);

                if (dlg.HostName == "")
                {
                    return;
                }
                else if (dlg.HostName.IndexOf("COM") == 0)
                {
                    _comm = new RczCommunication();
                    _comm.HostName = dlg.HostName;
                }
                else if (dlg.HostName.IndexOf("Vector") != -1 || dlg.HostName.IndexOf("Case") != -1 || dlg.HostName.IndexOf("XL") != -1)
                {
                    _comm = new RczCommunication();
                }
                else if (dlg.HostName.IndexOf(".") != -1)
                {
                    _comm = new RczCommunication();
                    _comm.PortNo = 9292;
                    _comm.HostName = string.Format("{0}", dlg.HostName);
                }
                _comm.Received += onReceived;
                _comm.OpenedOrClosed += onOpenedorClosed;
                if (_comm.Open())
                {
                }
                else
                {
                    MessageBox.Show("Can not open.");
                }
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_comm.IsConnect)
            {
                _comm.Close();
            }
        }

        private void onReceived(object sender)
        {
            string str = "Connect. (Data recieveing.)";
            toolStripStatusLabel1.Text = str;
        }

        private void onOpenedorClosed(object sender, bool bOpened)
        {
            string str;
            if (bOpened)
            {
                str = "Connect.";
                toolStripStatusLabel1.Text = str;
            }
            else
            {
                str = "Disonnect.";
            }
        }

        private void serializeConfig(bool save)
        {
            try
            {
                string path = Application.StartupPath + @"\PortOpenDialog.config.xml";
                XmlSerializer serializer = new XmlSerializer(typeof(connectConfig));
                if (save)
                {
                    FileStream fs = new FileStream(path, FileMode.Create);
                    serializer.Serialize(fs, _config);
                    fs.Close();
                }
                else
                {
                    FileStream fs = new FileStream(path, FileMode.Open);
                    _config = (connectConfig)serializer.Deserialize(fs);
                    fs.Close();
                }
            }
            catch (Exception)
            {
                // Ignore any.
            }

        }

/* drive control */
        private void button_drv_on_Click(object sender, EventArgs e)
        {
            _comm.Send(RczPacket.SetDriveMotor(1));
        }

        private void button_drv_off_Click(object sender, EventArgs e)
        {
            _comm.Send(RczPacket.SetDriveMotor(0));
        }

        private void button_drv_setZero_Click(object sender, EventArgs e)
        {
            _comm.Send(RczPacket.SetDriveVelocity(0));
//            trackBar_drv_speed.Value = 0;
//            textBox_drv_speed.Text = "0";
        }

        private void button_drv_setSpeed_Click(object sender, EventArgs e)
        {
/*            if (textBox_drv_speed.Text == "")
                return;
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox_drv_speed.Text, @"([^-0123456789.])"))
                return;
            if (textBox_drv_speed.Text.IndexOf("-") > 0)
                return;
            int speed = int.Parse(textBox_drv_speed.Text);
            _comm.Send(RczPacket.SetDriveVelocity(speed));
            trackBar_drv_speed.Value = speed;
 * */
        }

        private void trackBar_drv_speed_Scroll(object sender, EventArgs e)
        {
/*            int speed = trackBar_drv_speed.Value;
            _comm.Send(RczPacket.SetDriveVelocity(speed));
            textBox_drv_speed.Text = speed.ToString();
 * */
        }


/* parse */
        private void ParseSensorInf(RczMsg msg)
        {
/*            RcvSensorInf sensor;
            _comm.ParseSensorInf(msg, out sensor);
            Invoke((MethodInvoker)delegate
            {
                textBox_drv_encoderM.Text = sensor.motor_enc.ToString("f2");
                textBox_drv_encoderFL.Text = sensor.wheel_enc1.ToString("f2");
                textBox_drv_encoderFR.Text = sensor.wheel_enc2.ToString("f2");
                textBox_drv_encoderRL.Text = sensor.wheel_enc3.ToString("f2");
                textBox_drv_encoderRR.Text = sensor.wheel_enc4.ToString("f2");
            });
            */
        }

        private void ParseLrsInf(RczMsg msg)
        {
            LRSResult lrs;
            _comm.ParseLrsInf(msg, out lrs);
            if (lrs.dev == 1)
            {
                if (checkBox1.Checked == false)
                    writeData(lrs);
                else
                    writeData2(lrs);
            }
            else
            {
                if (checkBox1.Checked == false)
                    writeData2(lrs);
                else
                    writeData(lrs);
            }

        }

        private void writeData(LRSResult lrs)
        {
            Bitmap canvas = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            Graphics g = Graphics.FromImage(canvas);
            int rcvCnt = lrs.rcvCnt;

            Pen p = new Pen(Color.Black, 1);
            for (int i = 1; i < pictureBox1.Width / 50; i++)
            {
                g.DrawLine(p, 50 * i, 0, 50 * i, 250);
            }

            for (int i = 1; i < pictureBox1.Height / 50; i++)
            {
                g.DrawLine(p, 0, 50 * i, 500, 50 * i);
            }

            p.Color = Color.GreenYellow;

            g.DrawPie(p, 50, 0, 400, 400, 30, -240);

            p.Color = Color.Red;
            float tmp = 0;
            for (int i = 1; i < lrs.data_length; i++)
            {
                g.DrawLine(p, 250, 200,
                    (int)(250 + (lrs.data[i] * Math.Cos(((210.0f - (120.0f / 341.0f * i * 2))) * Math.PI / 180.0)) / 20),
                    (int)(200 - (lrs.data[i] * Math.Sin(((210.0f - (120.0f / 341.0f * i * 2))) * Math.PI / 180.0)) / 20));
            }

            p.Dispose();
            g.Dispose();
            Invoke((MethodInvoker)delegate
            {
                pictureBox1.Image = canvas;
                textBox_rcvCnt.Text = rcvCnt.ToString();
            });
        }

         private void writeData2(LRSResult lrs)
        {
            Bitmap canvas = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            Graphics g = Graphics.FromImage(canvas);
            int rcvCnt = lrs.rcvCnt;

            Pen p = new Pen(Color.Black, 1);
            for (int i = 1; i < pictureBox1.Width / 50; i++)
            {
                g.DrawLine(p, 50 * i, 0, 50 * i, 250);
            }

            for (int i = 1; i < pictureBox1.Height / 50; i++)
            {
                g.DrawLine(p, 0, 50 * i, 500, 50 * i);
            }

            p.Color = Color.GreenYellow;
            g.DrawPie(p, 50, -150, 400, 400, -30, 240);
//            g.DrawPie(p, 50, 0, 400, 400, 30, -240);

            p.Color = Color.Red;
            float tmp = 0;
            for (int i = 1; i < lrs.data_length; i++)
            {
                g.DrawLine(p, 250, 50,
                    (int)(250 + (lrs.data[i] * Math.Cos(((30.0f - (120.0f / 341.0f * i * 2))) * Math.PI / 180.0)) / 20),
                    (int)(50 - (lrs.data[i] * Math.Sin(((30.0f - (120.0f / 341.0f * i * 2))) * Math.PI / 180.0)) / 20));
            }

            p.Dispose();
            g.Dispose();
            Invoke((MethodInvoker)delegate
            {
                pictureBox2.Image = canvas;
                textBox_rcvCnt2.Text = rcvCnt.ToString();
            });
        }
	}


    public class connectConfig
    {
        public connectConfig() { }
        public string HostName { get; set; }
    }
}
