﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zmp.Rcz.Communication
{
/*    public enum GPS_DATA_TYPE
    {
        GPS_DATA_GGA,
        GPS_DATA_ZDA,
        GPS_DATA_GLL,
        GPS_DATA_GSA,
        GPS_DATA_GSV,
        GPS_DATA_VTG,
        GPS_DATA_RMC,
    };
    public enum GPS_QUALITY_TYPE
    {
        GPS_QUALITY_NOTAVAILABLE,
        GPS_QUALITY_STANDALONE,
        GPS_QUALITY_DGPS,
    };
    public enum GPS_RECEIVE_STATUS
    {
        GPS_RECEIVE_AVAILABLE,
        GPS_RECEIVE_VOID,
    };
    public enum GPS_MEASUREMENT_MODE
    {
        GPS_MODE_AUTODETECT,
        GPS_MODE_MANUALSELECT,
    };
    public enum GPS_MEASUREMENT_STATUS
    {
        GPS_STATUS_VOID,
        GPS_STATUS_TWODIMENSION,
        GPS_STATUS_THREEDEMENSION,
    };
    public struct GpsSatteliteInfo
    {
        public int satteliteNo;
        public double elevation;
        public double azimuth;
        public float snr;
    };
    public struct RcvDriveEncoder{
        public int[] enc;
    };
    public struct RcvDriveMotorV
    {
        public float velocR;
        public float velocL;
    };
    public struct RcvDriveStatus
    {
        public int mode;
        public int contMode;
        public bool servo;
        public byte errCode;
    };
    public struct RcvDriveSwStatus
    {
        public bool sw1;
        public bool sw2;
        public bool sw3;
        public bool sw4;
        public byte mode1;
        public byte mode2;
    };
    public struct RcvReactPos
    {
        public float targetPos;
        public float actualPos;
    };
    public struct RcvReactTorque
    {
        public int targetTorque;
        public int actualTorque;
    };
    public struct RcvSteerPos
    {
        public float targetPos;
        public float actualPos;
    };
    public struct RcvSteerStatus
    {
        public int mode;
        public int contMode;
        public bool reactServo;
        public bool steerServo;
        public byte errCode;
    };
    public struct RcvSyscomConfig
    {
        public int[] data;
    };
    public struct RcvSyscomEcho
    {
        public int group;
        public int num;
    };
    public struct RcvImuAcc
    {
        public double accX;
        public double accY;
        public double accZ;
        public int time;
    };
    public struct RcvImuGyro
    {
        public double gyroX;
        public double gyroY;
        public double gyroZ;
        public int time;
    };
    public struct RcvImuComp
    {
        public double compX;
        public double compY;
        public double compZ;
        public int time;
    };
    public struct RcvImuDeviceProfile
    {
        public byte hard;
        public byte firm;
        public byte[] btadr;
    };
    public struct RcvImuStatus
    {
        public int role;
        public int period;
        public byte rangeAcc;
        public byte rangeGyro;
        public byte rangeComp;
        public byte batt;
        public byte binary;
    };
    public struct RcvImuEcho
    {
        public int group;
        public int num;
    };
    public struct RcvPosGpsGGA
    {
        public int nodeNo;
        public GPS_DATA_TYPE type;
        public int utc_time_h;
        public int utc_time_m;
        public int utc_time_s;
        public int utc_time_ms;
        public double latitude;
        public double longitude;
        public GPS_QUALITY_TYPE quality;
        public int numOfSatelites;
        public float hdop;
        public double seaLevelAltitude;
        public double geoidLevel;
        public int ageOfDgps;
        public int dgpsStationId;
    };
    public struct RcvPosGpsZDA
    {
        public int nodeNo;
        public GPS_DATA_TYPE type;
        public int utc_time_h;
        public int utc_time_m;
        public int utc_time_s;
        public int utc_time_ms;
        public int utc_date_year;
        public int utc_date_month;
        public int utc_date_day;
        public float utc_date_timeZone;
    };
    public struct RcvPosGpsGLL
    {
        public int nodeNo;
        public GPS_DATA_TYPE type;
        public double latitude;
        public double longitude;
        public int utc_time_h;
        public int utc_time_m;
        public int utc_time_s;
        public int utc_time_ms;
        public GPS_RECEIVE_STATUS receiveStatus;
        public GPS_QUALITY_TYPE quality;
    };
    public struct RcvPosGpsGSA
    {
        public int nodeNo;
        public GPS_DATA_TYPE type;
        public GPS_MEASUREMENT_MODE mode;
        public GPS_MEASUREMENT_STATUS status;
        public int[] sateliteNo;
        public float pdop;
        public float hdop;
        public float vdop; 
    };
    public struct RcvPosGpsGSV
    {
        public int nodeNo;
        public GPS_DATA_TYPE type;
        public int numOfMsg;
        public int msgNo;
        public int numOfSattelite;
        public GpsSatteliteInfo satteliteInfo1;
        public GpsSatteliteInfo satteliteInfo2;
        public GpsSatteliteInfo satteliteInfo3;
        public GpsSatteliteInfo satteliteInfo4;
    };
    public struct RcvPosGpsVTG
    {
        public int nodeNo;
        public GPS_DATA_TYPE type;
        public double directionOfTrueNorth;
        public double directionOfMagneticNorth;
        public double speedKnot;
        public double speedKmph;
        public GPS_QUALITY_TYPE quality;
    };
    public struct RcvPosGpsRMC
    {
        public int nodeNo;
        public GPS_DATA_TYPE type;
        public int utc_time_h;
        public int utc_time_m;
        public int utc_time_s;
        public int utc_time_ms;
        public double latitude;
        public double longitude;
        public double speedKnot;
        public double directionOfTurnNorth;
        public int utc_date_year;
        public int utc_date_month;
        public int utc_date_day;
        public float utc_date_timeZone;
        public GPS_RECEIVE_STATUS status;
        public GPS_QUALITY_TYPE quality;
        public double magneticDeviation;
    };
    public struct RcvPosPressure
    {
        public int nodeNo;
        public float pressure;
        public float temperature;
    };
    public struct RcvPosHumidity
    {
        public int nodeNo;
        public float temperature;
        public float humidity;
    };
    public struct RcvPosStatus
    {
        public short gpsPeriod;
        public short pressurePeriod;
        public short humidityPeriod;
    };
    public struct RcvPosDeviceProfile
    {
        public byte hardware;
        public byte firmware;
    };
    public struct RcvPosEcho
    {
        public int group;
        public int num;
    };
	public static class MevParse
	{
        public static bool ParseBrakePedalInput(byte[] msg, out int input)
        {
            input = (int)msg[7] + ((int)msg[8] << 8) + ((int)msg[9] << 16) + ((int)msg[10] << 24);
            return true;
        }

        public static bool ParseDriveBatt(byte[] msg, out int batt)
        {
            batt = (int)msg[7] + ((int)msg[8] << 8);
            return true;
        }

        public static bool ParseDriveEncoder(byte[] msg, out RcvDriveEncoder enc)
        {
            enc.enc = new int[4];
            enc.enc[0] = (int)msg[7] + ((int)msg[8] << 8);
            enc.enc[1] = (int)msg[9] + ((int)msg[10] << 8);
            enc.enc[2] = (int)msg[11] + ((int)msg[12] << 8);
            enc.enc[3] = (int)msg[13] + ((int)msg[14] << 8);
            return true;
        }

        public static bool ParseDriveMotorV(byte[] msg, out RcvDriveMotorV veloc)
        {
            RcvDriveMotorV data = new RcvDriveMotorV();
            data.velocR = (int)msg[7] + ((int)msg[8] << 8);
            data.velocL = (int)msg[9] + ((int)msg[10] << 8);
            veloc = data;
            return true;
        }

        public static bool ParseDriveRawPedal(byte[] msg, out int rawPedal)
        {
            rawPedal = (int)msg[7] + ((int)msg[8] << 8);
            return true;
        }

        public static bool ParseDriveStatus(byte[] msg, out RcvDriveStatus status)
        {
            status.mode = (int)msg[7] + ((int)msg[8] << 8) + ((int)msg[9] << 16) + ((int)msg[10] << 24);
            status.contMode = (int)msg[11] + ((int)msg[12] << 8) + ((int)msg[13] << 16) + ((int)msg[14] << 24);
            if (msg[15] != 0)
                status.servo = true;
            else
                status.servo = false;
            status.errCode = msg[16];
            return true;
        }

        public static bool ParseDribeSwStatus(byte[] msg, out RcvDriveSwStatus swStatus)
        {
            if (msg[7] != 0)
                swStatus.sw1 = true;
            else
                swStatus.sw1 = false;
            if (msg[8] != 0)
                swStatus.sw2 = true;
            else
                swStatus.sw2 = false;
            if (msg[9] != 0)
                swStatus.sw3 = true;
            else
                swStatus.sw3 = false;
            if (msg[10] != 0)
                swStatus.sw4 = true;
            else
                swStatus.sw4 = false;
            swStatus.mode1 = msg[11];
            swStatus.mode2 = msg[12];
            return true;
        }

        public static bool ParseReactPos(byte[] msg, out RcvReactPos pos)
        {
            RcvReactPos data = new RcvReactPos();
            data.targetPos = (int)msg[7] + ((int)msg[8] << 8) + ((int)msg[9] << 16) + ((int)msg[10] << 24);
            data.actualPos = (int)msg[11] + ((int)msg[12] << 8) + ((int)msg[13] << 16) + ((int)msg[14] << 24);
            pos = data;
            return true;
        }

        public static bool ParseReactTorque(byte[] msg, out RcvReactTorque torque)
        {
            torque.targetTorque = (int)msg[7] + ((int)msg[8] << 8) + ((int)msg[9] << 16) + ((int)msg[10] << 24);
            torque.actualTorque = (int)msg[11] + ((int)msg[12] << 8) + ((int)msg[13] << 16) + ((int)msg[14] << 24);
            return true;
        }

        public static bool ParseSteerPos(byte[] msg, out RcvSteerPos pos)
        {
            pos.targetPos = (int)msg[7] + ((int)msg[8] << 8) + ((int)msg[9] << 16) + ((int)msg[10] << 24);
            pos.actualPos = (int)msg[11] + ((int)msg[12] << 8) + ((int)msg[13] << 16) + ((int)msg[14] << 24);
            return true;
        }

        public static bool ParseSteerStatus(byte[] msg, out RcvSteerStatus status)
        {
            status.mode = (int)msg[7] + ((int)msg[8] << 8) + ((int)msg[9] << 16) + ((int)msg[10] << 24);
            if (msg[11] != 0)
                status.steerServo = true;
            else
                status.steerServo = false;
            status.contMode = (int)msg[12] + ((int)msg[13] << 8) + ((int)msg[14] << 16) + ((int)msg[15] << 24);
            if (msg[16] != 0)
                status.reactServo = true;
            else
                status.reactServo = false;
            status.errCode = msg[17];
            return true;
        }

        public static bool ParseSyscomConfig(byte[] msg, out RcvSyscomConfig config)
        {
            config.data = new int[4];
            config.data[0] = (int)msg[7] + ((int)msg[8] << 8) + ((int)msg[9] << 16) + ((int)msg[10] << 24);
            config.data[1] = (int)msg[11] + ((int)msg[12] << 8) + ((int)msg[13] << 16) + ((int)msg[14] << 24);
            config.data[2] = (int)msg[15] + ((int)msg[16] << 8) + ((int)msg[17] << 16) + ((int)msg[18] << 24);
            config.data[3] = (int)msg[19] + ((int)msg[20] << 8) + ((int)msg[21] << 16) + ((int)msg[22] << 24);
            return true;
        }
        public static bool ParseSyscomEcho(byte[] msg, out RcvSyscomEcho echo)
        {
            echo.group = (int)msg[7] + ((int)msg[8] << 8) + ((int)msg[9] << 16) + ((int)msg[10] << 24);
            echo.num = (int)msg[11] + ((int)msg[12] << 8) + ((int)msg[13] << 16) + ((int)msg[14] << 24);            
            return true;
        }

        public static bool ParseImuMeasurementAcc(byte[] msg, out RcvImuAcc acc)
        {
            acc.accX = msg[7] + (msg[8] << 8);
            acc.accY = msg[9] + (msg[10] << 8);
            acc.accZ = msg[11] + (msg[12] << 8);
            acc.time = msg[13] + (msg[14] << 8);
            return true;
        }
        public static bool ParseImuMeasurementGyro(byte[] msg, out RcvImuGyro gyro)
        {
            gyro.gyroX = msg[7] + (msg[8] << 8);
            gyro.gyroY = msg[9] + (msg[10] << 8);
            gyro.gyroZ = msg[11] + (msg[12] << 8);
            gyro.time = msg[13] + (msg[14] << 8);
            return true;
        }
        public static bool ParseImuMeasurementComp(byte[] msg, out RcvImuComp comp)
        {
            comp.compX = msg[7] + (msg[8] << 8);
            comp.compY = msg[9] + (msg[10] << 8);
            comp.compZ = msg[11] + (msg[12] << 8);
            comp.time = msg[13] + (msg[14] << 8);
            return true;
        }
        public static bool ParseImuDeviceProfile(byte[] msg, out RcvImuDeviceProfile profile)
        {
            profile.hard = msg[7];
            profile.firm = msg[8];
            profile.btadr = new byte[6];
            profile.btadr[0] = msg[9];
            profile.btadr[1] = msg[10];
            profile.btadr[2] = msg[11];
            profile.btadr[3] = msg[12];
            profile.btadr[4] = msg[13];
            profile.btadr[5] = msg[14];
            return true;
        }

        public static bool ParseImuEcho(byte[] msg, out RcvImuEcho echo)
        {
            echo.group = (int)msg[7] + ((int)msg[8] << 8) + ((int)msg[9] << 16) + ((int)msg[10] << 24);
            echo.num = (int)msg[11] + ((int)msg[12] << 8) + ((int)msg[13] << 16) + ((int)msg[14] << 24);            
            return true;
        }
        public static bool ParseImuStatus(byte[] msg, out RcvImuStatus status)
        {
            RcvImuStatus stat = new RcvImuStatus();
            stat.role = (int)msg[7] + ((int)msg[8] << 8) + ((int)msg[9] << 16) + ((int)msg[10] << 24);
            stat.period = (int)msg[11] + ((int)msg[12] << 8) + ((int)msg[13] << 16) + ((int)msg[14] << 24);
            stat.rangeAcc = msg[15];
            stat.rangeGyro = msg[16];
            stat.rangeComp = msg[17];
            stat.batt = msg[18];
            status = stat;
            return true;
        }

        public static bool ParsePosGpsGGA(byte[] msg, out RcvPosGpsGGA gga)
        {
            RcvPosGpsGGA data = new RcvPosGpsGGA();
            data.nodeNo = 0x00;
*            gga.type =
            gga.utc_time_h = 
            gga.utc_time_m =
            gga.utc_time_s =
            gga.utc_time_ms =
            gga.latitude =
            gga.longitude =
            gga.quality =
            gga.numOfSatelites =
            gga.hdop =
            gga.seaLevelAltitude = 
            gga.geoidLevel = 
            gga.ageOfDgps = 
            gga.dgpsStationId =
            gga = data;
            return true;
        }
        public static bool ParsePosGpsZDA(byte[] msg, out RcvPosGpsZDA zda)
        {
            RcvPosGpsZDA data = new RcvPosGpsZDA();
            data.nodeNo = 0x00;
            zda.type =
            zda.utc_time_h =
            zda.utc_time_m =
            zda.utc_time_s =
            zda.utc_time_ms =
            zda.utc_date_year =
            zda.utc_date_month =
            zda.utc_date_day =
            zda.utc_date_timeZone =
            zda = data;
            return true;
        }
        public static bool ParsePosGpsGLL(byte[] msg, out RcvPosGpsGLL gll)
        {
            RcvPosGpsGLL data = new RcvPosGpsGLL();
            data.nodeNo = 0x00;
            gll.type =
            gll.latitude =
            gll.longitude =
            gll.utc_time_h =
            gll.utc_time_m =
            gll.utc_time_s =
            gll.utc_time_ms =
            gll.receiveStatus =
            gll.quality =
            gll = data;
            return true;
        }
        public static bool ParsePosGpsGSA(byte[] msg, out RcvPosGpsGSA gsa)
        {
            RcvPosGpsGSA data = new RcvPosGpsGSA();
            data.nodeNo = 0x00;
            gsa.type =
            gsa.mode =
            gsa.status =
            gsa.sateliteNo = new int[12];
            for(int i=0; i<12; i++)
            {
                gsa.sateliteNo[i] =
            }
            gsa.pdop =
            gsa.hdop =
            gsa.vdop =
            gsa = data;
            return true;
        }
        public static bool ParsePosGpsGSV(byte[] msg, out RcvPosGpsGSV gsv)
        {
            RcvPosGpsGSV data = new RcvPosGpsGSV();
            data.nodeNo = 0x00;
            gsv.type =
            gsv.numOfMsg =
            gsv.msgNo =
            gsv.numOfSattelite =
            gsv.satteliteInfo1.satteliteNo =
            gsv.satteliteInfo1.elevation =
            gsv.satteliteInfo1.azimuth =
            gsv.satteliteInfo1.snr =
            gsv.satteliteInfo2.satteliteNo =
            gsv.satteliteInfo2.elevation =
            gsv.satteliteInfo2.azimuth =
            gsv.satteliteInfo2.snr =
            gsv.satteliteInfo3.satteliteNo =
            gsv.satteliteInfo3.elevation =
            gsv.satteliteInfo3.azimuth =
            gsv.satteliteInfo3.snr =
            gsv.satteliteInfo4.satteliteNo =
            gsv.satteliteInfo4.elevation =
            gsv.satteliteInfo4.azimuth =
            gsv.satteliteInfo4.snr = 
            gsv = data;
            return true;
        }
        public static bool ParsePosGpsVTG(byte[] msg, out RcvPosGpsVTG vtg)
        {
            RcvPosGpsVTG data = new RcvPosGpsVTG();
            data.nodeNo = 0x00;
            vtg.type =
            vtg.directionOfTrueNorth =
            vtg.directionOfMagneticNorth =
            vtg.speedKnot =
            vtg.speedKmph =
            vtg.quality =
            vtg = data;
            return true;
        }
        public static bool ParsePosGpsRMC(byte[] msg, out RcvPosGpsRMC rmc)
        {
            RcvPosGpsRMC data = new RcvPosGpsRMC();
            data.nodeNo = 0x00;
            rmc.type =
            rmc.utc_time_h =
            rmc.utc_time_m =
            rmc.utc_time_s =
            rmc.utc_time_ms =
            rmc.latitude =
            rmc.longitude =
            rmc.speedKnot =
            rmc.directionOfTurnNorth =
            rmc.utc_date_year =
            rmc.utc_date_month =
            rmc.utc_date_day =
            rmc.utc_date_timeZone =
            rmc.status =
            rmc.quality =
            rmc.magneticDeviation =
            rmc = data;
            return true;
        }
        public static bool ParsePosHumidity(byte[] msg, out RcvPosHumidity humidity)
        {
            RcvPosHumidity data = new RcvPosHumidity();
            data.nodeNo = 0x00;
//            humidity.temperature =
//            humidity.humidity =
            humidity = data;
            return true;
        }
        public static bool ParsePosPressure(byte[] msg, out RcvPosPressure pressure)
        {
            RcvPosPressure data = new RcvPosPressure();
            data.nodeNo = 0x00;
//            pressure.pressure =
//            pressure.temperature =
            pressure = data;
            return true;
        }
        public static bool ParsePosDeviceProfile(byte[] msg, out RcvPosDeviceProfile profile)
        {
            RcvPosDeviceProfile data = new RcvPosDeviceProfile();
            data.hardware = 0x00;
//            profile.firmware =
            profile = data;
            return true;
        }
        public static bool ParsePosEcho(byte[] msg, out RcvPosEcho echo)
        {
            echo.group = 0x00;
            echo.num = 0x00;
            return true;
        }
        public static bool ParsePosStatus(byte[] msg, out RcvPosStatus status)
        {
            RcvPosStatus data = new RcvPosStatus();
            data.gpsPeriod = 0x00;
//            status.pressurePeriod =
//            status.humidityPeriod =
            status = data;
            return true;
        }
    }*/
}