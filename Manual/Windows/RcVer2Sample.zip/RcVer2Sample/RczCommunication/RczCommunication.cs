﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zmp.Rcz.Communication
{
    

    public struct LRSResult
    {
        public ulong magic;
        public ulong timestamp;
        public int data_length;
        public int rcvCnt;
        public int dev;
//        public float[] angle;
        public ushort[] data;
    };

    public struct RcvSensorInf
    {
        public float gyro;
        public float acc_x;
        public float acc_y;
        public float acc_z;
        public float motor_enc;
        public float wheel_enc1;
        public float wheel_enc2;
        public float wheel_enc3;
        public float wheel_enc4;
    };

    public struct RcvObstacleInf
    {
        public ushort[] ir_obstacle;
    };

    public struct RcvPowerInf
    {
        public float motor_current;
        public float batt_voltage;
    };

    public struct RcvLrsInf
    {
        public LRSResult lrs_data;  
    };

    public struct RcvServoInf
    {
        public int servo_id;
        public float present_position;
        public int present_speed;
        public int present_current;
        public int present_temperature;
        public int present_volts;
    };

    public struct RcvThermoInf
    {
        public float thermo_fet1;
        public float thermo_fet2;
        public float thermo_motor;
    };

    public struct RcvCamberInf
    {
        public RcvServoInf[] camber_data;
    };

    public struct RcvImage
    {
        public byte image_id;
        public byte ch;
        public ushort width;
        public ushort height;

        public ushort total_index;
        public ushort index;
        public ushort block_size;

        public byte[] data;
    };

    public struct RcvLaneResult
    {
        public short[]   xpos_l;
        public short[]   xpos_r;
        public short[]   ypos_l;
        public short[]   ypos_r;
    };

    public struct RcvStereoResultHist
    {
        public byte[] value;
        public byte[] index;
    };

    public struct RcvStereoResultHough
    {
        public ushort npoint;
        public ushort[] point_x0;
        public ushort[] point_x1;
        public byte[] point_y0;
        public byte[] point_y1;
    };

    public struct RcvStereoResultLabeling
    {
        public ushort npoint;
        public ushort[] point_x0;
        public ushort[] point_x1;
        public byte[] point_y0;
        public byte[] point_y1;
    };

    /// <summary>
    /// MEV communication class.
    /// </summary>
    public class RczCommunication : AsyncSockClient
	{
		/// <summary>
		/// Receive handler.
		/// </summary>
		/// <param name="sender">object.</param>
		/// <param name="msg">MEV message.</param>
		public delegate void ReceivedHandler(object sender, RczMsg msg);
        /// <summary>
        /// Open close handler.
        /// </summary>
        /// <param name="sender">object.</param>
        /// <param name="bOpen">open(true/false)</param>
		public delegate void OpenCloseHandler(object sender, bool bOpen);
        /// <summary>
        /// constructer
        /// </summary>
		public RczCommunication()
		{
		}

        /// <summary>
        /// Open processing.
        /// </summary>
        /// <returns>true/false</returns>
		public bool Open()
		{
			return base.Connect();
		}
        /// <summary>
        /// Close processing.
        /// </summary>
		public void Close()
		{
			base.Disconnect();
		}
        /// <summary>
        /// receive handler.
        /// </summary>
		public ReceivedHandler Received
		{
			get;
			set;
		}
        /// <summary>
        /// open close handler.
        /// </summary>
		public OpenCloseHandler OpenedOrClosed
		{
			get;
			set;
		}
        /// <summary>
        /// Message send.
        /// </summary>
        /// <param name="pkt">message.</param>
        /// <returns>true/false</returns>
		public new bool Send(byte[] pkt)
		{
			try
			{
				if (base.IsConnect)
				{
					base.Send(pkt);
					return true;
				}
				else
				{
					return false;
				}
			}
			catch (Exception exp)
			{
				return false;
			}
		}


        /// <summary>
        /// Socket message receive handler.
        /// </summary>
        /// <param name="fifo">receive queue.</param>
		protected override void socket_ReceivedHandler(Queue<byte> fifo)
		{
			if (Received != null)
			{
                byte[] data = new byte[fifo.Count];
                data = fifo.ToArray();
                int dataIndex = 0;
                bool chkFlg = false;
                while (dataIndex < data.Length)
                {
                    for (; dataIndex < data.Length; dataIndex++)
                    {
                        if (dataIndex >= data.Length - 1)
                            break;
                        if (data[dataIndex] == 0xac && data[dataIndex + 1] == 0xca)
                        {
/*                            chkFlg = false;
                            switch((RCZHMSG_ID)data[dataIndex+6]){
                                case RCZHMSG_ID.RCZHMSG_ID_GET_LRS_INFO_RES:
                                case RCZHMSG_ID.RCZHMSG_ID_GET_OBSTACLE_INFO_RES:
                                case RCZHMSG_ID.RCZHMSG_ID_GET_POWER_INFO_RES:
                                case RCZHMSG_ID.RCZHMSG_ID_GET_SENSOR_INFO_RES:
                                case RCZHMSG_ID.RCZHMSG_ID_GET_SERVO_INFO_RES:
                                case RCZHMSG_ID.RCZHMSG_ID_GET_THERMO_INFO_RES:
                                    chkFlg = true;
                                    break;
                            }
                            if (chkFlg == true)*/
                                break;
                        }
                    }
                    if (dataIndex + 7 >= data.Length)
                        break;
                    RczMsg msg = new RczMsg();
                    msg.header = new byte[2];
                    msg.header[0] = data[dataIndex];
                    msg.header[1] = data[dataIndex + 1];
                    msg.len = (ulong)data[dataIndex + 2] + ((ulong)data[dataIndex + 3] << 8) + ((ulong)data[dataIndex + 4] << 16) + ((ulong)data[dataIndex + 5] << 24);
                    if (dataIndex + (int)msg.len > data.Length)
                        break;
                    msg.id = data[dataIndex + 6];
                    msg.data = new byte[msg.len - 7];
                    for (int i = 7; i < (int)msg.len; i++)
                    {
                        msg.data[i - 7] = data[dataIndex + i];
                    }
                    Received(this, msg);
                    dataIndex = dataIndex + (int)msg.len;
                }
			}
		}
		/// <summary>
		/// オープンクローズハンドラ処理
		/// </summary>
		/// <param name="bOpened"></param>
		protected override void socket_ConnectedHandler(bool bOpened)
		{
			if (OpenedOrClosed != null)
			{
				OpenedOrClosed(this, bOpened);
			}
		}


        /// <summary>
        /// Pase drive encoder
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="enc">encoder enc[0]=left front, enc[1]=right front, enc[2]=left rear, enc[3]=right rear</param>
        /// <returns></returns>
        public bool ParseSensorInf(RczMsg msg, out RcvSensorInf sensor)
        {
            sensor.gyro = BitConverter.ToSingle(msg.data, 0);
            sensor.acc_x = BitConverter.ToSingle(msg.data, 4);
            sensor.acc_y = BitConverter.ToSingle(msg.data, 8);
            sensor.acc_z = BitConverter.ToSingle(msg.data, 12);
            sensor.motor_enc = BitConverter.ToSingle(msg.data, 16);
            sensor.wheel_enc1 = BitConverter.ToSingle(msg.data, 20);
            sensor.wheel_enc2 = BitConverter.ToSingle(msg.data, 24);
            sensor.wheel_enc3 = BitConverter.ToSingle(msg.data, 28);
            sensor.wheel_enc4 = BitConverter.ToSingle(msg.data, 32);

            return true;
        }

        public bool ParseObstacleInf(RczMsg msg, out RcvObstacleInf ir)
        {
            ir.ir_obstacle = new ushort[8];
            for (int i = 0; i < 8; i++)
            {
                ir.ir_obstacle[i] = BitConverter.ToUInt16(msg.data, i * 2);
            }
            return true;
        }

        public bool ParsePowerInf(RczMsg msg, out RcvPowerInf power)
        {
            power.motor_current = BitConverter.ToSingle(msg.data, 0);
            power.batt_voltage = BitConverter.ToSingle(msg.data, 4);

            return true;
        }

        public bool ParseThermoInf(RczMsg msg, out RcvThermoInf thermo)
        {
            thermo.thermo_fet1 = BitConverter.ToSingle(msg.data, 0);
            thermo.thermo_fet2 = BitConverter.ToSingle(msg.data, 4);
            thermo.thermo_motor = BitConverter.ToSingle(msg.data, 8);
            return true;
        }

        public bool ParseLrsInf(RczMsg msg, out LRSResult lrs)
        {
//            lrs.angle = new float[800];
            lrs.data = new ushort[726/2];
            lrs.magic = BitConverter.ToUInt64(msg.data, 0);
            lrs.timestamp = BitConverter.ToUInt64(msg.data, 8);
            lrs.data_length = BitConverter.ToInt32(msg.data, 16);
            lrs.rcvCnt = BitConverter.ToInt32(msg.data, 20);
            lrs.dev = BitConverter.ToInt32(msg.data, 24);
/*            for (int i = 0; i < 800; i++)
            {
                lrs.angle[i] = BitConverter.ToSingle(msg.data, 4 * i + 24);
            }*/
            for (int i = 0; i < 726/2; i++)
            {
                lrs.data[i] = BitConverter.ToUInt16(msg.data, 2 * i + 28);
            }

            return true;
        }

        public bool ParseServoInf(RczMsg msg, out RcvServoInf servo)
        {
            servo.servo_id = BitConverter.ToInt32(msg.data, 0);
            servo.present_position = BitConverter.ToSingle(msg.data, 4);
            servo.present_speed = BitConverter.ToInt32(msg.data, 8);
            servo.present_current = BitConverter.ToInt32(msg.data, 12);
            servo.present_temperature = BitConverter.ToInt32(msg.data, 16);
            servo.present_volts = BitConverter.ToInt32(msg.data, 20);

            return true;
        }
    
    }
}
