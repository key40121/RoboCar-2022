﻿namespace MevControl
{
    partial class MevControlForm
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage_Mev = new System.Windows.Forms.TabPage();
            this.button_logStop = new System.Windows.Forms.Button();
            this.button2_logStart = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox_mevVoltage = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.groupBox_driveSwitch = new System.Windows.Forms.GroupBox();
            this.textBox_mode2 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.textBox_mode1 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.textBox_sw4 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox_sw3 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox_sw2 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox_sw1 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.groupBox_SteerStatus = new System.Windows.Forms.GroupBox();
            this.textBox_steerErrCode = new System.Windows.Forms.TextBox();
            this.textBox_reactServo = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox_reactContMode = new System.Windows.Forms.TextBox();
            this.textBox_steerServo = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox_steerMode = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.button_GetSteerStatus = new System.Windows.Forms.Button();
            this.groupBox_reaction = new System.Windows.Forms.GroupBox();
            this.textBox_reactActualTorque = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox_reactTargetTorque = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.button_modeReactTorque = new System.Windows.Forms.Button();
            this.button_modeReactPos = new System.Windows.Forms.Button();
            this.button_setReactTorqueZero = new System.Windows.Forms.Button();
            this.button_setReactTorque = new System.Windows.Forms.Button();
            this.textBox_setReactTorque = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.hScrollBar_ReactTorque = new System.Windows.Forms.HScrollBar();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox_reactActualPos = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox_reactTargetPos = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.button_setReactPosZero = new System.Windows.Forms.Button();
            this.button_setReactPos = new System.Windows.Forms.Button();
            this.textBox_setReactPos = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.hScrollBar_reactPos = new System.Windows.Forms.HScrollBar();
            this.label35 = new System.Windows.Forms.Label();
            this.button_reactOff = new System.Windows.Forms.Button();
            this.button_reactOn = new System.Windows.Forms.Button();
            this.groupBox_steer = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox_steerActualPos = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox_steerTargetPos = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.button_setSteerPosZero = new System.Windows.Forms.Button();
            this.button_setSteerPos = new System.Windows.Forms.Button();
            this.textBox_setSteerPos = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.hScrollBar_steerPos = new System.Windows.Forms.HScrollBar();
            this.label19 = new System.Windows.Forms.Label();
            this.button_SteerOff = new System.Windows.Forms.Button();
            this.button_steerOn = new System.Windows.Forms.Button();
            this.groupBox_driveStatus = new System.Windows.Forms.GroupBox();
            this.textBox_driveErrCode = new System.Windows.Forms.TextBox();
            this.textBox_drivePedalInput = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox_driveContMode = new System.Windows.Forms.TextBox();
            this.textBox_driveServo = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox_driveMode = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox_drive = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox_targetVelocL = new System.Windows.Forms.TextBox();
            this.textBox_targetVelocR = new System.Windows.Forms.TextBox();
            this.button_modeTorque = new System.Windows.Forms.Button();
            this.button_modeVeloc = new System.Windows.Forms.Button();
            this.button_setDriveTorqueZero = new System.Windows.Forms.Button();
            this.button_setDriveTorque = new System.Windows.Forms.Button();
            this.textBox_setDriveTorque = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.hScrollBar_driveTorque = new System.Windows.Forms.HScrollBar();
            this.textBox_enc4 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_enc3 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_enc2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox_enc1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_actualVelocL = new System.Windows.Forms.TextBox();
            this.textBox_actualVelocR = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button_setVelocZero = new System.Windows.Forms.Button();
            this.button_setVeloc = new System.Windows.Forms.Button();
            this.textBox_setDriveVeloc = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.hScrollBar_driveVeloc = new System.Windows.Forms.HScrollBar();
            this.label1 = new System.Windows.Forms.Label();
            this.button_driveOff = new System.Windows.Forms.Button();
            this.button_driveOn = new System.Windows.Forms.Button();
            this.button_GetStatus = new System.Windows.Forms.Button();
            this.tabPage_Config = new System.Windows.Forms.TabPage();
            this.button_manualReactionVGainWrite = new System.Windows.Forms.Button();
            this.button_manualReactionVGainRead = new System.Windows.Forms.Button();
            this.numericUpDown_manualReactVGain = new System.Windows.Forms.NumericUpDown();
            this.label184 = new System.Windows.Forms.Label();
            this.groupBox_rawPedalInput = new System.Windows.Forms.GroupBox();
            this.button_getRawPedal = new System.Windows.Forms.Button();
            this.textbox_drivieRawPedalInput = new System.Windows.Forms.TextBox();
            this.button_configSave = new System.Windows.Forms.Button();
            this.button_configReadAll = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button_steerOffsetWrite = new System.Windows.Forms.Button();
            this.button_manualLockTorqueWrite = new System.Windows.Forms.Button();
            this.button_steerOffsetRead = new System.Windows.Forms.Button();
            this.button_manualLockTorqueRead = new System.Windows.Forms.Button();
            this.button_reactOffsetWrite = new System.Windows.Forms.Button();
            this.comboBox_steerKeepAlive = new System.Windows.Forms.ComboBox();
            this.numericUpDown_steerOffset = new System.Windows.Forms.NumericUpDown();
            this.label57 = new System.Windows.Forms.Label();
            this.numericUpDown_manualLockTorque = new System.Windows.Forms.NumericUpDown();
            this.button_steerKeepAliveRead = new System.Windows.Forms.Button();
            this.button_steerKeepAliveWrite = new System.Windows.Forms.Button();
            this.button_reactOffsetRead = new System.Windows.Forms.Button();
            this.label180 = new System.Windows.Forms.Label();
            this.label181 = new System.Windows.Forms.Label();
            this.numericUpDown_reactionOffset = new System.Windows.Forms.NumericUpDown();
            this.label183 = new System.Windows.Forms.Label();
            this.button_manualRatioWrite = new System.Windows.Forms.Button();
            this.button_manualRatioRead = new System.Windows.Forms.Button();
            this.numericUpDown_manualRatio = new System.Windows.Forms.NumericUpDown();
            this.label182 = new System.Windows.Forms.Label();
            this.button_manualReactionGainWrite = new System.Windows.Forms.Button();
            this.button_manualReactionGainRead = new System.Windows.Forms.Button();
            this.button_manualSteerGainWrite = new System.Windows.Forms.Button();
            this.button_manualSteerGainRead = new System.Windows.Forms.Button();
            this.button_manualSteerVelocWrite = new System.Windows.Forms.Button();
            this.button_manualSteerVelocRead = new System.Windows.Forms.Button();
            this.button_reactVelocWrite = new System.Windows.Forms.Button();
            this.button_reactVelocRead = new System.Windows.Forms.Button();
            this.button_reactAccWrite = new System.Windows.Forms.Button();
            this.button_reactAccRead = new System.Windows.Forms.Button();
            this.button_steerGainWrite = new System.Windows.Forms.Button();
            this.button_steerVelocWrite = new System.Windows.Forms.Button();
            this.button_steerGainRead = new System.Windows.Forms.Button();
            this.button_steerVelocRead = new System.Windows.Forms.Button();
            this.numericUpDown_manualReactGain = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_manualSteerGain = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_manualSteerVeloc = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_reactVeloc = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_reactAcc = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_steerGain = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_steerVeloc = new System.Windows.Forms.NumericUpDown();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.groupBox_driveConfig = new System.Windows.Forms.GroupBox();
            this.numericUpDown_hostIntervalLimit = new System.Windows.Forms.NumericUpDown();
            this.button_driveKeepAliveWrite = new System.Windows.Forms.Button();
            this.button_driveKeepAliveRead = new System.Windows.Forms.Button();
            this.button_hostIntervalLimitWrite = new System.Windows.Forms.Button();
            this.button_accRawMinWrite = new System.Windows.Forms.Button();
            this.button_accRawMinRead = new System.Windows.Forms.Button();
            this.button_hostIntervalLimitRead = new System.Windows.Forms.Button();
            this.label179 = new System.Windows.Forms.Label();
            this.button_accRawMaxWrite = new System.Windows.Forms.Button();
            this.button_accRawMaxRead = new System.Windows.Forms.Button();
            this.button_driveLimitSUMWrite = new System.Windows.Forms.Button();
            this.button_driveLimitSUMRead = new System.Windows.Forms.Button();
            this.button_driveTorqueLimitWrite = new System.Windows.Forms.Button();
            this.button_driveTorqueLimitRead = new System.Windows.Forms.Button();
            this.button_driveVelocLimitWrite = new System.Windows.Forms.Button();
            this.button_driveVelocLimitRead = new System.Windows.Forms.Button();
            this.button_velocDGainWrite = new System.Windows.Forms.Button();
            this.button_velocDGainRead = new System.Windows.Forms.Button();
            this.button_velocIGainWrite = new System.Windows.Forms.Button();
            this.button_velocPGainWrite = new System.Windows.Forms.Button();
            this.button_velocIGainRead = new System.Windows.Forms.Button();
            this.button_velocPGainRead = new System.Windows.Forms.Button();
            this.comboBox_driveKeepAlive = new System.Windows.Forms.ComboBox();
            this.numericUpDown_accRawMin = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_accRawMax = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_SUMLimit = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_driveTorqueLimit = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_velocLimit = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_velocDgain = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_velocIgain = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_velocPgain = new System.Windows.Forms.NumericUpDown();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.tabPage_IMU = new System.Windows.Forms.TabPage();
            this.button_setImuStatus = new System.Windows.Forms.Button();
            this.button_GetImuProfile = new System.Windows.Forms.Button();
            this.groupBox_ImuProfile = new System.Windows.Forms.GroupBox();
            this.textBox_imuBtAdr = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.textBox_imuFirm = new System.Windows.Forms.TextBox();
            this.label81 = new System.Windows.Forms.Label();
            this.textBox_imuHard = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.button_getIMUStatus = new System.Windows.Forms.Button();
            this.groupBox_ImuStatus = new System.Windows.Forms.GroupBox();
            this.textBox_ImuBinary = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.textBox_ImuBattery = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.comboBox_ImuCompRange = new System.Windows.Forms.ComboBox();
            this.label77 = new System.Windows.Forms.Label();
            this.comboBox_ImuGyroRange = new System.Windows.Forms.ComboBox();
            this.label76 = new System.Windows.Forms.Label();
            this.comboBox_ImuAccRange = new System.Windows.Forms.ComboBox();
            this.numericUpDown_ImuPeriod = new System.Windows.Forms.NumericUpDown();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.textBox_ImuRole = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.groupBox_comp = new System.Windows.Forms.GroupBox();
            this.textBox_compZ = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.textBox_compY = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.textBox_compX = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.groupBox_gyro = new System.Windows.Forms.GroupBox();
            this.textBox_gyroZ = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.textBox_gyroY = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.textBox_gyroX = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.groupBox_acc = new System.Windows.Forms.GroupBox();
            this.textBox_accZ = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.textBox_accY = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.textBox_AccX = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.connectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tabControl.SuspendLayout();
            this.tabPage_Mev.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox_driveSwitch.SuspendLayout();
            this.groupBox_SteerStatus.SuspendLayout();
            this.groupBox_reaction.SuspendLayout();
            this.groupBox_steer.SuspendLayout();
            this.groupBox_driveStatus.SuspendLayout();
            this.groupBox_drive.SuspendLayout();
            this.tabPage_Config.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_manualReactVGain)).BeginInit();
            this.groupBox_rawPedalInput.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_steerOffset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_manualLockTorque)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_reactionOffset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_manualRatio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_manualReactGain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_manualSteerGain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_manualSteerVeloc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_reactVeloc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_reactAcc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_steerGain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_steerVeloc)).BeginInit();
            this.groupBox_driveConfig.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_hostIntervalLimit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_accRawMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_accRawMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_SUMLimit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_driveTorqueLimit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_velocLimit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_velocDgain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_velocIgain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_velocPgain)).BeginInit();
            this.tabPage_IMU.SuspendLayout();
            this.groupBox_ImuProfile.SuspendLayout();
            this.groupBox_ImuStatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_ImuPeriod)).BeginInit();
            this.groupBox_comp.SuspendLayout();
            this.groupBox_gyro.SuspendLayout();
            this.groupBox_acc.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage_Mev);
            this.tabControl.Controls.Add(this.tabPage_Config);
            this.tabControl.Controls.Add(this.tabPage_IMU);
            this.tabControl.Location = new System.Drawing.Point(0, 28);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(741, 544);
            this.tabControl.TabIndex = 0;
            // 
            // tabPage_Mev
            // 
            this.tabPage_Mev.Controls.Add(this.button_logStop);
            this.tabPage_Mev.Controls.Add(this.button2_logStart);
            this.tabPage_Mev.Controls.Add(this.groupBox2);
            this.tabPage_Mev.Controls.Add(this.groupBox_driveSwitch);
            this.tabPage_Mev.Controls.Add(this.groupBox_SteerStatus);
            this.tabPage_Mev.Controls.Add(this.button_GetSteerStatus);
            this.tabPage_Mev.Controls.Add(this.groupBox_reaction);
            this.tabPage_Mev.Controls.Add(this.groupBox_steer);
            this.tabPage_Mev.Controls.Add(this.groupBox_driveStatus);
            this.tabPage_Mev.Controls.Add(this.groupBox_drive);
            this.tabPage_Mev.Controls.Add(this.button_GetStatus);
            this.tabPage_Mev.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Mev.Name = "tabPage_Mev";
            this.tabPage_Mev.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Mev.Size = new System.Drawing.Size(733, 518);
            this.tabPage_Mev.TabIndex = 0;
            this.tabPage_Mev.Text = "Mev";
            this.tabPage_Mev.UseVisualStyleBackColor = true;
            // 
            // button_logStop
            // 
            this.button_logStop.Location = new System.Drawing.Point(344, 374);
            this.button_logStop.Name = "button_logStop";
            this.button_logStop.Size = new System.Drawing.Size(63, 23);
            this.button_logStop.TabIndex = 37;
            this.button_logStop.Text = "logStop";
            this.button_logStop.UseVisualStyleBackColor = true;
            this.button_logStop.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2_logStart
            // 
            this.button2_logStart.Location = new System.Drawing.Point(275, 374);
            this.button2_logStart.Name = "button2_logStart";
            this.button2_logStart.Size = new System.Drawing.Size(63, 23);
            this.button2_logStart.TabIndex = 36;
            this.button2_logStart.Text = "logStart";
            this.button2_logStart.UseVisualStyleBackColor = true;
            this.button2_logStart.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox_mevVoltage);
            this.groupBox2.Controls.Add(this.label46);
            this.groupBox2.Location = new System.Drawing.Point(257, 314);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(152, 50);
            this.groupBox2.TabIndex = 35;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "battery status";
            // 
            // textBox_mevVoltage
            // 
            this.textBox_mevVoltage.Location = new System.Drawing.Point(84, 18);
            this.textBox_mevVoltage.Name = "textBox_mevVoltage";
            this.textBox_mevVoltage.ReadOnly = true;
            this.textBox_mevVoltage.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_mevVoltage.Size = new System.Drawing.Size(59, 19);
            this.textBox_mevVoltage.TabIndex = 25;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(39, 21);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(42, 12);
            this.label46.TabIndex = 24;
            this.label46.Text = "voltage";
            // 
            // groupBox_driveSwitch
            // 
            this.groupBox_driveSwitch.Controls.Add(this.textBox_mode2);
            this.groupBox_driveSwitch.Controls.Add(this.label42);
            this.groupBox_driveSwitch.Controls.Add(this.textBox_mode1);
            this.groupBox_driveSwitch.Controls.Add(this.label44);
            this.groupBox_driveSwitch.Controls.Add(this.textBox_sw4);
            this.groupBox_driveSwitch.Controls.Add(this.label40);
            this.groupBox_driveSwitch.Controls.Add(this.textBox_sw3);
            this.groupBox_driveSwitch.Controls.Add(this.label41);
            this.groupBox_driveSwitch.Controls.Add(this.textBox_sw2);
            this.groupBox_driveSwitch.Controls.Add(this.label39);
            this.groupBox_driveSwitch.Controls.Add(this.textBox_sw1);
            this.groupBox_driveSwitch.Controls.Add(this.label43);
            this.groupBox_driveSwitch.Location = new System.Drawing.Point(6, 398);
            this.groupBox_driveSwitch.Name = "groupBox_driveSwitch";
            this.groupBox_driveSwitch.Size = new System.Drawing.Size(236, 72);
            this.groupBox_driveSwitch.TabIndex = 34;
            this.groupBox_driveSwitch.TabStop = false;
            this.groupBox_driveSwitch.Text = "Drive Switch Status";
            // 
            // textBox_mode2
            // 
            this.textBox_mode2.Location = new System.Drawing.Point(175, 40);
            this.textBox_mode2.Name = "textBox_mode2";
            this.textBox_mode2.ReadOnly = true;
            this.textBox_mode2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_mode2.Size = new System.Drawing.Size(55, 19);
            this.textBox_mode2.TabIndex = 27;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(136, 43);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(38, 12);
            this.label42.TabIndex = 26;
            this.label42.Text = "mode2";
            // 
            // textBox_mode1
            // 
            this.textBox_mode1.Location = new System.Drawing.Point(59, 40);
            this.textBox_mode1.Name = "textBox_mode1";
            this.textBox_mode1.ReadOnly = true;
            this.textBox_mode1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_mode1.Size = new System.Drawing.Size(59, 19);
            this.textBox_mode1.TabIndex = 25;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(17, 43);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(38, 12);
            this.label44.TabIndex = 24;
            this.label44.Text = "mode1";
            // 
            // textBox_sw4
            // 
            this.textBox_sw4.Location = new System.Drawing.Point(192, 15);
            this.textBox_sw4.Name = "textBox_sw4";
            this.textBox_sw4.ReadOnly = true;
            this.textBox_sw4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_sw4.Size = new System.Drawing.Size(31, 19);
            this.textBox_sw4.TabIndex = 23;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(175, 18);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(13, 12);
            this.label40.TabIndex = 22;
            this.label40.Text = "R";
            // 
            // textBox_sw3
            // 
            this.textBox_sw3.Location = new System.Drawing.Point(135, 15);
            this.textBox_sw3.Name = "textBox_sw3";
            this.textBox_sw3.ReadOnly = true;
            this.textBox_sw3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_sw3.Size = new System.Drawing.Size(31, 19);
            this.textBox_sw3.TabIndex = 21;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(118, 18);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(13, 12);
            this.label41.TabIndex = 20;
            this.label41.Text = "D";
            // 
            // textBox_sw2
            // 
            this.textBox_sw2.Location = new System.Drawing.Point(80, 15);
            this.textBox_sw2.Name = "textBox_sw2";
            this.textBox_sw2.ReadOnly = true;
            this.textBox_sw2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_sw2.Size = new System.Drawing.Size(31, 19);
            this.textBox_sw2.TabIndex = 19;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(63, 18);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(13, 12);
            this.label39.TabIndex = 18;
            this.label39.Text = "N";
            // 
            // textBox_sw1
            // 
            this.textBox_sw1.Location = new System.Drawing.Point(20, 15);
            this.textBox_sw1.Name = "textBox_sw1";
            this.textBox_sw1.ReadOnly = true;
            this.textBox_sw1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_sw1.Size = new System.Drawing.Size(31, 19);
            this.textBox_sw1.TabIndex = 17;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(5, 18);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(13, 12);
            this.label43.TabIndex = 16;
            this.label43.Text = "B";
            // 
            // groupBox_SteerStatus
            // 
            this.groupBox_SteerStatus.Controls.Add(this.textBox_steerErrCode);
            this.groupBox_SteerStatus.Controls.Add(this.textBox_reactServo);
            this.groupBox_SteerStatus.Controls.Add(this.label26);
            this.groupBox_SteerStatus.Controls.Add(this.label27);
            this.groupBox_SteerStatus.Controls.Add(this.textBox_reactContMode);
            this.groupBox_SteerStatus.Controls.Add(this.textBox_steerServo);
            this.groupBox_SteerStatus.Controls.Add(this.label36);
            this.groupBox_SteerStatus.Controls.Add(this.label37);
            this.groupBox_SteerStatus.Controls.Add(this.textBox_steerMode);
            this.groupBox_SteerStatus.Controls.Add(this.label38);
            this.groupBox_SteerStatus.Location = new System.Drawing.Point(491, 198);
            this.groupBox_SteerStatus.Name = "groupBox_SteerStatus";
            this.groupBox_SteerStatus.Size = new System.Drawing.Size(236, 80);
            this.groupBox_SteerStatus.TabIndex = 33;
            this.groupBox_SteerStatus.TabStop = false;
            this.groupBox_SteerStatus.Text = "Steer Status";
            // 
            // textBox_steerErrCode
            // 
            this.textBox_steerErrCode.Location = new System.Drawing.Point(169, 57);
            this.textBox_steerErrCode.Name = "textBox_steerErrCode";
            this.textBox_steerErrCode.ReadOnly = true;
            this.textBox_steerErrCode.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_steerErrCode.Size = new System.Drawing.Size(53, 19);
            this.textBox_steerErrCode.TabIndex = 31;
            this.textBox_steerErrCode.Text = "unknown";
            // 
            // textBox_reactServo
            // 
            this.textBox_reactServo.Location = new System.Drawing.Point(66, 35);
            this.textBox_reactServo.Name = "textBox_reactServo";
            this.textBox_reactServo.ReadOnly = true;
            this.textBox_reactServo.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_reactServo.Size = new System.Drawing.Size(33, 19);
            this.textBox_reactServo.TabIndex = 27;
            this.textBox_reactServo.Text = "unknown";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(111, 60);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(57, 12);
            this.label26.TabIndex = 30;
            this.label26.Text = "error code";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(6, 38);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(63, 12);
            this.label27.TabIndex = 26;
            this.label27.Text = "react servo";
            // 
            // textBox_reactContMode
            // 
            this.textBox_reactContMode.Location = new System.Drawing.Point(169, 35);
            this.textBox_reactContMode.Name = "textBox_reactContMode";
            this.textBox_reactContMode.ReadOnly = true;
            this.textBox_reactContMode.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_reactContMode.Size = new System.Drawing.Size(53, 19);
            this.textBox_reactContMode.TabIndex = 25;
            this.textBox_reactContMode.Text = "unknown";
            // 
            // textBox_steerServo
            // 
            this.textBox_steerServo.Location = new System.Drawing.Point(67, 13);
            this.textBox_steerServo.Name = "textBox_steerServo";
            this.textBox_steerServo.ReadOnly = true;
            this.textBox_steerServo.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_steerServo.Size = new System.Drawing.Size(32, 19);
            this.textBox_steerServo.TabIndex = 19;
            this.textBox_steerServo.Text = "unknown";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(98, 38);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(71, 12);
            this.label36.TabIndex = 24;
            this.label36.Text = "control mode";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(6, 16);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(63, 12);
            this.label37.TabIndex = 18;
            this.label37.Text = "steer servo";
            // 
            // textBox_steerMode
            // 
            this.textBox_steerMode.Location = new System.Drawing.Point(169, 13);
            this.textBox_steerMode.Name = "textBox_steerMode";
            this.textBox_steerMode.ReadOnly = true;
            this.textBox_steerMode.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_steerMode.Size = new System.Drawing.Size(53, 19);
            this.textBox_steerMode.TabIndex = 17;
            this.textBox_steerMode.Text = "unknown";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(137, 16);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(32, 12);
            this.label38.TabIndex = 16;
            this.label38.Text = "mode";
            // 
            // button_GetSteerStatus
            // 
            this.button_GetSteerStatus.Location = new System.Drawing.Point(491, 172);
            this.button_GetSteerStatus.Name = "button_GetSteerStatus";
            this.button_GetSteerStatus.Size = new System.Drawing.Size(79, 23);
            this.button_GetSteerStatus.TabIndex = 32;
            this.button_GetSteerStatus.Text = "GetStatus";
            this.button_GetSteerStatus.UseVisualStyleBackColor = true;
            this.button_GetSteerStatus.Click += new System.EventHandler(this.button_GetSteerStatus_Click);
            // 
            // groupBox_reaction
            // 
            this.groupBox_reaction.Controls.Add(this.textBox_reactActualTorque);
            this.groupBox_reaction.Controls.Add(this.label28);
            this.groupBox_reaction.Controls.Add(this.textBox_reactTargetTorque);
            this.groupBox_reaction.Controls.Add(this.label29);
            this.groupBox_reaction.Controls.Add(this.label24);
            this.groupBox_reaction.Controls.Add(this.button_modeReactTorque);
            this.groupBox_reaction.Controls.Add(this.button_modeReactPos);
            this.groupBox_reaction.Controls.Add(this.button_setReactTorqueZero);
            this.groupBox_reaction.Controls.Add(this.button_setReactTorque);
            this.groupBox_reaction.Controls.Add(this.textBox_setReactTorque);
            this.groupBox_reaction.Controls.Add(this.label25);
            this.groupBox_reaction.Controls.Add(this.hScrollBar_ReactTorque);
            this.groupBox_reaction.Controls.Add(this.label30);
            this.groupBox_reaction.Controls.Add(this.label31);
            this.groupBox_reaction.Controls.Add(this.textBox_reactActualPos);
            this.groupBox_reaction.Controls.Add(this.label32);
            this.groupBox_reaction.Controls.Add(this.textBox_reactTargetPos);
            this.groupBox_reaction.Controls.Add(this.label33);
            this.groupBox_reaction.Controls.Add(this.button_setReactPosZero);
            this.groupBox_reaction.Controls.Add(this.button_setReactPos);
            this.groupBox_reaction.Controls.Add(this.textBox_setReactPos);
            this.groupBox_reaction.Controls.Add(this.label34);
            this.groupBox_reaction.Controls.Add(this.hScrollBar_reactPos);
            this.groupBox_reaction.Controls.Add(this.label35);
            this.groupBox_reaction.Controls.Add(this.button_reactOff);
            this.groupBox_reaction.Controls.Add(this.button_reactOn);
            this.groupBox_reaction.Location = new System.Drawing.Point(248, 6);
            this.groupBox_reaction.Name = "groupBox_reaction";
            this.groupBox_reaction.Size = new System.Drawing.Size(236, 273);
            this.groupBox_reaction.TabIndex = 31;
            this.groupBox_reaction.TabStop = false;
            this.groupBox_reaction.Text = "Reaction";
            // 
            // textBox_reactActualTorque
            // 
            this.textBox_reactActualTorque.Location = new System.Drawing.Point(106, 240);
            this.textBox_reactActualTorque.Name = "textBox_reactActualTorque";
            this.textBox_reactActualTorque.ReadOnly = true;
            this.textBox_reactActualTorque.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_reactActualTorque.Size = new System.Drawing.Size(63, 19);
            this.textBox_reactActualTorque.TabIndex = 33;
            this.textBox_reactActualTorque.Text = "0.0";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(33, 243);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(72, 12);
            this.label28.TabIndex = 32;
            this.label28.Text = "actual torque";
            // 
            // textBox_reactTargetTorque
            // 
            this.textBox_reactTargetTorque.Location = new System.Drawing.Point(106, 215);
            this.textBox_reactTargetTorque.Name = "textBox_reactTargetTorque";
            this.textBox_reactTargetTorque.ReadOnly = true;
            this.textBox_reactTargetTorque.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_reactTargetTorque.Size = new System.Drawing.Size(63, 19);
            this.textBox_reactTargetTorque.TabIndex = 31;
            this.textBox_reactTargetTorque.Text = "0.0";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(34, 218);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(71, 12);
            this.label29.TabIndex = 30;
            this.label29.Text = "target torque";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(8, 44);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(71, 12);
            this.label24.TabIndex = 29;
            this.label24.Text = "control mode";
            // 
            // button_modeReactTorque
            // 
            this.button_modeReactTorque.Location = new System.Drawing.Point(154, 39);
            this.button_modeReactTorque.Name = "button_modeReactTorque";
            this.button_modeReactTorque.Size = new System.Drawing.Size(63, 23);
            this.button_modeReactTorque.TabIndex = 28;
            this.button_modeReactTorque.Text = "Torque";
            this.button_modeReactTorque.UseVisualStyleBackColor = true;
            this.button_modeReactTorque.Click += new System.EventHandler(this.button_modeReactTorque_Click);
            // 
            // button_modeReactPos
            // 
            this.button_modeReactPos.Location = new System.Drawing.Point(85, 39);
            this.button_modeReactPos.Name = "button_modeReactPos";
            this.button_modeReactPos.Size = new System.Drawing.Size(63, 23);
            this.button_modeReactPos.TabIndex = 27;
            this.button_modeReactPos.Text = "Position";
            this.button_modeReactPos.UseVisualStyleBackColor = true;
            this.button_modeReactPos.Click += new System.EventHandler(this.button_modeReactPos_Click);
            // 
            // button_setReactTorqueZero
            // 
            this.button_setReactTorqueZero.Location = new System.Drawing.Point(178, 167);
            this.button_setReactTorqueZero.Name = "button_setReactTorqueZero";
            this.button_setReactTorqueZero.Size = new System.Drawing.Size(44, 23);
            this.button_setReactTorqueZero.TabIndex = 26;
            this.button_setReactTorqueZero.Text = "zero";
            this.button_setReactTorqueZero.UseVisualStyleBackColor = true;
            this.button_setReactTorqueZero.Click += new System.EventHandler(this.button_setReactTorqueZero_Click);
            // 
            // button_setReactTorque
            // 
            this.button_setReactTorque.Location = new System.Drawing.Point(125, 167);
            this.button_setReactTorque.Name = "button_setReactTorque";
            this.button_setReactTorque.Size = new System.Drawing.Size(44, 23);
            this.button_setReactTorque.TabIndex = 25;
            this.button_setReactTorque.Text = "setT";
            this.button_setReactTorque.UseVisualStyleBackColor = true;
            this.button_setReactTorque.Click += new System.EventHandler(this.button_setReactTorque_Click);
            // 
            // textBox_setReactTorque
            // 
            this.textBox_setReactTorque.Location = new System.Drawing.Point(73, 169);
            this.textBox_setReactTorque.Name = "textBox_setReactTorque";
            this.textBox_setReactTorque.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_setReactTorque.Size = new System.Drawing.Size(45, 19);
            this.textBox_setReactTorque.TabIndex = 24;
            this.textBox_setReactTorque.Text = "0";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 172);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(57, 12);
            this.label25.TabIndex = 23;
            this.label25.Text = "set torque";
            // 
            // hScrollBar_ReactTorque
            // 
            this.hScrollBar_ReactTorque.AccessibleRole = System.Windows.Forms.AccessibleRole.Slider;
            this.hScrollBar_ReactTorque.Location = new System.Drawing.Point(16, 195);
            this.hScrollBar_ReactTorque.Maximum = 1000;
            this.hScrollBar_ReactTorque.Minimum = -1000;
            this.hScrollBar_ReactTorque.Name = "hScrollBar_ReactTorque";
            this.hScrollBar_ReactTorque.Size = new System.Drawing.Size(206, 13);
            this.hScrollBar_ReactTorque.TabIndex = 22;
            this.hScrollBar_ReactTorque.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar_ReactTorque_Scroll);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(175, 144);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(23, 12);
            this.label30.TabIndex = 13;
            this.label30.Text = "deg";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(175, 119);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(23, 12);
            this.label31.TabIndex = 12;
            this.label31.Text = "deg";
            // 
            // textBox_reactActualPos
            // 
            this.textBox_reactActualPos.Location = new System.Drawing.Point(106, 141);
            this.textBox_reactActualPos.Name = "textBox_reactActualPos";
            this.textBox_reactActualPos.ReadOnly = true;
            this.textBox_reactActualPos.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_reactActualPos.Size = new System.Drawing.Size(63, 19);
            this.textBox_reactActualPos.TabIndex = 11;
            this.textBox_reactActualPos.Text = "0.0";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(25, 144);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(80, 12);
            this.label32.TabIndex = 10;
            this.label32.Text = "actual position";
            // 
            // textBox_reactTargetPos
            // 
            this.textBox_reactTargetPos.Location = new System.Drawing.Point(106, 116);
            this.textBox_reactTargetPos.Name = "textBox_reactTargetPos";
            this.textBox_reactTargetPos.ReadOnly = true;
            this.textBox_reactTargetPos.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_reactTargetPos.Size = new System.Drawing.Size(63, 19);
            this.textBox_reactTargetPos.TabIndex = 9;
            this.textBox_reactTargetPos.Text = "0.0";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(26, 119);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(79, 12);
            this.label33.TabIndex = 8;
            this.label33.Text = "target position";
            // 
            // button_setReactPosZero
            // 
            this.button_setReactPosZero.Location = new System.Drawing.Point(178, 68);
            this.button_setReactPosZero.Name = "button_setReactPosZero";
            this.button_setReactPosZero.Size = new System.Drawing.Size(44, 23);
            this.button_setReactPosZero.TabIndex = 7;
            this.button_setReactPosZero.Text = "zero";
            this.button_setReactPosZero.UseVisualStyleBackColor = true;
            this.button_setReactPosZero.Click += new System.EventHandler(this.button_setReactPosZero_Click);
            // 
            // button_setReactPos
            // 
            this.button_setReactPos.Location = new System.Drawing.Point(125, 68);
            this.button_setReactPos.Name = "button_setReactPos";
            this.button_setReactPos.Size = new System.Drawing.Size(44, 23);
            this.button_setReactPos.TabIndex = 6;
            this.button_setReactPos.Text = "setP";
            this.button_setReactPos.UseVisualStyleBackColor = true;
            this.button_setReactPos.Click += new System.EventHandler(this.button_setReactPos_Click);
            // 
            // textBox_setReactPos
            // 
            this.textBox_setReactPos.Location = new System.Drawing.Point(73, 70);
            this.textBox_setReactPos.Name = "textBox_setReactPos";
            this.textBox_setReactPos.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_setReactPos.Size = new System.Drawing.Size(45, 19);
            this.textBox_setReactPos.TabIndex = 5;
            this.textBox_setReactPos.Text = "0.0";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(6, 73);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(65, 12);
            this.label34.TabIndex = 4;
            this.label34.Text = "set position";
            // 
            // hScrollBar_reactPos
            // 
            this.hScrollBar_reactPos.AccessibleRole = System.Windows.Forms.AccessibleRole.Slider;
            this.hScrollBar_reactPos.Location = new System.Drawing.Point(16, 96);
            this.hScrollBar_reactPos.Maximum = 4500;
            this.hScrollBar_reactPos.Minimum = -4500;
            this.hScrollBar_reactPos.Name = "hScrollBar_reactPos";
            this.hScrollBar_reactPos.Size = new System.Drawing.Size(206, 13);
            this.hScrollBar_reactPos.TabIndex = 3;
            this.hScrollBar_reactPos.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar_reactPos_Scroll);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(44, 15);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(33, 12);
            this.label35.TabIndex = 2;
            this.label35.Text = "servo";
            // 
            // button_reactOff
            // 
            this.button_reactOff.Location = new System.Drawing.Point(154, 10);
            this.button_reactOff.Name = "button_reactOff";
            this.button_reactOff.Size = new System.Drawing.Size(63, 23);
            this.button_reactOff.TabIndex = 1;
            this.button_reactOff.Text = "OFF";
            this.button_reactOff.UseVisualStyleBackColor = true;
            this.button_reactOff.Click += new System.EventHandler(this.button_reactOff_Click);
            // 
            // button_reactOn
            // 
            this.button_reactOn.Location = new System.Drawing.Point(85, 10);
            this.button_reactOn.Name = "button_reactOn";
            this.button_reactOn.Size = new System.Drawing.Size(63, 23);
            this.button_reactOn.TabIndex = 0;
            this.button_reactOn.Text = "ON";
            this.button_reactOn.UseVisualStyleBackColor = true;
            this.button_reactOn.Click += new System.EventHandler(this.button_reactOn_Click);
            // 
            // groupBox_steer
            // 
            this.groupBox_steer.Controls.Add(this.label20);
            this.groupBox_steer.Controls.Add(this.label21);
            this.groupBox_steer.Controls.Add(this.textBox_steerActualPos);
            this.groupBox_steer.Controls.Add(this.label22);
            this.groupBox_steer.Controls.Add(this.textBox_steerTargetPos);
            this.groupBox_steer.Controls.Add(this.label23);
            this.groupBox_steer.Controls.Add(this.button_setSteerPosZero);
            this.groupBox_steer.Controls.Add(this.button_setSteerPos);
            this.groupBox_steer.Controls.Add(this.textBox_setSteerPos);
            this.groupBox_steer.Controls.Add(this.label18);
            this.groupBox_steer.Controls.Add(this.hScrollBar_steerPos);
            this.groupBox_steer.Controls.Add(this.label19);
            this.groupBox_steer.Controls.Add(this.button_SteerOff);
            this.groupBox_steer.Controls.Add(this.button_steerOn);
            this.groupBox_steer.Location = new System.Drawing.Point(491, 6);
            this.groupBox_steer.Name = "groupBox_steer";
            this.groupBox_steer.Size = new System.Drawing.Size(236, 144);
            this.groupBox_steer.TabIndex = 30;
            this.groupBox_steer.TabStop = false;
            this.groupBox_steer.Text = "Steer";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(173, 118);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(23, 12);
            this.label20.TabIndex = 21;
            this.label20.Text = "deg";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(173, 93);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(23, 12);
            this.label21.TabIndex = 20;
            this.label21.Text = "deg";
            // 
            // textBox_steerActualPos
            // 
            this.textBox_steerActualPos.Location = new System.Drawing.Point(104, 115);
            this.textBox_steerActualPos.Name = "textBox_steerActualPos";
            this.textBox_steerActualPos.ReadOnly = true;
            this.textBox_steerActualPos.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_steerActualPos.Size = new System.Drawing.Size(63, 19);
            this.textBox_steerActualPos.TabIndex = 19;
            this.textBox_steerActualPos.Text = "0.0";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(22, 118);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(80, 12);
            this.label22.TabIndex = 18;
            this.label22.Text = "actual position";
            // 
            // textBox_steerTargetPos
            // 
            this.textBox_steerTargetPos.Location = new System.Drawing.Point(104, 90);
            this.textBox_steerTargetPos.Name = "textBox_steerTargetPos";
            this.textBox_steerTargetPos.ReadOnly = true;
            this.textBox_steerTargetPos.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_steerTargetPos.Size = new System.Drawing.Size(63, 19);
            this.textBox_steerTargetPos.TabIndex = 17;
            this.textBox_steerTargetPos.Text = "0.0";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(21, 93);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(79, 12);
            this.label23.TabIndex = 16;
            this.label23.Text = "target position";
            // 
            // button_setSteerPosZero
            // 
            this.button_setSteerPosZero.Location = new System.Drawing.Point(182, 42);
            this.button_setSteerPosZero.Name = "button_setSteerPosZero";
            this.button_setSteerPosZero.Size = new System.Drawing.Size(44, 23);
            this.button_setSteerPosZero.TabIndex = 15;
            this.button_setSteerPosZero.Text = "zero";
            this.button_setSteerPosZero.UseVisualStyleBackColor = true;
            this.button_setSteerPosZero.Click += new System.EventHandler(this.button_setSteerPosZero_Click);
            // 
            // button_setSteerPos
            // 
            this.button_setSteerPos.Location = new System.Drawing.Point(129, 42);
            this.button_setSteerPos.Name = "button_setSteerPos";
            this.button_setSteerPos.Size = new System.Drawing.Size(44, 23);
            this.button_setSteerPos.TabIndex = 14;
            this.button_setSteerPos.Text = "setP";
            this.button_setSteerPos.UseVisualStyleBackColor = true;
            this.button_setSteerPos.Click += new System.EventHandler(this.button_setSteerPos_Click);
            // 
            // textBox_setSteerPos
            // 
            this.textBox_setSteerPos.Location = new System.Drawing.Point(77, 44);
            this.textBox_setSteerPos.Name = "textBox_setSteerPos";
            this.textBox_setSteerPos.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_setSteerPos.Size = new System.Drawing.Size(45, 19);
            this.textBox_setSteerPos.TabIndex = 13;
            this.textBox_setSteerPos.Text = "0.0";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(10, 47);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(65, 12);
            this.label18.TabIndex = 12;
            this.label18.Text = "set position";
            // 
            // hScrollBar_steerPos
            // 
            this.hScrollBar_steerPos.AccessibleRole = System.Windows.Forms.AccessibleRole.Slider;
            this.hScrollBar_steerPos.Location = new System.Drawing.Point(20, 70);
            this.hScrollBar_steerPos.Maximum = 4500;
            this.hScrollBar_steerPos.Minimum = -4500;
            this.hScrollBar_steerPos.Name = "hScrollBar_steerPos";
            this.hScrollBar_steerPos.Size = new System.Drawing.Size(206, 13);
            this.hScrollBar_steerPos.TabIndex = 11;
            this.hScrollBar_steerPos.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar_steerPos_Scroll);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(48, 16);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(33, 12);
            this.label19.TabIndex = 10;
            this.label19.Text = "servo";
            // 
            // button_SteerOff
            // 
            this.button_SteerOff.Location = new System.Drawing.Point(158, 11);
            this.button_SteerOff.Name = "button_SteerOff";
            this.button_SteerOff.Size = new System.Drawing.Size(63, 23);
            this.button_SteerOff.TabIndex = 9;
            this.button_SteerOff.Text = "OFF";
            this.button_SteerOff.UseVisualStyleBackColor = true;
            this.button_SteerOff.Click += new System.EventHandler(this.button_SteerOff_Click);
            // 
            // button_steerOn
            // 
            this.button_steerOn.Location = new System.Drawing.Point(89, 11);
            this.button_steerOn.Name = "button_steerOn";
            this.button_steerOn.Size = new System.Drawing.Size(63, 23);
            this.button_steerOn.TabIndex = 8;
            this.button_steerOn.Text = "ON";
            this.button_steerOn.UseVisualStyleBackColor = true;
            this.button_steerOn.Click += new System.EventHandler(this.button_steerOn_Click);
            // 
            // groupBox_driveStatus
            // 
            this.groupBox_driveStatus.Controls.Add(this.textBox_driveErrCode);
            this.groupBox_driveStatus.Controls.Add(this.textBox_drivePedalInput);
            this.groupBox_driveStatus.Controls.Add(this.label17);
            this.groupBox_driveStatus.Controls.Add(this.label16);
            this.groupBox_driveStatus.Controls.Add(this.textBox_driveContMode);
            this.groupBox_driveStatus.Controls.Add(this.textBox_driveServo);
            this.groupBox_driveStatus.Controls.Add(this.label15);
            this.groupBox_driveStatus.Controls.Add(this.label14);
            this.groupBox_driveStatus.Controls.Add(this.textBox_driveMode);
            this.groupBox_driveStatus.Controls.Add(this.label13);
            this.groupBox_driveStatus.Location = new System.Drawing.Point(6, 314);
            this.groupBox_driveStatus.Name = "groupBox_driveStatus";
            this.groupBox_driveStatus.Size = new System.Drawing.Size(236, 80);
            this.groupBox_driveStatus.TabIndex = 29;
            this.groupBox_driveStatus.TabStop = false;
            this.groupBox_driveStatus.Text = "Drive Status";
            // 
            // textBox_driveErrCode
            // 
            this.textBox_driveErrCode.Location = new System.Drawing.Point(170, 57);
            this.textBox_driveErrCode.Name = "textBox_driveErrCode";
            this.textBox_driveErrCode.ReadOnly = true;
            this.textBox_driveErrCode.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_driveErrCode.Size = new System.Drawing.Size(53, 19);
            this.textBox_driveErrCode.TabIndex = 31;
            this.textBox_driveErrCode.Text = "unknown";
            // 
            // textBox_drivePedalInput
            // 
            this.textBox_drivePedalInput.Location = new System.Drawing.Point(170, 35);
            this.textBox_drivePedalInput.Name = "textBox_drivePedalInput";
            this.textBox_drivePedalInput.ReadOnly = true;
            this.textBox_drivePedalInput.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_drivePedalInput.Size = new System.Drawing.Size(53, 19);
            this.textBox_drivePedalInput.TabIndex = 27;
            this.textBox_drivePedalInput.Text = "unknown";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(112, 60);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(57, 12);
            this.label17.TabIndex = 30;
            this.label17.Text = "error code";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(108, 38);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(61, 12);
            this.label16.TabIndex = 26;
            this.label16.Text = "pedal input";
            // 
            // textBox_driveContMode
            // 
            this.textBox_driveContMode.Location = new System.Drawing.Point(170, 13);
            this.textBox_driveContMode.Name = "textBox_driveContMode";
            this.textBox_driveContMode.ReadOnly = true;
            this.textBox_driveContMode.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_driveContMode.Size = new System.Drawing.Size(53, 19);
            this.textBox_driveContMode.TabIndex = 25;
            this.textBox_driveContMode.Text = "unknown";
            // 
            // textBox_driveServo
            // 
            this.textBox_driveServo.Location = new System.Drawing.Point(40, 35);
            this.textBox_driveServo.Name = "textBox_driveServo";
            this.textBox_driveServo.ReadOnly = true;
            this.textBox_driveServo.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_driveServo.Size = new System.Drawing.Size(53, 19);
            this.textBox_driveServo.TabIndex = 19;
            this.textBox_driveServo.Text = "unknown";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(99, 16);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 12);
            this.label15.TabIndex = 24;
            this.label15.Text = "control mode";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(5, 38);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(33, 12);
            this.label14.TabIndex = 18;
            this.label14.Text = "servo";
            // 
            // textBox_driveMode
            // 
            this.textBox_driveMode.Location = new System.Drawing.Point(40, 13);
            this.textBox_driveMode.Name = "textBox_driveMode";
            this.textBox_driveMode.ReadOnly = true;
            this.textBox_driveMode.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_driveMode.Size = new System.Drawing.Size(53, 19);
            this.textBox_driveMode.TabIndex = 17;
            this.textBox_driveMode.Text = "unknown";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(5, 16);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(32, 12);
            this.label13.TabIndex = 16;
            this.label13.Text = "mode";
            // 
            // groupBox_drive
            // 
            this.groupBox_drive.Controls.Add(this.label6);
            this.groupBox_drive.Controls.Add(this.label5);
            this.groupBox_drive.Controls.Add(this.label12);
            this.groupBox_drive.Controls.Add(this.textBox_targetVelocL);
            this.groupBox_drive.Controls.Add(this.textBox_targetVelocR);
            this.groupBox_drive.Controls.Add(this.button_modeTorque);
            this.groupBox_drive.Controls.Add(this.button_modeVeloc);
            this.groupBox_drive.Controls.Add(this.button_setDriveTorqueZero);
            this.groupBox_drive.Controls.Add(this.button_setDriveTorque);
            this.groupBox_drive.Controls.Add(this.textBox_setDriveTorque);
            this.groupBox_drive.Controls.Add(this.label11);
            this.groupBox_drive.Controls.Add(this.hScrollBar_driveTorque);
            this.groupBox_drive.Controls.Add(this.textBox_enc4);
            this.groupBox_drive.Controls.Add(this.label9);
            this.groupBox_drive.Controls.Add(this.textBox_enc3);
            this.groupBox_drive.Controls.Add(this.label10);
            this.groupBox_drive.Controls.Add(this.label4);
            this.groupBox_drive.Controls.Add(this.textBox_enc2);
            this.groupBox_drive.Controls.Add(this.label8);
            this.groupBox_drive.Controls.Add(this.textBox_enc1);
            this.groupBox_drive.Controls.Add(this.label7);
            this.groupBox_drive.Controls.Add(this.textBox_actualVelocL);
            this.groupBox_drive.Controls.Add(this.textBox_actualVelocR);
            this.groupBox_drive.Controls.Add(this.label3);
            this.groupBox_drive.Controls.Add(this.button_setVelocZero);
            this.groupBox_drive.Controls.Add(this.button_setVeloc);
            this.groupBox_drive.Controls.Add(this.textBox_setDriveVeloc);
            this.groupBox_drive.Controls.Add(this.label2);
            this.groupBox_drive.Controls.Add(this.hScrollBar_driveVeloc);
            this.groupBox_drive.Controls.Add(this.label1);
            this.groupBox_drive.Controls.Add(this.button_driveOff);
            this.groupBox_drive.Controls.Add(this.button_driveOn);
            this.groupBox_drive.Location = new System.Drawing.Point(6, 6);
            this.groupBox_drive.Name = "groupBox_drive";
            this.groupBox_drive.Size = new System.Drawing.Size(236, 273);
            this.groupBox_drive.TabIndex = 27;
            this.groupBox_drive.TabStop = false;
            this.groupBox_drive.Text = "Drive";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(150, 119);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(19, 12);
            this.label6.TabIndex = 41;
            this.label6.Text = "(L)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(150, 144);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(19, 12);
            this.label5.TabIndex = 38;
            this.label5.Text = "(L)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(8, 44);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 12);
            this.label12.TabIndex = 29;
            this.label12.Text = "control mode";
            // 
            // textBox_targetVelocL
            // 
            this.textBox_targetVelocL.Location = new System.Drawing.Point(175, 116);
            this.textBox_targetVelocL.Name = "textBox_targetVelocL";
            this.textBox_targetVelocL.ReadOnly = true;
            this.textBox_targetVelocL.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_targetVelocL.Size = new System.Drawing.Size(42, 19);
            this.textBox_targetVelocL.TabIndex = 40;
            this.textBox_targetVelocL.Text = "0.0";
            // 
            // textBox_targetVelocR
            // 
            this.textBox_targetVelocR.Location = new System.Drawing.Point(99, 116);
            this.textBox_targetVelocR.Name = "textBox_targetVelocR";
            this.textBox_targetVelocR.ReadOnly = true;
            this.textBox_targetVelocR.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_targetVelocR.Size = new System.Drawing.Size(42, 19);
            this.textBox_targetVelocR.TabIndex = 39;
            this.textBox_targetVelocR.Text = "0.0";
            // 
            // button_modeTorque
            // 
            this.button_modeTorque.Location = new System.Drawing.Point(154, 39);
            this.button_modeTorque.Name = "button_modeTorque";
            this.button_modeTorque.Size = new System.Drawing.Size(63, 23);
            this.button_modeTorque.TabIndex = 28;
            this.button_modeTorque.Text = "Torque";
            this.button_modeTorque.UseVisualStyleBackColor = true;
            this.button_modeTorque.Click += new System.EventHandler(this.button_modeTorque_Click);
            // 
            // button_modeVeloc
            // 
            this.button_modeVeloc.Location = new System.Drawing.Point(85, 39);
            this.button_modeVeloc.Name = "button_modeVeloc";
            this.button_modeVeloc.Size = new System.Drawing.Size(63, 23);
            this.button_modeVeloc.TabIndex = 27;
            this.button_modeVeloc.Text = "Velocity";
            this.button_modeVeloc.UseVisualStyleBackColor = true;
            this.button_modeVeloc.Click += new System.EventHandler(this.button_modeVeloc_Click);
            // 
            // button_setDriveTorqueZero
            // 
            this.button_setDriveTorqueZero.Location = new System.Drawing.Point(178, 216);
            this.button_setDriveTorqueZero.Name = "button_setDriveTorqueZero";
            this.button_setDriveTorqueZero.Size = new System.Drawing.Size(44, 23);
            this.button_setDriveTorqueZero.TabIndex = 26;
            this.button_setDriveTorqueZero.Text = "zero";
            this.button_setDriveTorqueZero.UseVisualStyleBackColor = true;
            this.button_setDriveTorqueZero.Click += new System.EventHandler(this.button_setDriveTorqueZero_Click);
            // 
            // button_setDriveTorque
            // 
            this.button_setDriveTorque.Location = new System.Drawing.Point(125, 216);
            this.button_setDriveTorque.Name = "button_setDriveTorque";
            this.button_setDriveTorque.Size = new System.Drawing.Size(44, 23);
            this.button_setDriveTorque.TabIndex = 25;
            this.button_setDriveTorque.Text = "setT";
            this.button_setDriveTorque.UseVisualStyleBackColor = true;
            this.button_setDriveTorque.Click += new System.EventHandler(this.button_setDriveTorque_Click);
            // 
            // textBox_setDriveTorque
            // 
            this.textBox_setDriveTorque.Location = new System.Drawing.Point(73, 218);
            this.textBox_setDriveTorque.Name = "textBox_setDriveTorque";
            this.textBox_setDriveTorque.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_setDriveTorque.Size = new System.Drawing.Size(45, 19);
            this.textBox_setDriveTorque.TabIndex = 24;
            this.textBox_setDriveTorque.Text = "0.0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 221);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(57, 12);
            this.label11.TabIndex = 23;
            this.label11.Text = "set torque";
            // 
            // hScrollBar_driveTorque
            // 
            this.hScrollBar_driveTorque.AccessibleRole = System.Windows.Forms.AccessibleRole.Slider;
            this.hScrollBar_driveTorque.Location = new System.Drawing.Point(16, 244);
            this.hScrollBar_driveTorque.Maximum = 1000;
            this.hScrollBar_driveTorque.Minimum = -1000;
            this.hScrollBar_driveTorque.Name = "hScrollBar_driveTorque";
            this.hScrollBar_driveTorque.Size = new System.Drawing.Size(206, 13);
            this.hScrollBar_driveTorque.TabIndex = 22;
            this.hScrollBar_driveTorque.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar_driveTorque_Scroll);
            // 
            // textBox_enc4
            // 
            this.textBox_enc4.Location = new System.Drawing.Point(172, 189);
            this.textBox_enc4.Name = "textBox_enc4";
            this.textBox_enc4.ReadOnly = true;
            this.textBox_enc4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_enc4.Size = new System.Drawing.Size(53, 19);
            this.textBox_enc4.TabIndex = 21;
            this.textBox_enc4.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(121, 192);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 12);
            this.label9.TabIndex = 20;
            this.label9.Text = "enc(LR)";
            // 
            // textBox_enc3
            // 
            this.textBox_enc3.Location = new System.Drawing.Point(56, 189);
            this.textBox_enc3.Name = "textBox_enc3";
            this.textBox_enc3.ReadOnly = true;
            this.textBox_enc3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_enc3.Size = new System.Drawing.Size(53, 19);
            this.textBox_enc3.TabIndex = 19;
            this.textBox_enc3.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(5, 192);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 12);
            this.label10.TabIndex = 18;
            this.label10.Text = "enc(RR)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 12);
            this.label4.TabIndex = 10;
            this.label4.Text = "targetVelocity(R)";
            // 
            // textBox_enc2
            // 
            this.textBox_enc2.Location = new System.Drawing.Point(172, 166);
            this.textBox_enc2.Name = "textBox_enc2";
            this.textBox_enc2.ReadOnly = true;
            this.textBox_enc2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_enc2.Size = new System.Drawing.Size(53, 19);
            this.textBox_enc2.TabIndex = 17;
            this.textBox_enc2.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(121, 169);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 12);
            this.label8.TabIndex = 16;
            this.label8.Text = "enc(LF)";
            // 
            // textBox_enc1
            // 
            this.textBox_enc1.Location = new System.Drawing.Point(56, 166);
            this.textBox_enc1.Name = "textBox_enc1";
            this.textBox_enc1.ReadOnly = true;
            this.textBox_enc1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_enc1.Size = new System.Drawing.Size(53, 19);
            this.textBox_enc1.TabIndex = 15;
            this.textBox_enc1.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 169);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 12);
            this.label7.TabIndex = 14;
            this.label7.Text = "enc(RF)";
            // 
            // textBox_actualVelocL
            // 
            this.textBox_actualVelocL.Location = new System.Drawing.Point(175, 141);
            this.textBox_actualVelocL.Name = "textBox_actualVelocL";
            this.textBox_actualVelocL.ReadOnly = true;
            this.textBox_actualVelocL.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_actualVelocL.Size = new System.Drawing.Size(42, 19);
            this.textBox_actualVelocL.TabIndex = 11;
            this.textBox_actualVelocL.Text = "0.0";
            // 
            // textBox_actualVelocR
            // 
            this.textBox_actualVelocR.Location = new System.Drawing.Point(99, 141);
            this.textBox_actualVelocR.Name = "textBox_actualVelocR";
            this.textBox_actualVelocR.ReadOnly = true;
            this.textBox_actualVelocR.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_actualVelocR.Size = new System.Drawing.Size(42, 19);
            this.textBox_actualVelocR.TabIndex = 9;
            this.textBox_actualVelocR.Text = "0.0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "actualVelocity(R)";
            // 
            // button_setVelocZero
            // 
            this.button_setVelocZero.Location = new System.Drawing.Point(178, 68);
            this.button_setVelocZero.Name = "button_setVelocZero";
            this.button_setVelocZero.Size = new System.Drawing.Size(44, 23);
            this.button_setVelocZero.TabIndex = 7;
            this.button_setVelocZero.Text = "zero";
            this.button_setVelocZero.UseVisualStyleBackColor = true;
            this.button_setVelocZero.Click += new System.EventHandler(this.button_setVelocZero_Click);
            // 
            // button_setVeloc
            // 
            this.button_setVeloc.Location = new System.Drawing.Point(125, 68);
            this.button_setVeloc.Name = "button_setVeloc";
            this.button_setVeloc.Size = new System.Drawing.Size(44, 23);
            this.button_setVeloc.TabIndex = 6;
            this.button_setVeloc.Text = "setV";
            this.button_setVeloc.UseVisualStyleBackColor = true;
            this.button_setVeloc.Click += new System.EventHandler(this.button_setVeloc_Click);
            // 
            // textBox_setDriveVeloc
            // 
            this.textBox_setDriveVeloc.Location = new System.Drawing.Point(73, 70);
            this.textBox_setDriveVeloc.Name = "textBox_setDriveVeloc";
            this.textBox_setDriveVeloc.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox_setDriveVeloc.Size = new System.Drawing.Size(45, 19);
            this.textBox_setDriveVeloc.TabIndex = 5;
            this.textBox_setDriveVeloc.Text = "0.0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "set velocity";
            // 
            // hScrollBar_driveVeloc
            // 
            this.hScrollBar_driveVeloc.AccessibleRole = System.Windows.Forms.AccessibleRole.Slider;
            this.hScrollBar_driveVeloc.Location = new System.Drawing.Point(16, 96);
            this.hScrollBar_driveVeloc.Maximum = 600;
            this.hScrollBar_driveVeloc.Minimum = -300;
            this.hScrollBar_driveVeloc.Name = "hScrollBar_driveVeloc";
            this.hScrollBar_driveVeloc.Size = new System.Drawing.Size(206, 13);
            this.hScrollBar_driveVeloc.TabIndex = 3;
            this.hScrollBar_driveVeloc.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar_driveVeloc_Scroll);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "servo";
            // 
            // button_driveOff
            // 
            this.button_driveOff.Location = new System.Drawing.Point(154, 10);
            this.button_driveOff.Name = "button_driveOff";
            this.button_driveOff.Size = new System.Drawing.Size(63, 23);
            this.button_driveOff.TabIndex = 1;
            this.button_driveOff.Text = "OFF";
            this.button_driveOff.UseVisualStyleBackColor = true;
            this.button_driveOff.Click += new System.EventHandler(this.button_driveOff_Click);
            // 
            // button_driveOn
            // 
            this.button_driveOn.Location = new System.Drawing.Point(85, 10);
            this.button_driveOn.Name = "button_driveOn";
            this.button_driveOn.Size = new System.Drawing.Size(63, 23);
            this.button_driveOn.TabIndex = 0;
            this.button_driveOn.Text = "ON";
            this.button_driveOn.UseVisualStyleBackColor = true;
            this.button_driveOn.Click += new System.EventHandler(this.button_driveOn_Click);
            // 
            // button_GetStatus
            // 
            this.button_GetStatus.Location = new System.Drawing.Point(7, 285);
            this.button_GetStatus.Name = "button_GetStatus";
            this.button_GetStatus.Size = new System.Drawing.Size(79, 23);
            this.button_GetStatus.TabIndex = 28;
            this.button_GetStatus.Text = "GetStatus";
            this.button_GetStatus.UseVisualStyleBackColor = true;
            this.button_GetStatus.Click += new System.EventHandler(this.button_GetStatus_Click);
            // 
            // tabPage_Config
            // 
            this.tabPage_Config.Controls.Add(this.button_manualReactionVGainWrite);
            this.tabPage_Config.Controls.Add(this.button_manualReactionVGainRead);
            this.tabPage_Config.Controls.Add(this.numericUpDown_manualReactVGain);
            this.tabPage_Config.Controls.Add(this.label184);
            this.tabPage_Config.Controls.Add(this.groupBox_rawPedalInput);
            this.tabPage_Config.Controls.Add(this.button_configSave);
            this.tabPage_Config.Controls.Add(this.button_configReadAll);
            this.tabPage_Config.Controls.Add(this.groupBox3);
            this.tabPage_Config.Controls.Add(this.groupBox_driveConfig);
            this.tabPage_Config.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Config.Name = "tabPage_Config";
            this.tabPage_Config.Size = new System.Drawing.Size(733, 518);
            this.tabPage_Config.TabIndex = 10;
            this.tabPage_Config.Text = "Config";
            this.tabPage_Config.UseVisualStyleBackColor = true;
            // 
            // button_manualReactionVGainWrite
            // 
            this.button_manualReactionVGainWrite.Location = new System.Drawing.Point(395, 288);
            this.button_manualReactionVGainWrite.Name = "button_manualReactionVGainWrite";
            this.button_manualReactionVGainWrite.Size = new System.Drawing.Size(36, 23);
            this.button_manualReactionVGainWrite.TabIndex = 43;
            this.button_manualReactionVGainWrite.Text = "write";
            this.button_manualReactionVGainWrite.UseVisualStyleBackColor = true;
            this.button_manualReactionVGainWrite.Click += new System.EventHandler(this.button_manualReactionVGainWrite_Click);
            // 
            // button_manualReactionVGainRead
            // 
            this.button_manualReactionVGainRead.Location = new System.Drawing.Point(353, 288);
            this.button_manualReactionVGainRead.Name = "button_manualReactionVGainRead";
            this.button_manualReactionVGainRead.Size = new System.Drawing.Size(36, 23);
            this.button_manualReactionVGainRead.TabIndex = 42;
            this.button_manualReactionVGainRead.Text = "read";
            this.button_manualReactionVGainRead.UseVisualStyleBackColor = true;
            this.button_manualReactionVGainRead.Click += new System.EventHandler(this.button_manualReactionVGainRead_Click);
            // 
            // numericUpDown_manualReactVGain
            // 
            this.numericUpDown_manualReactVGain.Location = new System.Drawing.Point(265, 291);
            this.numericUpDown_manualReactVGain.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown_manualReactVGain.Minimum = new decimal(new int[] {
            100000,
            0,
            0,
            -2147483648});
            this.numericUpDown_manualReactVGain.Name = "numericUpDown_manualReactVGain";
            this.numericUpDown_manualReactVGain.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_manualReactVGain.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_manualReactVGain.TabIndex = 41;
            this.numericUpDown_manualReactVGain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_manualReactVGain.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // label184
            // 
            this.label184.AutoSize = true;
            this.label184.Location = new System.Drawing.Point(239, 276);
            this.label184.Name = "label184";
            this.label184.Size = new System.Drawing.Size(182, 12);
            this.label184.TabIndex = 40;
            this.label184.Text = "manual reaction Vgain(default:200)";
            // 
            // groupBox_rawPedalInput
            // 
            this.groupBox_rawPedalInput.Controls.Add(this.button_getRawPedal);
            this.groupBox_rawPedalInput.Controls.Add(this.textbox_drivieRawPedalInput);
            this.groupBox_rawPedalInput.Location = new System.Drawing.Point(480, 7);
            this.groupBox_rawPedalInput.Name = "groupBox_rawPedalInput";
            this.groupBox_rawPedalInput.Size = new System.Drawing.Size(179, 46);
            this.groupBox_rawPedalInput.TabIndex = 39;
            this.groupBox_rawPedalInput.TabStop = false;
            this.groupBox_rawPedalInput.Text = "acc raw pedal input";
            // 
            // button_getRawPedal
            // 
            this.button_getRawPedal.Location = new System.Drawing.Point(8, 16);
            this.button_getRawPedal.Name = "button_getRawPedal";
            this.button_getRawPedal.Size = new System.Drawing.Size(85, 23);
            this.button_getRawPedal.TabIndex = 36;
            this.button_getRawPedal.Text = "GetRawPedal";
            this.button_getRawPedal.UseVisualStyleBackColor = true;
            this.button_getRawPedal.Click += new System.EventHandler(this.button_getRawPedal_Click);
            // 
            // textbox_drivieRawPedalInput
            // 
            this.textbox_drivieRawPedalInput.Location = new System.Drawing.Point(108, 18);
            this.textbox_drivieRawPedalInput.Name = "textbox_drivieRawPedalInput";
            this.textbox_drivieRawPedalInput.ReadOnly = true;
            this.textbox_drivieRawPedalInput.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textbox_drivieRawPedalInput.Size = new System.Drawing.Size(59, 19);
            this.textbox_drivieRawPedalInput.TabIndex = 37;
            // 
            // button_configSave
            // 
            this.button_configSave.Location = new System.Drawing.Point(86, 426);
            this.button_configSave.Name = "button_configSave";
            this.button_configSave.Size = new System.Drawing.Size(55, 23);
            this.button_configSave.TabIndex = 34;
            this.button_configSave.Text = "save";
            this.button_configSave.UseVisualStyleBackColor = true;
            this.button_configSave.Click += new System.EventHandler(this.button_configSave_Click);
            // 
            // button_configReadAll
            // 
            this.button_configReadAll.Location = new System.Drawing.Point(17, 426);
            this.button_configReadAll.Name = "button_configReadAll";
            this.button_configReadAll.Size = new System.Drawing.Size(55, 23);
            this.button_configReadAll.TabIndex = 33;
            this.button_configReadAll.Text = "readAll";
            this.button_configReadAll.UseVisualStyleBackColor = true;
            this.button_configReadAll.Click += new System.EventHandler(this.button_configReadAll_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button_steerOffsetWrite);
            this.groupBox3.Controls.Add(this.button_manualLockTorqueWrite);
            this.groupBox3.Controls.Add(this.button_steerOffsetRead);
            this.groupBox3.Controls.Add(this.button_manualLockTorqueRead);
            this.groupBox3.Controls.Add(this.button_reactOffsetWrite);
            this.groupBox3.Controls.Add(this.comboBox_steerKeepAlive);
            this.groupBox3.Controls.Add(this.numericUpDown_steerOffset);
            this.groupBox3.Controls.Add(this.label57);
            this.groupBox3.Controls.Add(this.numericUpDown_manualLockTorque);
            this.groupBox3.Controls.Add(this.button_steerKeepAliveRead);
            this.groupBox3.Controls.Add(this.button_steerKeepAliveWrite);
            this.groupBox3.Controls.Add(this.button_reactOffsetRead);
            this.groupBox3.Controls.Add(this.label180);
            this.groupBox3.Controls.Add(this.label181);
            this.groupBox3.Controls.Add(this.numericUpDown_reactionOffset);
            this.groupBox3.Controls.Add(this.label183);
            this.groupBox3.Controls.Add(this.button_manualRatioWrite);
            this.groupBox3.Controls.Add(this.button_manualRatioRead);
            this.groupBox3.Controls.Add(this.numericUpDown_manualRatio);
            this.groupBox3.Controls.Add(this.label182);
            this.groupBox3.Controls.Add(this.button_manualReactionGainWrite);
            this.groupBox3.Controls.Add(this.button_manualReactionGainRead);
            this.groupBox3.Controls.Add(this.button_manualSteerGainWrite);
            this.groupBox3.Controls.Add(this.button_manualSteerGainRead);
            this.groupBox3.Controls.Add(this.button_manualSteerVelocWrite);
            this.groupBox3.Controls.Add(this.button_manualSteerVelocRead);
            this.groupBox3.Controls.Add(this.button_reactVelocWrite);
            this.groupBox3.Controls.Add(this.button_reactVelocRead);
            this.groupBox3.Controls.Add(this.button_reactAccWrite);
            this.groupBox3.Controls.Add(this.button_reactAccRead);
            this.groupBox3.Controls.Add(this.button_steerGainWrite);
            this.groupBox3.Controls.Add(this.button_steerVelocWrite);
            this.groupBox3.Controls.Add(this.button_steerGainRead);
            this.groupBox3.Controls.Add(this.button_steerVelocRead);
            this.groupBox3.Controls.Add(this.numericUpDown_manualReactGain);
            this.groupBox3.Controls.Add(this.numericUpDown_manualSteerGain);
            this.groupBox3.Controls.Add(this.numericUpDown_manualSteerVeloc);
            this.groupBox3.Controls.Add(this.numericUpDown_reactVeloc);
            this.groupBox3.Controls.Add(this.numericUpDown_reactAcc);
            this.groupBox3.Controls.Add(this.numericUpDown_steerGain);
            this.groupBox3.Controls.Add(this.numericUpDown_steerVeloc);
            this.groupBox3.Controls.Add(this.label58);
            this.groupBox3.Controls.Add(this.label59);
            this.groupBox3.Controls.Add(this.label60);
            this.groupBox3.Controls.Add(this.label61);
            this.groupBox3.Controls.Add(this.label62);
            this.groupBox3.Controls.Add(this.label63);
            this.groupBox3.Controls.Add(this.label64);
            this.groupBox3.Location = new System.Drawing.Point(233, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(241, 508);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "steer config";
            // 
            // button_steerOffsetWrite
            // 
            this.button_steerOffsetWrite.Location = new System.Drawing.Point(162, 400);
            this.button_steerOffsetWrite.Name = "button_steerOffsetWrite";
            this.button_steerOffsetWrite.Size = new System.Drawing.Size(36, 23);
            this.button_steerOffsetWrite.TabIndex = 43;
            this.button_steerOffsetWrite.Text = "write";
            this.button_steerOffsetWrite.UseVisualStyleBackColor = true;
            this.button_steerOffsetWrite.Click += new System.EventHandler(this.button_steerOffsetWrite_Click);
            // 
            // button_manualLockTorqueWrite
            // 
            this.button_manualLockTorqueWrite.Location = new System.Drawing.Point(162, 361);
            this.button_manualLockTorqueWrite.Name = "button_manualLockTorqueWrite";
            this.button_manualLockTorqueWrite.Size = new System.Drawing.Size(36, 23);
            this.button_manualLockTorqueWrite.TabIndex = 55;
            this.button_manualLockTorqueWrite.Text = "write";
            this.button_manualLockTorqueWrite.UseVisualStyleBackColor = true;
            this.button_manualLockTorqueWrite.Click += new System.EventHandler(this.button_manualLockTorqueWrite_Click);
            // 
            // button_steerOffsetRead
            // 
            this.button_steerOffsetRead.Location = new System.Drawing.Point(120, 400);
            this.button_steerOffsetRead.Name = "button_steerOffsetRead";
            this.button_steerOffsetRead.Size = new System.Drawing.Size(36, 23);
            this.button_steerOffsetRead.TabIndex = 42;
            this.button_steerOffsetRead.Text = "read";
            this.button_steerOffsetRead.UseVisualStyleBackColor = true;
            this.button_steerOffsetRead.Click += new System.EventHandler(this.button_steerOffsetRead_Click);
            // 
            // button_manualLockTorqueRead
            // 
            this.button_manualLockTorqueRead.Location = new System.Drawing.Point(120, 361);
            this.button_manualLockTorqueRead.Name = "button_manualLockTorqueRead";
            this.button_manualLockTorqueRead.Size = new System.Drawing.Size(36, 23);
            this.button_manualLockTorqueRead.TabIndex = 54;
            this.button_manualLockTorqueRead.Text = "read";
            this.button_manualLockTorqueRead.UseVisualStyleBackColor = true;
            this.button_manualLockTorqueRead.Click += new System.EventHandler(this.button_manualLockTorqueRead_Click);
            // 
            // button_reactOffsetWrite
            // 
            this.button_reactOffsetWrite.Location = new System.Drawing.Point(162, 440);
            this.button_reactOffsetWrite.Name = "button_reactOffsetWrite";
            this.button_reactOffsetWrite.Size = new System.Drawing.Size(36, 23);
            this.button_reactOffsetWrite.TabIndex = 47;
            this.button_reactOffsetWrite.Text = "write";
            this.button_reactOffsetWrite.UseVisualStyleBackColor = true;
            this.button_reactOffsetWrite.Click += new System.EventHandler(this.button_reactOffsetWrite_Click);
            // 
            // comboBox_steerKeepAlive
            // 
            this.comboBox_steerKeepAlive.FormattingEnabled = true;
            this.comboBox_steerKeepAlive.Items.AddRange(new object[] {
            "disable",
            "SteerControl"});
            this.comboBox_steerKeepAlive.Location = new System.Drawing.Point(32, 480);
            this.comboBox_steerKeepAlive.Name = "comboBox_steerKeepAlive";
            this.comboBox_steerKeepAlive.Size = new System.Drawing.Size(67, 20);
            this.comboBox_steerKeepAlive.TabIndex = 34;
            // 
            // numericUpDown_steerOffset
            // 
            this.numericUpDown_steerOffset.Location = new System.Drawing.Point(32, 403);
            this.numericUpDown_steerOffset.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown_steerOffset.Minimum = new decimal(new int[] {
            100000,
            0,
            0,
            -2147483648});
            this.numericUpDown_steerOffset.Name = "numericUpDown_steerOffset";
            this.numericUpDown_steerOffset.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_steerOffset.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_steerOffset.TabIndex = 41;
            this.numericUpDown_steerOffset.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(6, 466);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(143, 12);
            this.label57.TabIndex = 7;
            this.label57.Text = "keep alive param(default:0)";
            // 
            // numericUpDown_manualLockTorque
            // 
            this.numericUpDown_manualLockTorque.Location = new System.Drawing.Point(32, 364);
            this.numericUpDown_manualLockTorque.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown_manualLockTorque.Minimum = new decimal(new int[] {
            100000,
            0,
            0,
            -2147483648});
            this.numericUpDown_manualLockTorque.Name = "numericUpDown_manualLockTorque";
            this.numericUpDown_manualLockTorque.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_manualLockTorque.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_manualLockTorque.TabIndex = 53;
            this.numericUpDown_manualLockTorque.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_manualLockTorque.Value = new decimal(new int[] {
            300,
            0,
            0,
            0});
            // 
            // button_steerKeepAliveRead
            // 
            this.button_steerKeepAliveRead.Location = new System.Drawing.Point(120, 478);
            this.button_steerKeepAliveRead.Name = "button_steerKeepAliveRead";
            this.button_steerKeepAliveRead.Size = new System.Drawing.Size(36, 23);
            this.button_steerKeepAliveRead.TabIndex = 32;
            this.button_steerKeepAliveRead.Text = "read";
            this.button_steerKeepAliveRead.UseVisualStyleBackColor = true;
            this.button_steerKeepAliveRead.Click += new System.EventHandler(this.button_steerKeepAliveRead_Click);
            // 
            // button_steerKeepAliveWrite
            // 
            this.button_steerKeepAliveWrite.Location = new System.Drawing.Point(162, 478);
            this.button_steerKeepAliveWrite.Name = "button_steerKeepAliveWrite";
            this.button_steerKeepAliveWrite.Size = new System.Drawing.Size(36, 23);
            this.button_steerKeepAliveWrite.TabIndex = 33;
            this.button_steerKeepAliveWrite.Text = "write";
            this.button_steerKeepAliveWrite.UseVisualStyleBackColor = true;
            this.button_steerKeepAliveWrite.Click += new System.EventHandler(this.button_steerKeepAliveWrite_Click);
            // 
            // button_reactOffsetRead
            // 
            this.button_reactOffsetRead.Location = new System.Drawing.Point(120, 440);
            this.button_reactOffsetRead.Name = "button_reactOffsetRead";
            this.button_reactOffsetRead.Size = new System.Drawing.Size(36, 23);
            this.button_reactOffsetRead.TabIndex = 46;
            this.button_reactOffsetRead.Text = "read";
            this.button_reactOffsetRead.UseVisualStyleBackColor = true;
            this.button_reactOffsetRead.Click += new System.EventHandler(this.button_reactOffsetRead_Click);
            // 
            // label180
            // 
            this.label180.AutoSize = true;
            this.label180.Location = new System.Drawing.Point(6, 388);
            this.label180.Name = "label180";
            this.label180.Size = new System.Drawing.Size(178, 12);
            this.label180.TabIndex = 40;
            this.label180.Text = "steer offset(1=0.01[deg] default:0)";
            // 
            // label181
            // 
            this.label181.AutoSize = true;
            this.label181.Location = new System.Drawing.Point(6, 428);
            this.label181.Name = "label181";
            this.label181.Size = new System.Drawing.Size(193, 12);
            this.label181.TabIndex = 44;
            this.label181.Text = "reaction offset(1=0.01[deg] default:0)";
            // 
            // numericUpDown_reactionOffset
            // 
            this.numericUpDown_reactionOffset.Location = new System.Drawing.Point(32, 443);
            this.numericUpDown_reactionOffset.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown_reactionOffset.Minimum = new decimal(new int[] {
            100000,
            0,
            0,
            -2147483648});
            this.numericUpDown_reactionOffset.Name = "numericUpDown_reactionOffset";
            this.numericUpDown_reactionOffset.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_reactionOffset.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_reactionOffset.TabIndex = 45;
            this.numericUpDown_reactionOffset.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label183
            // 
            this.label183.AutoSize = true;
            this.label183.Location = new System.Drawing.Point(6, 349);
            this.label183.Name = "label183";
            this.label183.Size = new System.Drawing.Size(207, 12);
            this.label183.TabIndex = 52;
            this.label183.Text = "manual lock torque(1=0.001 default:300)";
            // 
            // button_manualRatioWrite
            // 
            this.button_manualRatioWrite.Location = new System.Drawing.Point(162, 323);
            this.button_manualRatioWrite.Name = "button_manualRatioWrite";
            this.button_manualRatioWrite.Size = new System.Drawing.Size(36, 23);
            this.button_manualRatioWrite.TabIndex = 51;
            this.button_manualRatioWrite.Text = "write";
            this.button_manualRatioWrite.UseVisualStyleBackColor = true;
            this.button_manualRatioWrite.Click += new System.EventHandler(this.button_manualRatioWrite_Click);
            // 
            // button_manualRatioRead
            // 
            this.button_manualRatioRead.Location = new System.Drawing.Point(120, 323);
            this.button_manualRatioRead.Name = "button_manualRatioRead";
            this.button_manualRatioRead.Size = new System.Drawing.Size(36, 23);
            this.button_manualRatioRead.TabIndex = 50;
            this.button_manualRatioRead.Text = "read";
            this.button_manualRatioRead.UseVisualStyleBackColor = true;
            this.button_manualRatioRead.Click += new System.EventHandler(this.button_manualRatioRead_Click);
            // 
            // numericUpDown_manualRatio
            // 
            this.numericUpDown_manualRatio.Location = new System.Drawing.Point(32, 326);
            this.numericUpDown_manualRatio.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown_manualRatio.Minimum = new decimal(new int[] {
            100000,
            0,
            0,
            -2147483648});
            this.numericUpDown_manualRatio.Name = "numericUpDown_manualRatio";
            this.numericUpDown_manualRatio.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_manualRatio.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_manualRatio.TabIndex = 49;
            this.numericUpDown_manualRatio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_manualRatio.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // label182
            // 
            this.label182.AutoSize = true;
            this.label182.Location = new System.Drawing.Point(6, 311);
            this.label182.Name = "label182";
            this.label182.Size = new System.Drawing.Size(179, 12);
            this.label182.TabIndex = 48;
            this.label182.Text = "manual ratio(1=0.001 default:1000)";
            // 
            // button_manualReactionGainWrite
            // 
            this.button_manualReactionGainWrite.Location = new System.Drawing.Point(162, 249);
            this.button_manualReactionGainWrite.Name = "button_manualReactionGainWrite";
            this.button_manualReactionGainWrite.Size = new System.Drawing.Size(36, 23);
            this.button_manualReactionGainWrite.TabIndex = 31;
            this.button_manualReactionGainWrite.Text = "write";
            this.button_manualReactionGainWrite.UseVisualStyleBackColor = true;
            this.button_manualReactionGainWrite.Click += new System.EventHandler(this.button_manualReactionGainWrite_Click);
            // 
            // button_manualReactionGainRead
            // 
            this.button_manualReactionGainRead.Location = new System.Drawing.Point(120, 249);
            this.button_manualReactionGainRead.Name = "button_manualReactionGainRead";
            this.button_manualReactionGainRead.Size = new System.Drawing.Size(36, 23);
            this.button_manualReactionGainRead.TabIndex = 30;
            this.button_manualReactionGainRead.Text = "read";
            this.button_manualReactionGainRead.UseVisualStyleBackColor = true;
            this.button_manualReactionGainRead.Click += new System.EventHandler(this.button_manualReactionGainRead_Click);
            // 
            // button_manualSteerGainWrite
            // 
            this.button_manualSteerGainWrite.Location = new System.Drawing.Point(162, 211);
            this.button_manualSteerGainWrite.Name = "button_manualSteerGainWrite";
            this.button_manualSteerGainWrite.Size = new System.Drawing.Size(36, 23);
            this.button_manualSteerGainWrite.TabIndex = 29;
            this.button_manualSteerGainWrite.Text = "write";
            this.button_manualSteerGainWrite.UseVisualStyleBackColor = true;
            this.button_manualSteerGainWrite.Click += new System.EventHandler(this.button_manualSteerGainWrite_Click);
            // 
            // button_manualSteerGainRead
            // 
            this.button_manualSteerGainRead.Location = new System.Drawing.Point(120, 211);
            this.button_manualSteerGainRead.Name = "button_manualSteerGainRead";
            this.button_manualSteerGainRead.Size = new System.Drawing.Size(36, 23);
            this.button_manualSteerGainRead.TabIndex = 28;
            this.button_manualSteerGainRead.Text = "read";
            this.button_manualSteerGainRead.UseVisualStyleBackColor = true;
            this.button_manualSteerGainRead.Click += new System.EventHandler(this.button_manualSteerGainRead_Click);
            // 
            // button_manualSteerVelocWrite
            // 
            this.button_manualSteerVelocWrite.Location = new System.Drawing.Point(162, 175);
            this.button_manualSteerVelocWrite.Name = "button_manualSteerVelocWrite";
            this.button_manualSteerVelocWrite.Size = new System.Drawing.Size(36, 23);
            this.button_manualSteerVelocWrite.TabIndex = 27;
            this.button_manualSteerVelocWrite.Text = "write";
            this.button_manualSteerVelocWrite.UseVisualStyleBackColor = true;
            this.button_manualSteerVelocWrite.Click += new System.EventHandler(this.button_manualSteerVelocWrite_Click);
            // 
            // button_manualSteerVelocRead
            // 
            this.button_manualSteerVelocRead.Location = new System.Drawing.Point(120, 175);
            this.button_manualSteerVelocRead.Name = "button_manualSteerVelocRead";
            this.button_manualSteerVelocRead.Size = new System.Drawing.Size(36, 23);
            this.button_manualSteerVelocRead.TabIndex = 26;
            this.button_manualSteerVelocRead.Text = "read";
            this.button_manualSteerVelocRead.UseVisualStyleBackColor = true;
            this.button_manualSteerVelocRead.Click += new System.EventHandler(this.button_manualSteerVelocRead_Click);
            // 
            // button_reactVelocWrite
            // 
            this.button_reactVelocWrite.Location = new System.Drawing.Point(162, 137);
            this.button_reactVelocWrite.Name = "button_reactVelocWrite";
            this.button_reactVelocWrite.Size = new System.Drawing.Size(36, 23);
            this.button_reactVelocWrite.TabIndex = 25;
            this.button_reactVelocWrite.Text = "write";
            this.button_reactVelocWrite.UseVisualStyleBackColor = true;
            this.button_reactVelocWrite.Click += new System.EventHandler(this.button_reactVelocWrite_Click);
            // 
            // button_reactVelocRead
            // 
            this.button_reactVelocRead.Location = new System.Drawing.Point(120, 137);
            this.button_reactVelocRead.Name = "button_reactVelocRead";
            this.button_reactVelocRead.Size = new System.Drawing.Size(36, 23);
            this.button_reactVelocRead.TabIndex = 24;
            this.button_reactVelocRead.Text = "read";
            this.button_reactVelocRead.UseVisualStyleBackColor = true;
            this.button_reactVelocRead.Click += new System.EventHandler(this.button_reactVelocRead_Click);
            // 
            // button_reactAccWrite
            // 
            this.button_reactAccWrite.Location = new System.Drawing.Point(162, 100);
            this.button_reactAccWrite.Name = "button_reactAccWrite";
            this.button_reactAccWrite.Size = new System.Drawing.Size(36, 23);
            this.button_reactAccWrite.TabIndex = 23;
            this.button_reactAccWrite.Text = "write";
            this.button_reactAccWrite.UseVisualStyleBackColor = true;
            this.button_reactAccWrite.Click += new System.EventHandler(this.button_reactAccWrite_Click);
            // 
            // button_reactAccRead
            // 
            this.button_reactAccRead.Location = new System.Drawing.Point(120, 100);
            this.button_reactAccRead.Name = "button_reactAccRead";
            this.button_reactAccRead.Size = new System.Drawing.Size(36, 23);
            this.button_reactAccRead.TabIndex = 22;
            this.button_reactAccRead.Text = "read";
            this.button_reactAccRead.UseVisualStyleBackColor = true;
            this.button_reactAccRead.Click += new System.EventHandler(this.button_reactAccRead_Click);
            // 
            // button_steerGainWrite
            // 
            this.button_steerGainWrite.Location = new System.Drawing.Point(162, 63);
            this.button_steerGainWrite.Name = "button_steerGainWrite";
            this.button_steerGainWrite.Size = new System.Drawing.Size(36, 23);
            this.button_steerGainWrite.TabIndex = 21;
            this.button_steerGainWrite.Text = "write";
            this.button_steerGainWrite.UseVisualStyleBackColor = true;
            this.button_steerGainWrite.Click += new System.EventHandler(this.button_steerGainWrite_Click);
            // 
            // button_steerVelocWrite
            // 
            this.button_steerVelocWrite.Location = new System.Drawing.Point(162, 27);
            this.button_steerVelocWrite.Name = "button_steerVelocWrite";
            this.button_steerVelocWrite.Size = new System.Drawing.Size(36, 23);
            this.button_steerVelocWrite.TabIndex = 19;
            this.button_steerVelocWrite.Text = "write";
            this.button_steerVelocWrite.UseVisualStyleBackColor = true;
            this.button_steerVelocWrite.Click += new System.EventHandler(this.button_steerVelocWrite_Click);
            // 
            // button_steerGainRead
            // 
            this.button_steerGainRead.Location = new System.Drawing.Point(120, 63);
            this.button_steerGainRead.Name = "button_steerGainRead";
            this.button_steerGainRead.Size = new System.Drawing.Size(36, 23);
            this.button_steerGainRead.TabIndex = 20;
            this.button_steerGainRead.Text = "read";
            this.button_steerGainRead.UseVisualStyleBackColor = true;
            this.button_steerGainRead.Click += new System.EventHandler(this.button_steerGainRead_Click);
            // 
            // button_steerVelocRead
            // 
            this.button_steerVelocRead.Location = new System.Drawing.Point(120, 27);
            this.button_steerVelocRead.Name = "button_steerVelocRead";
            this.button_steerVelocRead.Size = new System.Drawing.Size(36, 23);
            this.button_steerVelocRead.TabIndex = 18;
            this.button_steerVelocRead.Text = "read";
            this.button_steerVelocRead.UseVisualStyleBackColor = true;
            this.button_steerVelocRead.Click += new System.EventHandler(this.button_steerVelocRead_Click);
            // 
            // numericUpDown_manualReactGain
            // 
            this.numericUpDown_manualReactGain.Location = new System.Drawing.Point(32, 252);
            this.numericUpDown_manualReactGain.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown_manualReactGain.Minimum = new decimal(new int[] {
            100000,
            0,
            0,
            -2147483648});
            this.numericUpDown_manualReactGain.Name = "numericUpDown_manualReactGain";
            this.numericUpDown_manualReactGain.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_manualReactGain.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_manualReactGain.TabIndex = 15;
            this.numericUpDown_manualReactGain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_manualReactGain.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // numericUpDown_manualSteerGain
            // 
            this.numericUpDown_manualSteerGain.Location = new System.Drawing.Point(32, 215);
            this.numericUpDown_manualSteerGain.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown_manualSteerGain.Minimum = new decimal(new int[] {
            100000,
            0,
            0,
            -2147483648});
            this.numericUpDown_manualSteerGain.Name = "numericUpDown_manualSteerGain";
            this.numericUpDown_manualSteerGain.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_manualSteerGain.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_manualSteerGain.TabIndex = 14;
            this.numericUpDown_manualSteerGain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_manualSteerGain.Value = new decimal(new int[] {
            3000,
            0,
            0,
            0});
            // 
            // numericUpDown_manualSteerVeloc
            // 
            this.numericUpDown_manualSteerVeloc.Location = new System.Drawing.Point(32, 178);
            this.numericUpDown_manualSteerVeloc.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown_manualSteerVeloc.Minimum = new decimal(new int[] {
            100000,
            0,
            0,
            -2147483648});
            this.numericUpDown_manualSteerVeloc.Name = "numericUpDown_manualSteerVeloc";
            this.numericUpDown_manualSteerVeloc.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_manualSteerVeloc.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_manualSteerVeloc.TabIndex = 13;
            this.numericUpDown_manualSteerVeloc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_manualSteerVeloc.Value = new decimal(new int[] {
            3600,
            0,
            0,
            0});
            // 
            // numericUpDown_reactVeloc
            // 
            this.numericUpDown_reactVeloc.Location = new System.Drawing.Point(32, 141);
            this.numericUpDown_reactVeloc.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown_reactVeloc.Minimum = new decimal(new int[] {
            100000,
            0,
            0,
            -2147483648});
            this.numericUpDown_reactVeloc.Name = "numericUpDown_reactVeloc";
            this.numericUpDown_reactVeloc.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_reactVeloc.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_reactVeloc.TabIndex = 12;
            this.numericUpDown_reactVeloc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_reactVeloc.Value = new decimal(new int[] {
            3600,
            0,
            0,
            0});
            // 
            // numericUpDown_reactAcc
            // 
            this.numericUpDown_reactAcc.Location = new System.Drawing.Point(32, 104);
            this.numericUpDown_reactAcc.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown_reactAcc.Minimum = new decimal(new int[] {
            100000,
            0,
            0,
            -2147483648});
            this.numericUpDown_reactAcc.Name = "numericUpDown_reactAcc";
            this.numericUpDown_reactAcc.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_reactAcc.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_reactAcc.TabIndex = 11;
            this.numericUpDown_reactAcc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_reactAcc.Value = new decimal(new int[] {
            1800,
            0,
            0,
            0});
            // 
            // numericUpDown_steerGain
            // 
            this.numericUpDown_steerGain.Location = new System.Drawing.Point(32, 67);
            this.numericUpDown_steerGain.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown_steerGain.Minimum = new decimal(new int[] {
            100000,
            0,
            0,
            -2147483648});
            this.numericUpDown_steerGain.Name = "numericUpDown_steerGain";
            this.numericUpDown_steerGain.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_steerGain.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_steerGain.TabIndex = 10;
            this.numericUpDown_steerGain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_steerGain.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // numericUpDown_steerVeloc
            // 
            this.numericUpDown_steerVeloc.Location = new System.Drawing.Point(32, 30);
            this.numericUpDown_steerVeloc.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown_steerVeloc.Minimum = new decimal(new int[] {
            100000,
            0,
            0,
            -2147483648});
            this.numericUpDown_steerVeloc.Name = "numericUpDown_steerVeloc";
            this.numericUpDown_steerVeloc.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_steerVeloc.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_steerVeloc.TabIndex = 9;
            this.numericUpDown_steerVeloc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_steerVeloc.Value = new decimal(new int[] {
            1800,
            0,
            0,
            0});
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(6, 237);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(180, 12);
            this.label58.TabIndex = 6;
            this.label58.Text = "manual reaction gain(default:1000)";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(6, 200);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(165, 12);
            this.label59.TabIndex = 5;
            this.label59.Text = "manual steer gain(default:3000)";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(6, 163);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(234, 12);
            this.label60.TabIndex = 4;
            this.label60.Text = "manual steer velocity(default:3600[deg/sec])";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(6, 126);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(209, 12);
            this.label61.TabIndex = 3;
            this.label61.Text = "reaction velocity(default:3600[deg/sec])";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(6, 89);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(193, 12);
            this.label62.TabIndex = 2;
            this.label62.Text = "reaction acc(default:1800[deg/sec2])";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(6, 52);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(125, 12);
            this.label63.TabIndex = 1;
            this.label63.Text = "steer gain(default:1000)";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(6, 15);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(194, 12);
            this.label64.TabIndex = 0;
            this.label64.Text = "steer velocity(default:1800[deg/sec])";
            // 
            // groupBox_driveConfig
            // 
            this.groupBox_driveConfig.Controls.Add(this.numericUpDown_hostIntervalLimit);
            this.groupBox_driveConfig.Controls.Add(this.button_driveKeepAliveWrite);
            this.groupBox_driveConfig.Controls.Add(this.button_driveKeepAliveRead);
            this.groupBox_driveConfig.Controls.Add(this.button_hostIntervalLimitWrite);
            this.groupBox_driveConfig.Controls.Add(this.button_accRawMinWrite);
            this.groupBox_driveConfig.Controls.Add(this.button_accRawMinRead);
            this.groupBox_driveConfig.Controls.Add(this.button_hostIntervalLimitRead);
            this.groupBox_driveConfig.Controls.Add(this.label179);
            this.groupBox_driveConfig.Controls.Add(this.button_accRawMaxWrite);
            this.groupBox_driveConfig.Controls.Add(this.button_accRawMaxRead);
            this.groupBox_driveConfig.Controls.Add(this.button_driveLimitSUMWrite);
            this.groupBox_driveConfig.Controls.Add(this.button_driveLimitSUMRead);
            this.groupBox_driveConfig.Controls.Add(this.button_driveTorqueLimitWrite);
            this.groupBox_driveConfig.Controls.Add(this.button_driveTorqueLimitRead);
            this.groupBox_driveConfig.Controls.Add(this.button_driveVelocLimitWrite);
            this.groupBox_driveConfig.Controls.Add(this.button_driveVelocLimitRead);
            this.groupBox_driveConfig.Controls.Add(this.button_velocDGainWrite);
            this.groupBox_driveConfig.Controls.Add(this.button_velocDGainRead);
            this.groupBox_driveConfig.Controls.Add(this.button_velocIGainWrite);
            this.groupBox_driveConfig.Controls.Add(this.button_velocPGainWrite);
            this.groupBox_driveConfig.Controls.Add(this.button_velocIGainRead);
            this.groupBox_driveConfig.Controls.Add(this.button_velocPGainRead);
            this.groupBox_driveConfig.Controls.Add(this.comboBox_driveKeepAlive);
            this.groupBox_driveConfig.Controls.Add(this.numericUpDown_accRawMin);
            this.groupBox_driveConfig.Controls.Add(this.numericUpDown_accRawMax);
            this.groupBox_driveConfig.Controls.Add(this.numericUpDown_SUMLimit);
            this.groupBox_driveConfig.Controls.Add(this.numericUpDown_driveTorqueLimit);
            this.groupBox_driveConfig.Controls.Add(this.numericUpDown_velocLimit);
            this.groupBox_driveConfig.Controls.Add(this.numericUpDown_velocDgain);
            this.groupBox_driveConfig.Controls.Add(this.numericUpDown_velocIgain);
            this.groupBox_driveConfig.Controls.Add(this.numericUpDown_velocPgain);
            this.groupBox_driveConfig.Controls.Add(this.label55);
            this.groupBox_driveConfig.Controls.Add(this.label54);
            this.groupBox_driveConfig.Controls.Add(this.label53);
            this.groupBox_driveConfig.Controls.Add(this.label52);
            this.groupBox_driveConfig.Controls.Add(this.label51);
            this.groupBox_driveConfig.Controls.Add(this.label50);
            this.groupBox_driveConfig.Controls.Add(this.label49);
            this.groupBox_driveConfig.Controls.Add(this.label48);
            this.groupBox_driveConfig.Controls.Add(this.label47);
            this.groupBox_driveConfig.Location = new System.Drawing.Point(7, 3);
            this.groupBox_driveConfig.Name = "groupBox_driveConfig";
            this.groupBox_driveConfig.Size = new System.Drawing.Size(211, 410);
            this.groupBox_driveConfig.TabIndex = 0;
            this.groupBox_driveConfig.TabStop = false;
            this.groupBox_driveConfig.Text = "drive config";
            // 
            // numericUpDown_hostIntervalLimit
            // 
            this.numericUpDown_hostIntervalLimit.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown_hostIntervalLimit.Location = new System.Drawing.Point(32, 332);
            this.numericUpDown_hostIntervalLimit.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.numericUpDown_hostIntervalLimit.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.numericUpDown_hostIntervalLimit.Name = "numericUpDown_hostIntervalLimit";
            this.numericUpDown_hostIntervalLimit.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_hostIntervalLimit.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_hostIntervalLimit.TabIndex = 40;
            this.numericUpDown_hostIntervalLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_hostIntervalLimit.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // button_driveKeepAliveWrite
            // 
            this.button_driveKeepAliveWrite.Location = new System.Drawing.Point(162, 378);
            this.button_driveKeepAliveWrite.Name = "button_driveKeepAliveWrite";
            this.button_driveKeepAliveWrite.Size = new System.Drawing.Size(36, 23);
            this.button_driveKeepAliveWrite.TabIndex = 35;
            this.button_driveKeepAliveWrite.Text = "write";
            this.button_driveKeepAliveWrite.UseVisualStyleBackColor = true;
            this.button_driveKeepAliveWrite.Click += new System.EventHandler(this.button_driveKeepAliveWrite_Click);
            // 
            // button_driveKeepAliveRead
            // 
            this.button_driveKeepAliveRead.Location = new System.Drawing.Point(120, 378);
            this.button_driveKeepAliveRead.Name = "button_driveKeepAliveRead";
            this.button_driveKeepAliveRead.Size = new System.Drawing.Size(36, 23);
            this.button_driveKeepAliveRead.TabIndex = 34;
            this.button_driveKeepAliveRead.Text = "read";
            this.button_driveKeepAliveRead.UseVisualStyleBackColor = true;
            this.button_driveKeepAliveRead.Click += new System.EventHandler(this.button_driveKeepAliveRead_Click);
            // 
            // button_hostIntervalLimitWrite
            // 
            this.button_hostIntervalLimitWrite.Location = new System.Drawing.Point(162, 328);
            this.button_hostIntervalLimitWrite.Name = "button_hostIntervalLimitWrite";
            this.button_hostIntervalLimitWrite.Size = new System.Drawing.Size(36, 23);
            this.button_hostIntervalLimitWrite.TabIndex = 39;
            this.button_hostIntervalLimitWrite.Text = "write";
            this.button_hostIntervalLimitWrite.UseVisualStyleBackColor = true;
            this.button_hostIntervalLimitWrite.Click += new System.EventHandler(this.button_hostIntervalLimitWrite_Click);
            // 
            // button_accRawMinWrite
            // 
            this.button_accRawMinWrite.Location = new System.Drawing.Point(162, 286);
            this.button_accRawMinWrite.Name = "button_accRawMinWrite";
            this.button_accRawMinWrite.Size = new System.Drawing.Size(36, 23);
            this.button_accRawMinWrite.TabIndex = 33;
            this.button_accRawMinWrite.Text = "write";
            this.button_accRawMinWrite.UseVisualStyleBackColor = true;
            this.button_accRawMinWrite.Click += new System.EventHandler(this.button_accRawMinWrite_Click);
            // 
            // button_accRawMinRead
            // 
            this.button_accRawMinRead.Location = new System.Drawing.Point(120, 286);
            this.button_accRawMinRead.Name = "button_accRawMinRead";
            this.button_accRawMinRead.Size = new System.Drawing.Size(36, 23);
            this.button_accRawMinRead.TabIndex = 32;
            this.button_accRawMinRead.Text = "read";
            this.button_accRawMinRead.UseVisualStyleBackColor = true;
            this.button_accRawMinRead.Click += new System.EventHandler(this.button_accRawMinRead_Click);
            // 
            // button_hostIntervalLimitRead
            // 
            this.button_hostIntervalLimitRead.Location = new System.Drawing.Point(120, 328);
            this.button_hostIntervalLimitRead.Name = "button_hostIntervalLimitRead";
            this.button_hostIntervalLimitRead.Size = new System.Drawing.Size(36, 23);
            this.button_hostIntervalLimitRead.TabIndex = 38;
            this.button_hostIntervalLimitRead.Text = "read";
            this.button_hostIntervalLimitRead.UseVisualStyleBackColor = true;
            this.button_hostIntervalLimitRead.Click += new System.EventHandler(this.button_hostIntervalLimitRead_Click);
            // 
            // label179
            // 
            this.label179.AutoSize = true;
            this.label179.Location = new System.Drawing.Point(6, 313);
            this.label179.Name = "label179";
            this.label179.Size = new System.Drawing.Size(158, 12);
            this.label179.TabIndex = 36;
            this.label179.Text = "host interval limit(default:100)";
            // 
            // button_accRawMaxWrite
            // 
            this.button_accRawMaxWrite.Location = new System.Drawing.Point(162, 249);
            this.button_accRawMaxWrite.Name = "button_accRawMaxWrite";
            this.button_accRawMaxWrite.Size = new System.Drawing.Size(36, 23);
            this.button_accRawMaxWrite.TabIndex = 31;
            this.button_accRawMaxWrite.Text = "write";
            this.button_accRawMaxWrite.UseVisualStyleBackColor = true;
            this.button_accRawMaxWrite.Click += new System.EventHandler(this.button_accRawMaxWrite_Click);
            // 
            // button_accRawMaxRead
            // 
            this.button_accRawMaxRead.Location = new System.Drawing.Point(120, 249);
            this.button_accRawMaxRead.Name = "button_accRawMaxRead";
            this.button_accRawMaxRead.Size = new System.Drawing.Size(36, 23);
            this.button_accRawMaxRead.TabIndex = 30;
            this.button_accRawMaxRead.Text = "read";
            this.button_accRawMaxRead.UseVisualStyleBackColor = true;
            this.button_accRawMaxRead.Click += new System.EventHandler(this.button_accRawMaxRead_Click);
            // 
            // button_driveLimitSUMWrite
            // 
            this.button_driveLimitSUMWrite.Location = new System.Drawing.Point(162, 211);
            this.button_driveLimitSUMWrite.Name = "button_driveLimitSUMWrite";
            this.button_driveLimitSUMWrite.Size = new System.Drawing.Size(36, 23);
            this.button_driveLimitSUMWrite.TabIndex = 29;
            this.button_driveLimitSUMWrite.Text = "write";
            this.button_driveLimitSUMWrite.UseVisualStyleBackColor = true;
            this.button_driveLimitSUMWrite.Click += new System.EventHandler(this.button_driveLimitSUMWrite_Click);
            // 
            // button_driveLimitSUMRead
            // 
            this.button_driveLimitSUMRead.Location = new System.Drawing.Point(120, 211);
            this.button_driveLimitSUMRead.Name = "button_driveLimitSUMRead";
            this.button_driveLimitSUMRead.Size = new System.Drawing.Size(36, 23);
            this.button_driveLimitSUMRead.TabIndex = 28;
            this.button_driveLimitSUMRead.Text = "read";
            this.button_driveLimitSUMRead.UseVisualStyleBackColor = true;
            this.button_driveLimitSUMRead.Click += new System.EventHandler(this.button_driveLimitSUMRead_Click);
            // 
            // button_driveTorqueLimitWrite
            // 
            this.button_driveTorqueLimitWrite.Location = new System.Drawing.Point(162, 175);
            this.button_driveTorqueLimitWrite.Name = "button_driveTorqueLimitWrite";
            this.button_driveTorqueLimitWrite.Size = new System.Drawing.Size(36, 23);
            this.button_driveTorqueLimitWrite.TabIndex = 27;
            this.button_driveTorqueLimitWrite.Text = "write";
            this.button_driveTorqueLimitWrite.UseVisualStyleBackColor = true;
            this.button_driveTorqueLimitWrite.Click += new System.EventHandler(this.button_driveTorqueLimitWrite_Click);
            // 
            // button_driveTorqueLimitRead
            // 
            this.button_driveTorqueLimitRead.Location = new System.Drawing.Point(120, 175);
            this.button_driveTorqueLimitRead.Name = "button_driveTorqueLimitRead";
            this.button_driveTorqueLimitRead.Size = new System.Drawing.Size(36, 23);
            this.button_driveTorqueLimitRead.TabIndex = 26;
            this.button_driveTorqueLimitRead.Text = "read";
            this.button_driveTorqueLimitRead.UseVisualStyleBackColor = true;
            this.button_driveTorqueLimitRead.Click += new System.EventHandler(this.button_driveTorqueLimitRead_Click);
            // 
            // button_driveVelocLimitWrite
            // 
            this.button_driveVelocLimitWrite.Location = new System.Drawing.Point(162, 137);
            this.button_driveVelocLimitWrite.Name = "button_driveVelocLimitWrite";
            this.button_driveVelocLimitWrite.Size = new System.Drawing.Size(36, 23);
            this.button_driveVelocLimitWrite.TabIndex = 25;
            this.button_driveVelocLimitWrite.Text = "write";
            this.button_driveVelocLimitWrite.UseVisualStyleBackColor = true;
            this.button_driveVelocLimitWrite.Click += new System.EventHandler(this.button_driveVelocLimitWrite_Click);
            // 
            // button_driveVelocLimitRead
            // 
            this.button_driveVelocLimitRead.Location = new System.Drawing.Point(120, 137);
            this.button_driveVelocLimitRead.Name = "button_driveVelocLimitRead";
            this.button_driveVelocLimitRead.Size = new System.Drawing.Size(36, 23);
            this.button_driveVelocLimitRead.TabIndex = 24;
            this.button_driveVelocLimitRead.Text = "read";
            this.button_driveVelocLimitRead.UseVisualStyleBackColor = true;
            this.button_driveVelocLimitRead.Click += new System.EventHandler(this.button_driveVelocLimitRead_Click);
            // 
            // button_velocDGainWrite
            // 
            this.button_velocDGainWrite.Location = new System.Drawing.Point(162, 100);
            this.button_velocDGainWrite.Name = "button_velocDGainWrite";
            this.button_velocDGainWrite.Size = new System.Drawing.Size(36, 23);
            this.button_velocDGainWrite.TabIndex = 23;
            this.button_velocDGainWrite.Text = "write";
            this.button_velocDGainWrite.UseVisualStyleBackColor = true;
            this.button_velocDGainWrite.Click += new System.EventHandler(this.button_velocDGainWrite_Click);
            // 
            // button_velocDGainRead
            // 
            this.button_velocDGainRead.Location = new System.Drawing.Point(120, 100);
            this.button_velocDGainRead.Name = "button_velocDGainRead";
            this.button_velocDGainRead.Size = new System.Drawing.Size(36, 23);
            this.button_velocDGainRead.TabIndex = 22;
            this.button_velocDGainRead.Text = "read";
            this.button_velocDGainRead.UseVisualStyleBackColor = true;
            this.button_velocDGainRead.Click += new System.EventHandler(this.button_velocDGainRead_Click);
            // 
            // button_velocIGainWrite
            // 
            this.button_velocIGainWrite.Location = new System.Drawing.Point(162, 63);
            this.button_velocIGainWrite.Name = "button_velocIGainWrite";
            this.button_velocIGainWrite.Size = new System.Drawing.Size(36, 23);
            this.button_velocIGainWrite.TabIndex = 21;
            this.button_velocIGainWrite.Text = "write";
            this.button_velocIGainWrite.UseVisualStyleBackColor = true;
            this.button_velocIGainWrite.Click += new System.EventHandler(this.button_velocIGainWrite_Click);
            // 
            // button_velocPGainWrite
            // 
            this.button_velocPGainWrite.Location = new System.Drawing.Point(162, 27);
            this.button_velocPGainWrite.Name = "button_velocPGainWrite";
            this.button_velocPGainWrite.Size = new System.Drawing.Size(36, 23);
            this.button_velocPGainWrite.TabIndex = 19;
            this.button_velocPGainWrite.Text = "write";
            this.button_velocPGainWrite.UseVisualStyleBackColor = true;
            this.button_velocPGainWrite.Click += new System.EventHandler(this.button_velocPGainWrite_Click);
            // 
            // button_velocIGainRead
            // 
            this.button_velocIGainRead.Location = new System.Drawing.Point(120, 63);
            this.button_velocIGainRead.Name = "button_velocIGainRead";
            this.button_velocIGainRead.Size = new System.Drawing.Size(36, 23);
            this.button_velocIGainRead.TabIndex = 20;
            this.button_velocIGainRead.Text = "read";
            this.button_velocIGainRead.UseVisualStyleBackColor = true;
            this.button_velocIGainRead.Click += new System.EventHandler(this.button_velocIGainRead_Click);
            // 
            // button_velocPGainRead
            // 
            this.button_velocPGainRead.Location = new System.Drawing.Point(120, 27);
            this.button_velocPGainRead.Name = "button_velocPGainRead";
            this.button_velocPGainRead.Size = new System.Drawing.Size(36, 23);
            this.button_velocPGainRead.TabIndex = 18;
            this.button_velocPGainRead.Text = "read";
            this.button_velocPGainRead.UseVisualStyleBackColor = true;
            this.button_velocPGainRead.Click += new System.EventHandler(this.button_velocPGainRead_Click);
            // 
            // comboBox_driveKeepAlive
            // 
            this.comboBox_driveKeepAlive.FormattingEnabled = true;
            this.comboBox_driveKeepAlive.Items.AddRange(new object[] {
            "disable",
            "SteerControl"});
            this.comboBox_driveKeepAlive.Location = new System.Drawing.Point(32, 378);
            this.comboBox_driveKeepAlive.Name = "comboBox_driveKeepAlive";
            this.comboBox_driveKeepAlive.Size = new System.Drawing.Size(67, 20);
            this.comboBox_driveKeepAlive.TabIndex = 17;
            // 
            // numericUpDown_accRawMin
            // 
            this.numericUpDown_accRawMin.Location = new System.Drawing.Point(32, 289);
            this.numericUpDown_accRawMin.Maximum = new decimal(new int[] {
            10230,
            0,
            0,
            0});
            this.numericUpDown_accRawMin.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.numericUpDown_accRawMin.Name = "numericUpDown_accRawMin";
            this.numericUpDown_accRawMin.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_accRawMin.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_accRawMin.TabIndex = 16;
            this.numericUpDown_accRawMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown_accRawMax
            // 
            this.numericUpDown_accRawMax.Location = new System.Drawing.Point(32, 252);
            this.numericUpDown_accRawMax.Maximum = new decimal(new int[] {
            10230,
            0,
            0,
            0});
            this.numericUpDown_accRawMax.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.numericUpDown_accRawMax.Name = "numericUpDown_accRawMax";
            this.numericUpDown_accRawMax.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_accRawMax.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_accRawMax.TabIndex = 15;
            this.numericUpDown_accRawMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_accRawMax.Value = new decimal(new int[] {
            1023,
            0,
            0,
            0});
            // 
            // numericUpDown_SUMLimit
            // 
            this.numericUpDown_SUMLimit.Location = new System.Drawing.Point(32, 215);
            this.numericUpDown_SUMLimit.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown_SUMLimit.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.numericUpDown_SUMLimit.Name = "numericUpDown_SUMLimit";
            this.numericUpDown_SUMLimit.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_SUMLimit.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_SUMLimit.TabIndex = 14;
            this.numericUpDown_SUMLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_SUMLimit.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // numericUpDown_driveTorqueLimit
            // 
            this.numericUpDown_driveTorqueLimit.Location = new System.Drawing.Point(32, 178);
            this.numericUpDown_driveTorqueLimit.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.numericUpDown_driveTorqueLimit.Minimum = new decimal(new int[] {
            2000,
            0,
            0,
            -2147483648});
            this.numericUpDown_driveTorqueLimit.Name = "numericUpDown_driveTorqueLimit";
            this.numericUpDown_driveTorqueLimit.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_driveTorqueLimit.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_driveTorqueLimit.TabIndex = 13;
            this.numericUpDown_driveTorqueLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_driveTorqueLimit.Value = new decimal(new int[] {
            500,
            0,
            0,
            0});
            // 
            // numericUpDown_velocLimit
            // 
            this.numericUpDown_velocLimit.Location = new System.Drawing.Point(32, 141);
            this.numericUpDown_velocLimit.Maximum = new decimal(new int[] {
            160000,
            0,
            0,
            0});
            this.numericUpDown_velocLimit.Minimum = new decimal(new int[] {
            160000,
            0,
            0,
            -2147483648});
            this.numericUpDown_velocLimit.Name = "numericUpDown_velocLimit";
            this.numericUpDown_velocLimit.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_velocLimit.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_velocLimit.TabIndex = 12;
            this.numericUpDown_velocLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown_velocDgain
            // 
            this.numericUpDown_velocDgain.Location = new System.Drawing.Point(32, 104);
            this.numericUpDown_velocDgain.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.numericUpDown_velocDgain.Minimum = new decimal(new int[] {
            2000,
            0,
            0,
            -2147483648});
            this.numericUpDown_velocDgain.Name = "numericUpDown_velocDgain";
            this.numericUpDown_velocDgain.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_velocDgain.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_velocDgain.TabIndex = 11;
            this.numericUpDown_velocDgain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown_velocIgain
            // 
            this.numericUpDown_velocIgain.Location = new System.Drawing.Point(32, 67);
            this.numericUpDown_velocIgain.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.numericUpDown_velocIgain.Minimum = new decimal(new int[] {
            2000,
            0,
            0,
            -2147483648});
            this.numericUpDown_velocIgain.Name = "numericUpDown_velocIgain";
            this.numericUpDown_velocIgain.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_velocIgain.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_velocIgain.TabIndex = 10;
            this.numericUpDown_velocIgain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown_velocPgain
            // 
            this.numericUpDown_velocPgain.Location = new System.Drawing.Point(32, 30);
            this.numericUpDown_velocPgain.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.numericUpDown_velocPgain.Minimum = new decimal(new int[] {
            2000,
            0,
            0,
            -2147483648});
            this.numericUpDown_velocPgain.Name = "numericUpDown_velocPgain";
            this.numericUpDown_velocPgain.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown_velocPgain.Size = new System.Drawing.Size(67, 19);
            this.numericUpDown_velocPgain.TabIndex = 9;
            this.numericUpDown_velocPgain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_velocPgain.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(6, 363);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(137, 12);
            this.label55.TabIndex = 8;
            this.label55.Text = "keep alive param(dfault:0)";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(6, 274);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(146, 12);
            this.label54.TabIndex = 7;
            this.label54.Text = "accPedal raw min(default:0)";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(6, 237);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(167, 12);
            this.label53.TabIndex = 6;
            this.label53.Text = "accPedal raw max(default:1023)";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(6, 200);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(118, 12);
            this.label52.TabIndex = 5;
            this.label52.Text = "limit SUM(default:100)";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(6, 163);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(126, 12);
            this.label51.TabIndex = 4;
            this.label51.Text = "torque limit(default:500)";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(6, 126);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(140, 12);
            this.label50.TabIndex = 3;
            this.label50.Text = "velocity limit(default:2841)";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(6, 89);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(133, 12);
            this.label49.TabIndex = 2;
            this.label49.Text = "velocity D gain(default:0)";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(6, 52);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(128, 12);
            this.label48.TabIndex = 1;
            this.label48.Text = "velocity I gain(default:0)";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(6, 15);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(150, 12);
            this.label47.TabIndex = 0;
            this.label47.Text = "velocity P gain(default:1000)";
            // 
            // tabPage_IMU
            // 
            this.tabPage_IMU.Controls.Add(this.button_setImuStatus);
            this.tabPage_IMU.Controls.Add(this.button_GetImuProfile);
            this.tabPage_IMU.Controls.Add(this.groupBox_ImuProfile);
            this.tabPage_IMU.Controls.Add(this.button_getIMUStatus);
            this.tabPage_IMU.Controls.Add(this.groupBox_ImuStatus);
            this.tabPage_IMU.Controls.Add(this.groupBox_comp);
            this.tabPage_IMU.Controls.Add(this.groupBox_gyro);
            this.tabPage_IMU.Controls.Add(this.groupBox_acc);
            this.tabPage_IMU.Location = new System.Drawing.Point(4, 22);
            this.tabPage_IMU.Name = "tabPage_IMU";
            this.tabPage_IMU.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_IMU.Size = new System.Drawing.Size(733, 518);
            this.tabPage_IMU.TabIndex = 1;
            this.tabPage_IMU.Text = "IMU";
            this.tabPage_IMU.UseVisualStyleBackColor = true;
            // 
            // button_setImuStatus
            // 
            this.button_setImuStatus.Location = new System.Drawing.Point(319, 10);
            this.button_setImuStatus.Name = "button_setImuStatus";
            this.button_setImuStatus.Size = new System.Drawing.Size(83, 23);
            this.button_setImuStatus.TabIndex = 7;
            this.button_setImuStatus.Text = "SetStatus";
            this.button_setImuStatus.UseVisualStyleBackColor = true;
            this.button_setImuStatus.Click += new System.EventHandler(this.button_setImuStatus_Click);
            // 
            // button_GetImuProfile
            // 
            this.button_GetImuProfile.Location = new System.Drawing.Point(445, 10);
            this.button_GetImuProfile.Name = "button_GetImuProfile";
            this.button_GetImuProfile.Size = new System.Drawing.Size(75, 23);
            this.button_GetImuProfile.TabIndex = 6;
            this.button_GetImuProfile.Text = "GetProfile";
            this.button_GetImuProfile.UseVisualStyleBackColor = true;
            this.button_GetImuProfile.Click += new System.EventHandler(this.button_GetImuProfile_Click);
            // 
            // groupBox_ImuProfile
            // 
            this.groupBox_ImuProfile.Controls.Add(this.textBox_imuBtAdr);
            this.groupBox_ImuProfile.Controls.Add(this.label80);
            this.groupBox_ImuProfile.Controls.Add(this.textBox_imuFirm);
            this.groupBox_ImuProfile.Controls.Add(this.label81);
            this.groupBox_ImuProfile.Controls.Add(this.textBox_imuHard);
            this.groupBox_ImuProfile.Controls.Add(this.label86);
            this.groupBox_ImuProfile.Location = new System.Drawing.Point(445, 39);
            this.groupBox_ImuProfile.Name = "groupBox_ImuProfile";
            this.groupBox_ImuProfile.Size = new System.Drawing.Size(204, 97);
            this.groupBox_ImuProfile.TabIndex = 5;
            this.groupBox_ImuProfile.TabStop = false;
            this.groupBox_ImuProfile.Text = "device profile";
            // 
            // textBox_imuBtAdr
            // 
            this.textBox_imuBtAdr.Location = new System.Drawing.Point(68, 62);
            this.textBox_imuBtAdr.Name = "textBox_imuBtAdr";
            this.textBox_imuBtAdr.ReadOnly = true;
            this.textBox_imuBtAdr.Size = new System.Drawing.Size(90, 19);
            this.textBox_imuBtAdr.TabIndex = 15;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(6, 65);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(37, 12);
            this.label80.TabIndex = 14;
            this.label80.Text = "btaddr";
            // 
            // textBox_imuFirm
            // 
            this.textBox_imuFirm.Location = new System.Drawing.Point(69, 37);
            this.textBox_imuFirm.Name = "textBox_imuFirm";
            this.textBox_imuFirm.ReadOnly = true;
            this.textBox_imuFirm.Size = new System.Drawing.Size(90, 19);
            this.textBox_imuFirm.TabIndex = 13;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(7, 40);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(49, 12);
            this.label81.TabIndex = 12;
            this.label81.Text = "firmware";
            // 
            // textBox_imuHard
            // 
            this.textBox_imuHard.Location = new System.Drawing.Point(68, 12);
            this.textBox_imuHard.Name = "textBox_imuHard";
            this.textBox_imuHard.ReadOnly = true;
            this.textBox_imuHard.Size = new System.Drawing.Size(90, 19);
            this.textBox_imuHard.TabIndex = 1;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(6, 15);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(51, 12);
            this.label86.TabIndex = 0;
            this.label86.Text = "hardware";
            // 
            // button_getIMUStatus
            // 
            this.button_getIMUStatus.Location = new System.Drawing.Point(226, 10);
            this.button_getIMUStatus.Name = "button_getIMUStatus";
            this.button_getIMUStatus.Size = new System.Drawing.Size(75, 23);
            this.button_getIMUStatus.TabIndex = 4;
            this.button_getIMUStatus.Text = "GetStatus";
            this.button_getIMUStatus.UseVisualStyleBackColor = true;
            this.button_getIMUStatus.Click += new System.EventHandler(this.button_getIMUStatus_Click);
            // 
            // groupBox_ImuStatus
            // 
            this.groupBox_ImuStatus.Controls.Add(this.textBox_ImuBinary);
            this.groupBox_ImuStatus.Controls.Add(this.label79);
            this.groupBox_ImuStatus.Controls.Add(this.textBox_ImuBattery);
            this.groupBox_ImuStatus.Controls.Add(this.label78);
            this.groupBox_ImuStatus.Controls.Add(this.comboBox_ImuCompRange);
            this.groupBox_ImuStatus.Controls.Add(this.label77);
            this.groupBox_ImuStatus.Controls.Add(this.comboBox_ImuGyroRange);
            this.groupBox_ImuStatus.Controls.Add(this.label76);
            this.groupBox_ImuStatus.Controls.Add(this.comboBox_ImuAccRange);
            this.groupBox_ImuStatus.Controls.Add(this.numericUpDown_ImuPeriod);
            this.groupBox_ImuStatus.Controls.Add(this.label73);
            this.groupBox_ImuStatus.Controls.Add(this.label74);
            this.groupBox_ImuStatus.Controls.Add(this.textBox_ImuRole);
            this.groupBox_ImuStatus.Controls.Add(this.label75);
            this.groupBox_ImuStatus.Location = new System.Drawing.Point(226, 39);
            this.groupBox_ImuStatus.Name = "groupBox_ImuStatus";
            this.groupBox_ImuStatus.Size = new System.Drawing.Size(204, 196);
            this.groupBox_ImuStatus.TabIndex = 3;
            this.groupBox_ImuStatus.TabStop = false;
            this.groupBox_ImuStatus.Text = "status";
            // 
            // textBox_ImuBinary
            // 
            this.textBox_ImuBinary.Location = new System.Drawing.Point(67, 169);
            this.textBox_ImuBinary.Name = "textBox_ImuBinary";
            this.textBox_ImuBinary.ReadOnly = true;
            this.textBox_ImuBinary.Size = new System.Drawing.Size(90, 19);
            this.textBox_ImuBinary.TabIndex = 15;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(5, 172);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(36, 12);
            this.label79.TabIndex = 14;
            this.label79.Text = "binary";
            // 
            // textBox_ImuBattery
            // 
            this.textBox_ImuBattery.Location = new System.Drawing.Point(68, 144);
            this.textBox_ImuBattery.Name = "textBox_ImuBattery";
            this.textBox_ImuBattery.ReadOnly = true;
            this.textBox_ImuBattery.Size = new System.Drawing.Size(90, 19);
            this.textBox_ImuBattery.TabIndex = 13;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(6, 147);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(41, 12);
            this.label78.TabIndex = 12;
            this.label78.Text = "battery";
            // 
            // comboBox_ImuCompRange
            // 
            this.comboBox_ImuCompRange.FormattingEnabled = true;
            this.comboBox_ImuCompRange.Items.AddRange(new object[] {
            "COMP_07",
            "COMP_10",
            "COMP_15",
            "COMP_20",
            "COMP_32",
            "COMP_38",
            "COMP_45"});
            this.comboBox_ImuCompRange.Location = new System.Drawing.Point(67, 115);
            this.comboBox_ImuCompRange.Name = "comboBox_ImuCompRange";
            this.comboBox_ImuCompRange.Size = new System.Drawing.Size(91, 20);
            this.comboBox_ImuCompRange.TabIndex = 11;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(3, 118);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(64, 12);
            this.label77.TabIndex = 10;
            this.label77.Text = "comp range";
            // 
            // comboBox_ImuGyroRange
            // 
            this.comboBox_ImuGyroRange.FormattingEnabled = true;
            this.comboBox_ImuGyroRange.Items.AddRange(new object[] {
            "GYRO_30",
            "GYRO_120"});
            this.comboBox_ImuGyroRange.Location = new System.Drawing.Point(67, 89);
            this.comboBox_ImuGyroRange.Name = "comboBox_ImuGyroRange";
            this.comboBox_ImuGyroRange.Size = new System.Drawing.Size(91, 20);
            this.comboBox_ImuGyroRange.TabIndex = 9;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(5, 92);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(59, 12);
            this.label76.TabIndex = 8;
            this.label76.Text = "gyro range";
            // 
            // comboBox_ImuAccRange
            // 
            this.comboBox_ImuAccRange.FormattingEnabled = true;
            this.comboBox_ImuAccRange.Items.AddRange(new object[] {
            "ACC_2G",
            "ACC_4G",
            "ACC_8G"});
            this.comboBox_ImuAccRange.Location = new System.Drawing.Point(67, 63);
            this.comboBox_ImuAccRange.Name = "comboBox_ImuAccRange";
            this.comboBox_ImuAccRange.Size = new System.Drawing.Size(91, 20);
            this.comboBox_ImuAccRange.TabIndex = 7;
            // 
            // numericUpDown_ImuPeriod
            // 
            this.numericUpDown_ImuPeriod.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown_ImuPeriod.Location = new System.Drawing.Point(68, 38);
            this.numericUpDown_ImuPeriod.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown_ImuPeriod.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown_ImuPeriod.Name = "numericUpDown_ImuPeriod";
            this.numericUpDown_ImuPeriod.Size = new System.Drawing.Size(90, 19);
            this.numericUpDown_ImuPeriod.TabIndex = 6;
            this.numericUpDown_ImuPeriod.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDown_ImuPeriod.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(6, 65);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(55, 12);
            this.label73.TabIndex = 4;
            this.label73.Text = "acc range";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(6, 40);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(36, 12);
            this.label74.TabIndex = 2;
            this.label74.Text = "period";
            // 
            // textBox_ImuRole
            // 
            this.textBox_ImuRole.Location = new System.Drawing.Point(68, 12);
            this.textBox_ImuRole.Name = "textBox_ImuRole";
            this.textBox_ImuRole.ReadOnly = true;
            this.textBox_ImuRole.Size = new System.Drawing.Size(90, 19);
            this.textBox_ImuRole.TabIndex = 1;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(6, 15);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(24, 12);
            this.label75.TabIndex = 0;
            this.label75.Text = "role";
            // 
            // groupBox_comp
            // 
            this.groupBox_comp.Controls.Add(this.textBox_compZ);
            this.groupBox_comp.Controls.Add(this.label70);
            this.groupBox_comp.Controls.Add(this.textBox_compY);
            this.groupBox_comp.Controls.Add(this.label71);
            this.groupBox_comp.Controls.Add(this.textBox_compX);
            this.groupBox_comp.Controls.Add(this.label72);
            this.groupBox_comp.Location = new System.Drawing.Point(7, 204);
            this.groupBox_comp.Name = "groupBox_comp";
            this.groupBox_comp.Size = new System.Drawing.Size(204, 93);
            this.groupBox_comp.TabIndex = 2;
            this.groupBox_comp.TabStop = false;
            this.groupBox_comp.Text = "comp";
            // 
            // textBox_compZ
            // 
            this.textBox_compZ.Location = new System.Drawing.Point(51, 62);
            this.textBox_compZ.Name = "textBox_compZ";
            this.textBox_compZ.ReadOnly = true;
            this.textBox_compZ.Size = new System.Drawing.Size(90, 19);
            this.textBox_compZ.TabIndex = 5;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(6, 65);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(39, 12);
            this.label70.TabIndex = 4;
            this.label70.Text = "Z Axis";
            // 
            // textBox_compY
            // 
            this.textBox_compY.Location = new System.Drawing.Point(51, 37);
            this.textBox_compY.Name = "textBox_compY";
            this.textBox_compY.ReadOnly = true;
            this.textBox_compY.Size = new System.Drawing.Size(90, 19);
            this.textBox_compY.TabIndex = 3;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(6, 40);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(39, 12);
            this.label71.TabIndex = 2;
            this.label71.Text = "Y Axis";
            // 
            // textBox_compX
            // 
            this.textBox_compX.Location = new System.Drawing.Point(51, 12);
            this.textBox_compX.Name = "textBox_compX";
            this.textBox_compX.ReadOnly = true;
            this.textBox_compX.Size = new System.Drawing.Size(90, 19);
            this.textBox_compX.TabIndex = 1;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(6, 15);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(39, 12);
            this.label72.TabIndex = 0;
            this.label72.Text = "X Axis";
            // 
            // groupBox_gyro
            // 
            this.groupBox_gyro.Controls.Add(this.textBox_gyroZ);
            this.groupBox_gyro.Controls.Add(this.label67);
            this.groupBox_gyro.Controls.Add(this.textBox_gyroY);
            this.groupBox_gyro.Controls.Add(this.label68);
            this.groupBox_gyro.Controls.Add(this.textBox_gyroX);
            this.groupBox_gyro.Controls.Add(this.label69);
            this.groupBox_gyro.Location = new System.Drawing.Point(7, 105);
            this.groupBox_gyro.Name = "groupBox_gyro";
            this.groupBox_gyro.Size = new System.Drawing.Size(204, 93);
            this.groupBox_gyro.TabIndex = 1;
            this.groupBox_gyro.TabStop = false;
            this.groupBox_gyro.Text = "gyro";
            // 
            // textBox_gyroZ
            // 
            this.textBox_gyroZ.Location = new System.Drawing.Point(51, 62);
            this.textBox_gyroZ.Name = "textBox_gyroZ";
            this.textBox_gyroZ.ReadOnly = true;
            this.textBox_gyroZ.Size = new System.Drawing.Size(90, 19);
            this.textBox_gyroZ.TabIndex = 5;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(6, 65);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(39, 12);
            this.label67.TabIndex = 4;
            this.label67.Text = "Z Axis";
            // 
            // textBox_gyroY
            // 
            this.textBox_gyroY.Location = new System.Drawing.Point(51, 37);
            this.textBox_gyroY.Name = "textBox_gyroY";
            this.textBox_gyroY.ReadOnly = true;
            this.textBox_gyroY.Size = new System.Drawing.Size(90, 19);
            this.textBox_gyroY.TabIndex = 3;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(6, 40);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(39, 12);
            this.label68.TabIndex = 2;
            this.label68.Text = "Y Axis";
            // 
            // textBox_gyroX
            // 
            this.textBox_gyroX.Location = new System.Drawing.Point(51, 12);
            this.textBox_gyroX.Name = "textBox_gyroX";
            this.textBox_gyroX.ReadOnly = true;
            this.textBox_gyroX.Size = new System.Drawing.Size(90, 19);
            this.textBox_gyroX.TabIndex = 1;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(6, 15);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(39, 12);
            this.label69.TabIndex = 0;
            this.label69.Text = "X Axis";
            // 
            // groupBox_acc
            // 
            this.groupBox_acc.Controls.Add(this.textBox_accZ);
            this.groupBox_acc.Controls.Add(this.label66);
            this.groupBox_acc.Controls.Add(this.textBox_accY);
            this.groupBox_acc.Controls.Add(this.label65);
            this.groupBox_acc.Controls.Add(this.textBox_AccX);
            this.groupBox_acc.Controls.Add(this.label56);
            this.groupBox_acc.Location = new System.Drawing.Point(7, 6);
            this.groupBox_acc.Name = "groupBox_acc";
            this.groupBox_acc.Size = new System.Drawing.Size(204, 93);
            this.groupBox_acc.TabIndex = 0;
            this.groupBox_acc.TabStop = false;
            this.groupBox_acc.Text = "acc";
            // 
            // textBox_accZ
            // 
            this.textBox_accZ.Location = new System.Drawing.Point(51, 62);
            this.textBox_accZ.Name = "textBox_accZ";
            this.textBox_accZ.ReadOnly = true;
            this.textBox_accZ.Size = new System.Drawing.Size(90, 19);
            this.textBox_accZ.TabIndex = 5;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(6, 65);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(39, 12);
            this.label66.TabIndex = 4;
            this.label66.Text = "Z Axis";
            // 
            // textBox_accY
            // 
            this.textBox_accY.Location = new System.Drawing.Point(51, 37);
            this.textBox_accY.Name = "textBox_accY";
            this.textBox_accY.ReadOnly = true;
            this.textBox_accY.Size = new System.Drawing.Size(90, 19);
            this.textBox_accY.TabIndex = 3;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(6, 40);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(39, 12);
            this.label65.TabIndex = 2;
            this.label65.Text = "Y Axis";
            // 
            // textBox_AccX
            // 
            this.textBox_AccX.Location = new System.Drawing.Point(51, 12);
            this.textBox_AccX.Name = "textBox_AccX";
            this.textBox_AccX.ReadOnly = true;
            this.textBox_AccX.Size = new System.Drawing.Size(90, 19);
            this.textBox_AccX.TabIndex = 1;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(6, 15);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(39, 12);
            this.label56.TabIndex = 0;
            this.label56.Text = "X Axis";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.connectToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(738, 26);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // connectToolStripMenuItem
            // 
            this.connectToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.closeToolStripMenuItem});
            this.connectToolStripMenuItem.Name = "connectToolStripMenuItem";
            this.connectToolStripMenuItem.Size = new System.Drawing.Size(67, 22);
            this.connectToolStripMenuItem.Text = "Connect";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.toolStrip1.Location = new System.Drawing.Point(116, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(110, 25);
            this.toolStrip1.TabIndex = 36;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(98, 20);
            this.toolStripStatusLabel1.Text = "Not Connected.";
            // 
            // MevControlForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(738, 570);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.tabControl);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MevControlForm";
            this.Text = "MevControl";
            this.tabControl.ResumeLayout(false);
            this.tabPage_Mev.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox_driveSwitch.ResumeLayout(false);
            this.groupBox_driveSwitch.PerformLayout();
            this.groupBox_SteerStatus.ResumeLayout(false);
            this.groupBox_SteerStatus.PerformLayout();
            this.groupBox_reaction.ResumeLayout(false);
            this.groupBox_reaction.PerformLayout();
            this.groupBox_steer.ResumeLayout(false);
            this.groupBox_steer.PerformLayout();
            this.groupBox_driveStatus.ResumeLayout(false);
            this.groupBox_driveStatus.PerformLayout();
            this.groupBox_drive.ResumeLayout(false);
            this.groupBox_drive.PerformLayout();
            this.tabPage_Config.ResumeLayout(false);
            this.tabPage_Config.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_manualReactVGain)).EndInit();
            this.groupBox_rawPedalInput.ResumeLayout(false);
            this.groupBox_rawPedalInput.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_steerOffset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_manualLockTorque)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_reactionOffset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_manualRatio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_manualReactGain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_manualSteerGain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_manualSteerVeloc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_reactVeloc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_reactAcc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_steerGain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_steerVeloc)).EndInit();
            this.groupBox_driveConfig.ResumeLayout(false);
            this.groupBox_driveConfig.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_hostIntervalLimit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_accRawMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_accRawMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_SUMLimit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_driveTorqueLimit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_velocLimit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_velocDgain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_velocIgain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_velocPgain)).EndInit();
            this.tabPage_IMU.ResumeLayout(false);
            this.groupBox_ImuProfile.ResumeLayout(false);
            this.groupBox_ImuProfile.PerformLayout();
            this.groupBox_ImuStatus.ResumeLayout(false);
            this.groupBox_ImuStatus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_ImuPeriod)).EndInit();
            this.groupBox_comp.ResumeLayout(false);
            this.groupBox_comp.PerformLayout();
            this.groupBox_gyro.ResumeLayout(false);
            this.groupBox_gyro.PerformLayout();
            this.groupBox_acc.ResumeLayout(false);
            this.groupBox_acc.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage_Mev;
        private System.Windows.Forms.TabPage tabPage_IMU;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem connectToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage_Config;
        private System.Windows.Forms.TextBox textBox_driveErrCode;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox_driveStatus;
        private System.Windows.Forms.TextBox textBox_drivePedalInput;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox_driveContMode;
        private System.Windows.Forms.TextBox textBox_driveServo;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox_driveMode;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox_drive;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button_modeTorque;
        private System.Windows.Forms.Button button_modeVeloc;
        private System.Windows.Forms.Button button_setDriveTorqueZero;
        private System.Windows.Forms.Button button_setDriveTorque;
        private System.Windows.Forms.TextBox textBox_setDriveTorque;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.HScrollBar hScrollBar_driveTorque;
        private System.Windows.Forms.TextBox textBox_enc4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_enc3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_enc2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox_enc1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_actualVelocL;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_actualVelocR;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_setVelocZero;
        private System.Windows.Forms.Button button_setVeloc;
        private System.Windows.Forms.TextBox textBox_setDriveVeloc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.HScrollBar hScrollBar_driveVeloc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_driveOff;
        private System.Windows.Forms.Button button_driveOn;
        private System.Windows.Forms.Button button_GetStatus;
        private System.Windows.Forms.GroupBox groupBox_steer;
        private System.Windows.Forms.Button button_setSteerPosZero;
        private System.Windows.Forms.Button button_setSteerPos;
        private System.Windows.Forms.TextBox textBox_setSteerPos;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.HScrollBar hScrollBar_steerPos;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button_SteerOff;
        private System.Windows.Forms.Button button_steerOn;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox_steerActualPos;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox_steerTargetPos;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.GroupBox groupBox_reaction;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button_modeReactTorque;
        private System.Windows.Forms.Button button_modeReactPos;
        private System.Windows.Forms.Button button_setReactTorqueZero;
        private System.Windows.Forms.Button button_setReactTorque;
        private System.Windows.Forms.TextBox textBox_setReactTorque;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.HScrollBar hScrollBar_ReactTorque;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox_reactActualPos;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox_reactTargetPos;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button button_setReactPosZero;
        private System.Windows.Forms.Button button_setReactPos;
        private System.Windows.Forms.TextBox textBox_setReactPos;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.HScrollBar hScrollBar_reactPos;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button button_reactOff;
        private System.Windows.Forms.Button button_reactOn;
        private System.Windows.Forms.TextBox textBox_reactActualTorque;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox_reactTargetTorque;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.GroupBox groupBox_SteerStatus;
        private System.Windows.Forms.TextBox textBox_steerErrCode;
        private System.Windows.Forms.TextBox textBox_reactServo;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox_reactContMode;
        private System.Windows.Forms.TextBox textBox_steerServo;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBox_steerMode;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Button button_GetSteerStatus;
        private System.Windows.Forms.GroupBox groupBox_driveSwitch;
        private System.Windows.Forms.TextBox textBox_sw4;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox_sw3;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox_sw2;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox_sw1;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox textBox_mode2;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox textBox_mode1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox_mevVoltage;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.GroupBox groupBox_driveConfig;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.NumericUpDown numericUpDown_velocPgain;
        private System.Windows.Forms.NumericUpDown numericUpDown_driveTorqueLimit;
        private System.Windows.Forms.NumericUpDown numericUpDown_velocLimit;
        private System.Windows.Forms.NumericUpDown numericUpDown_velocDgain;
        private System.Windows.Forms.NumericUpDown numericUpDown_velocIgain;
        private System.Windows.Forms.NumericUpDown numericUpDown_SUMLimit;
        private System.Windows.Forms.ComboBox comboBox_driveKeepAlive;
        private System.Windows.Forms.NumericUpDown numericUpDown_accRawMin;
        private System.Windows.Forms.NumericUpDown numericUpDown_accRawMax;
        private System.Windows.Forms.Button button_velocPGainWrite;
        private System.Windows.Forms.Button button_velocPGainRead;
        private System.Windows.Forms.Button button_driveKeepAliveWrite;
        private System.Windows.Forms.Button button_driveKeepAliveRead;
        private System.Windows.Forms.Button button_accRawMinWrite;
        private System.Windows.Forms.Button button_accRawMinRead;
        private System.Windows.Forms.Button button_accRawMaxWrite;
        private System.Windows.Forms.Button button_accRawMaxRead;
        private System.Windows.Forms.Button button_driveLimitSUMWrite;
        private System.Windows.Forms.Button button_driveLimitSUMRead;
        private System.Windows.Forms.Button button_driveTorqueLimitWrite;
        private System.Windows.Forms.Button button_driveTorqueLimitRead;
        private System.Windows.Forms.Button button_driveVelocLimitWrite;
        private System.Windows.Forms.Button button_driveVelocLimitRead;
        private System.Windows.Forms.Button button_velocDGainWrite;
        private System.Windows.Forms.Button button_velocDGainRead;
        private System.Windows.Forms.Button button_velocIGainWrite;
        private System.Windows.Forms.Button button_velocIGainRead;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button_steerKeepAliveWrite;
        private System.Windows.Forms.Button button_steerKeepAliveRead;
        private System.Windows.Forms.Button button_manualReactionGainWrite;
        private System.Windows.Forms.Button button_manualReactionGainRead;
        private System.Windows.Forms.Button button_manualSteerGainWrite;
        private System.Windows.Forms.Button button_manualSteerGainRead;
        private System.Windows.Forms.Button button_manualSteerVelocWrite;
        private System.Windows.Forms.Button button_manualSteerVelocRead;
        private System.Windows.Forms.Button button_reactVelocWrite;
        private System.Windows.Forms.Button button_reactVelocRead;
        private System.Windows.Forms.Button button_reactAccWrite;
        private System.Windows.Forms.Button button_reactAccRead;
        private System.Windows.Forms.Button button_steerGainWrite;
        private System.Windows.Forms.Button button_steerVelocWrite;
        private System.Windows.Forms.Button button_steerGainRead;
        private System.Windows.Forms.Button button_steerVelocRead;
        private System.Windows.Forms.NumericUpDown numericUpDown_manualReactGain;
        private System.Windows.Forms.NumericUpDown numericUpDown_manualSteerGain;
        private System.Windows.Forms.NumericUpDown numericUpDown_manualSteerVeloc;
        private System.Windows.Forms.NumericUpDown numericUpDown_reactVeloc;
        private System.Windows.Forms.NumericUpDown numericUpDown_reactAcc;
        private System.Windows.Forms.NumericUpDown numericUpDown_steerGain;
        private System.Windows.Forms.NumericUpDown numericUpDown_steerVeloc;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.ComboBox comboBox_steerKeepAlive;
        private System.Windows.Forms.Button button_configReadAll;
        private System.Windows.Forms.Button button_configSave;
        private System.Windows.Forms.GroupBox groupBox_acc;
        private System.Windows.Forms.GroupBox groupBox_comp;
        private System.Windows.Forms.TextBox textBox_compZ;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox textBox_compY;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox textBox_compX;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.GroupBox groupBox_gyro;
        private System.Windows.Forms.TextBox textBox_gyroZ;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox textBox_gyroY;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox textBox_gyroX;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox textBox_accZ;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox textBox_accY;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox textBox_AccX;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Button button_getIMUStatus;
        private System.Windows.Forms.GroupBox groupBox_ImuStatus;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.TextBox textBox_ImuRole;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.ComboBox comboBox_ImuGyroRange;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.ComboBox comboBox_ImuAccRange;
        private System.Windows.Forms.NumericUpDown numericUpDown_ImuPeriod;
        private System.Windows.Forms.TextBox textBox_ImuBinary;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TextBox textBox_ImuBattery;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.ComboBox comboBox_ImuCompRange;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Button button_GetImuProfile;
        private System.Windows.Forms.GroupBox groupBox_ImuProfile;
        private System.Windows.Forms.TextBox textBox_imuBtAdr;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TextBox textBox_imuFirm;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.TextBox textBox_imuHard;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Button button_setImuStatus;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.GroupBox groupBox_rawPedalInput;
        private System.Windows.Forms.Button button_getRawPedal;
        private System.Windows.Forms.TextBox textbox_drivieRawPedalInput;
        private System.Windows.Forms.Button button_hostIntervalLimitWrite;
        private System.Windows.Forms.Button button_hostIntervalLimitRead;
        private System.Windows.Forms.Label label179;
        private System.Windows.Forms.NumericUpDown numericUpDown_hostIntervalLimit;
        private System.Windows.Forms.Button button_logStop;
        private System.Windows.Forms.Button button2_logStart;
        private System.Windows.Forms.Button button_steerOffsetWrite;
        private System.Windows.Forms.Button button_steerOffsetRead;
        private System.Windows.Forms.NumericUpDown numericUpDown_steerOffset;
        private System.Windows.Forms.Label label180;
        private System.Windows.Forms.Button button_reactOffsetWrite;
        private System.Windows.Forms.Button button_reactOffsetRead;
        private System.Windows.Forms.NumericUpDown numericUpDown_reactionOffset;
        private System.Windows.Forms.Label label181;
        private System.Windows.Forms.Button button_manualLockTorqueWrite;
        private System.Windows.Forms.Button button_manualLockTorqueRead;
        private System.Windows.Forms.NumericUpDown numericUpDown_manualLockTorque;
        private System.Windows.Forms.Label label183;
        private System.Windows.Forms.Button button_manualRatioWrite;
        private System.Windows.Forms.Button button_manualRatioRead;
        private System.Windows.Forms.NumericUpDown numericUpDown_manualRatio;
        private System.Windows.Forms.Label label182;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_targetVelocL;
        private System.Windows.Forms.TextBox textBox_targetVelocR;
        private System.Windows.Forms.Button button_manualReactionVGainWrite;
        private System.Windows.Forms.Button button_manualReactionVGainRead;
        private System.Windows.Forms.NumericUpDown numericUpDown_manualReactVGain;
        private System.Windows.Forms.Label label184;
    }
}

