﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;

//using System.Net;
using System.IO;
//using System.Web;

//using Zmp.Imuz.Communication;
//using Zmp.Imuz.Estimator;
using Zmp.Mev.Communication;
using Zmp.Rcz.Communication;

namespace MevControl
{

    public partial class MevControlForm : Form
    {
        /// <summary>
        /// Connect
        /// </summary>
        private connectConfig _config = new connectConfig();
        private RczCommunication _comm = new RczCommunication();

        /// <summary>
        /// config tab
        /// </summary>
        ConfigTable _readConfTable;
        int _readConfLen;
        bool _readConfAll;

        public MevControlForm()
        {
            InitializeComponent();

            _readConfTable = ConfigTable.VelocityGainP;
            _readConfLen = 0;
            _readConfAll = false;
        }

        private void onReceived(object sender, MevMsg msg)
        {
            try
            {
                switch ((MsgId)msg.id)
                {
                    case MsgId.MEVMSG_ID_RCV_DRIVE_MOTORV: ParseDriveMotorVKm(msg); break;
                    case MsgId.MEVMSG_ID_RCV_DRIVE_ENCODER: ParseDriveEncoder(msg);  break;
                    case MsgId.MEVMSG_ID_RCV_DRIVE_STATUS: ParseDriveStatus(msg); break;
                    case MsgId.MEVMSG_ID_RCV_DRIVE_PEDALINPUT: ParseDrivePedalInput(msg); break;
                    case MsgId.MEVMSG_ID_RCV_DRIVE_SWSTATUS: ParseDriveSwStatus(msg); break;
                    case MsgId.MEVMSG_ID_RCV_DRIVE_RAWPEDAL: ParseDriveRawPedal(msg); break;
                    case MsgId.MEVMSG_ID_RCV_DRIVE_BATT: ParseDriveBatt(msg); break;

                    case MsgId.MEVMSG_ID_RCV_REACTION_DATA1: ParseReactPos(msg); break;
                    case MsgId.MEVMSG_ID_RCV_REACTION_DATA2: ParseReactTorque(msg); break;

                    case MsgId.MEVMSG_ID_RCV_STEER_DATA: ParseSteerPos(msg); break;
                    case MsgId.MEVMSG_ID_RCV_STEER_STATUS: ParseSteerStatus(msg); break;

                    case MsgId.MEVMSG_ID_RES_SYSCOM_CONFIG: ParseSyscomConfig(msg); break;
                    case MsgId.MEVMSG_ID_RES_SYSCOM_ECHO: ParseSyscomEcho(msg); break;

                    case MsgId.MEVMSG_ID_RES_IMU_ECHO: ParseImuEcho(msg); break;
                    case MsgId.MEVMSG_ID_RES_IMU_STATUS: ParseImuStatus(msg); break;
                    case MsgId.MEVMSG_ID_RES_IMU_DEVICEPROFILE: ParseImuDeviceProfile(msg); break;
                    case MsgId.MEVMSG_ID_REP_IMU_MEASUREMENTACC: ParseImuMeasurementAccG(msg); break;
                    case MsgId.MEVMSG_ID_REP_IMU_MEASUREMENTCOMP: ParseImuMeasurementCompGa(msg); break;
                    case MsgId.MEVMSG_ID_REP_IMU_MEASUREMENTGYRO: ParseImuMeasurementGyroDeg(msg); break;

                    default: break;
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }


/*
 * Connect
 */
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_comm.IsConnect)
            {
                return;
            }

            OpenDialog dlg = new OpenDialog();
            if (_config.HostName == null)
                dlg.HostName = "192.168.1.35";
            else
                dlg.HostName = _config.HostName;

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                _config.HostName = dlg.HostName;
                serializeConfig(true);

                if (dlg.HostName == "")
                {
                    return;
                }
                else if (dlg.HostName.IndexOf("COM") == 0)
                {
                    _comm = new RczCommunication();
                    _comm.HostName = dlg.HostName;
                }
                else if (dlg.HostName.IndexOf("Vector") != -1 || dlg.HostName.IndexOf("Case") != -1 || dlg.HostName.IndexOf("XL") != -1)
                {
                    _comm = new RczCommunication();
                }
                else if (dlg.HostName.IndexOf(".") != -1)
                {
                    _comm = new RczCommunication();
                    _comm.PortNo = 9292;
                    _comm.HostName = string.Format("{0}", dlg.HostName);
                }
                _comm.Received += onReceived;
                _comm.OpenedOrClosed += onOpenedorClosed;
                if (_comm.Open())
                {
                }
                else
                {
                    MessageBox.Show("Can not open.");
                }
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_comm.IsConnect)
            {
                _comm.Close();
            }
        }

        private void onReceived(object sender)
        {
            string str = "Connect. (Data recieveing.)";
            toolStripStatusLabel1.Text = str;
        }

        private void onOpenedorClosed(object sender, bool bOpened)
        {
            string str;
            if (bOpened)
            {
                str = "Connect.";
                toolStripStatusLabel1.Text = str;
            }
            else
            {
                str = "Disonnect.";
            }
        }

        private void serializeConfig(bool save)
        {
            try
            {
                string path = Application.StartupPath + @"\PortOpenDialog.config.xml";
                XmlSerializer serializer = new XmlSerializer(typeof(connectConfig));
                if (save)
                {
                    FileStream fs = new FileStream(path, FileMode.Create);
                    serializer.Serialize(fs, _config);
                    fs.Close();
                }
                else
                {
                    FileStream fs = new FileStream(path, FileMode.Open);
                    _config = (connectConfig)serializer.Deserialize(fs);
                    fs.Close();
                }
            }
            catch (Exception)
            {
                // Ignore any.
            }

        }

/*
 * Mev tab
 */
        private void button_driveOn_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SetDriveServo(true));
        }

        private void button_driveOff_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SetDriveServo(false));
        }

        private void button_modeVeloc_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SetDriveMode((byte)DriveControlMode.VelocityControl));
        }

        private void button_modeTorque_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SetDriveMode((byte)DriveControlMode.Torque));
        }

        private void button_setVeloc_Click(object sender, EventArgs e)
        {
            float veloc = float.Parse(textBox_setDriveVeloc.Text);
            _comm.Send(MevPacket.SetDriveVelocityKm(veloc, veloc));
            hScrollBar_driveVeloc.Value = (int)(veloc * 10);
        }

        private void button_setVelocZero_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SetDriveVelocity(0.0f, 0.0f));
            textBox_setDriveVeloc.Text = "0.000";
            hScrollBar_driveVeloc.Value = 0;
        }

        private void hScrollBar_driveVeloc_Scroll(object sender, ScrollEventArgs e)
        {
            float value = hScrollBar_driveVeloc.Value / 10.0f;
            textBox_setDriveVeloc.Text = value.ToString("f1");
            _comm.Send(MevPacket.SetDriveVelocityKm(value, value));
        }

        private void button_setDriveTorque_Click(object sender, EventArgs e)
        {
            float torque = float.Parse(textBox_setDriveTorque.Text);
            _comm.Send(MevPacket.SetDriveTorque(torque, torque));
            hScrollBar_driveTorque.Value = (int)(torque * 1000);
        }

        private void button_setDriveTorqueZero_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SetDriveTorque(0, 0));
            textBox_setDriveTorque.Text = "0";
            hScrollBar_driveTorque.Value = 0;
        }

        private void hScrollBar_driveTorque_Scroll(object sender, ScrollEventArgs e)
        {
            float torque = hScrollBar_driveTorque.Value / 1000.0f;
            _comm.Send(MevPacket.SetDriveTorque(torque, torque));
            textBox_setDriveTorque.Text = ((float)hScrollBar_driveTorque.Value / 1000.0f).ToString("f3");
        }

        private void button_GetStatus_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.ReqDriveStatus());
        }

        private void button_steerOn_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SetSteerServo(true));
        }

        private void button_SteerOff_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SetSteerServo(false));
        }

        private void button_setSteerPos_Click(object sender, EventArgs e)
        {
            float pos = float.Parse(textBox_setSteerPos.Text);
            _comm.Send(MevPacket.SetSteerPosition(pos));
            hScrollBar_steerPos.Value = (int)(pos);
        }

        private void button_setSteerPosZero_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SetSteerPosition(0.0f));
            textBox_setSteerPos.Text = "0.0";
            hScrollBar_steerPos.Value = 0;
        }

        private void hScrollBar_steerPos_Scroll(object sender, ScrollEventArgs e)
        {
            float value = (float)(hScrollBar_steerPos.Value / 10.0f);
            _comm.Send(MevPacket.SetSteerPosition(value));
            textBox_setSteerPos.Text = value.ToString("f1");
        }

        private void button_reactOn_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SetReactServo(true));
        }

        private void button_reactOff_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SetReactServo(false));
        }

        private void button_modeReactPos_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SetReactMode((byte)SteerControlMode.Position));
        }

        private void button_modeReactTorque_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SetReactMode((byte)SteerControlMode.Torque));
        }

        private void button_setReactPos_Click(object sender, EventArgs e)
        {
            float pos = float.Parse(textBox_setReactPos.Text);
            _comm.Send(MevPacket.SetReactPosition(pos));
            hScrollBar_reactPos.Value = (int)(pos * 10);
        }

        private void button_setReactPosZero_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SetReactPosition(0.0f));
            textBox_setReactPos.Text = "0.0";
            hScrollBar_reactPos.Value = 0;
        }

        private void hScrollBar_reactPos_Scroll(object sender, ScrollEventArgs e)
        {
            float pos = ((float)hScrollBar_reactPos.Value / 10.0f);
            _comm.Send(MevPacket.SetReactPosition(pos));
            textBox_setReactPos.Text = pos.ToString("f1");
        }

        private void button_setReactTorque_Click(object sender, EventArgs e)
        {
            float torque = float.Parse(textBox_setReactTorque.Text);
            _comm.Send(MevPacket.SetReactTorque(torque));
            hScrollBar_ReactTorque.Value = (int)(torque * 1000);
        }

        private void button_setReactTorqueZero_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SetReactTorque(0));
            textBox_setReactTorque.Text = "0";
            hScrollBar_ReactTorque.Value = 0;
        }

        private void hScrollBar_ReactTorque_Scroll(object sender, ScrollEventArgs e)
        {
            float setT = hScrollBar_ReactTorque.Value / 1000.0f;
            _comm.Send(MevPacket.SetReactTorque(setT));
            textBox_setReactTorque.Text = (hScrollBar_ReactTorque.Value / 1000.0f).ToString("f3");
        }

        private void button_GetSteerStatus_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.ReqSteerStatus());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.ReqLogStart());
        }
        private void button1_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.ReqLogStop());
        }

        /*
         * Mev receive data
         */
        private void ParseDriveBatt(MevMsg msg)
        {
            float batt;
            _comm.ParseDriveBatt(msg, out batt);
            Invoke((MethodInvoker)delegate
            {
                textBox_mevVoltage.Text = batt.ToString("f1");
//                textBox_batteryLevel.Text = batt.ToString();
            });
        }

        private void ParseDriveEncoder(MevMsg msg)
        {
            RcvDriveEncoder enc = new RcvDriveEncoder();
            _comm.ParseDriveEncoder(msg, out enc);
            Invoke((MethodInvoker)delegate
            {
                textBox_enc1.Text = enc.enc[0].ToString();
                textBox_enc2.Text = enc.enc[1].ToString();
                textBox_enc3.Text = enc.enc[2].ToString();
                textBox_enc4.Text = enc.enc[3].ToString();
            });
        }

        private void ParseDriveMotorV(MevMsg msg)
        {
            RcvDriveMotorV veloc = new RcvDriveMotorV();
            _comm.ParseDriveMotorV(msg, out veloc);
            Invoke((MethodInvoker)delegate
            {
                textBox_targetVelocR.Text = veloc.targetVR.ToString("f2");
                textBox_targetVelocL.Text = veloc.targetVL.ToString("f2");
                textBox_actualVelocR.Text = veloc.actualVR.ToString("f2");
                textBox_actualVelocL.Text = veloc.actualVL.ToString("f2");
            });
        }

        private void ParseDriveMotorVKm(MevMsg msg)
        {
            float targetVR;
            float targetVL;
            float actualVR;
            float actualVL;
            _comm.ParseDriveMotorVKm(msg, out targetVR, out targetVL, out actualVR, out actualVL);
            Invoke((MethodInvoker)delegate
            {
                textBox_targetVelocR.Text = targetVR.ToString("f2");
                textBox_targetVelocL.Text = targetVL.ToString("f2");
                textBox_actualVelocR.Text = actualVR.ToString("f2");
                textBox_actualVelocL.Text = actualVL.ToString("f2");
            });
        }

        private void ParseDrivePedalInput(MevMsg msg)
        {
            int input;
            _comm.ParseDrivePedalInput(msg, out input);
            Invoke((MethodInvoker)delegate
            {
                textBox_drivePedalInput.Text = input.ToString();
            });
        }

        private void ParseDriveStatus(MevMsg msg)
        {
            RcvDriveStatus status = new RcvDriveStatus();
            _comm.ParseDriveStatus(msg, out status);
            Invoke((MethodInvoker)delegate
            {
                if (status.mode == 0x00)
                    textBox_driveMode.Text = "Manual";
                else if (status.mode == 0x01)
                    textBox_driveMode.Text = "Program";
                if (status.contMode == 0x00)
                    textBox_driveContMode.Text = "Velocity";
                else if (status.contMode == 0x01)
                    textBox_driveContMode.Text = "Torque";
                if (status.servo == 0x00)
                    textBox_driveServo.Text = "OFF";
                else
                    textBox_driveServo.Text = "ON";
                textBox_driveErrCode.Text = status.errCode.ToString("x");
            });
        }

        private void ParseDriveSwStatus(MevMsg msg)
        {
            RcvDriveSwStatus swStatus = new RcvDriveSwStatus();
            _comm.ParseDriveSwStatus(msg, out swStatus);
            Invoke((MethodInvoker)delegate
            {
                textBox_sw1.Text = swStatus.sw1.ToString();
                if (swStatus.sw3 == false && swStatus.sw4 == false)
                    textBox_sw2.Text = "true";
                else
                    textBox_sw2.Text = "false";
                textBox_sw3.Text = swStatus.sw3.ToString();
                textBox_sw4.Text = swStatus.sw4.ToString();
                textBox_mode1.Text = swStatus.mode1.ToString();
                textBox_mode2.Text = swStatus.mode2.ToString();
            });
        }

        private void ParseReactPos(MevMsg msg)
        {
            RcvReactPos pos = new RcvReactPos();
            _comm.ParseReactPos(msg, out pos);
            Invoke((MethodInvoker)delegate
            {
                textBox_reactActualPos.Text = (pos.actualPos/10.0f).ToString("f1");
                textBox_reactTargetPos.Text = (pos.targetPos/10.0f).ToString("f1");
            });
        }

        private void ParseReactTorque(MevMsg msg)
        {
            RcvReactTorque torque = new RcvReactTorque();
            _comm.ParseReactTorque(msg, out torque);
            Invoke((MethodInvoker)delegate
            {
                textBox_reactActualTorque.Text = (torque.actualTorque/1000.0f).ToString("f3");
                textBox_reactTargetTorque.Text = (torque.targetTorque/1000.0f).ToString("f3");
            });
        }

        private void ParseSteerPos(MevMsg msg)
        {
            RcvSteerPos pos = new RcvSteerPos();
            _comm.ParseSteerPos(msg, out pos);
            Invoke((MethodInvoker)delegate
            {
                textBox_steerActualPos.Text = (pos.actualPos/10.0f).ToString("f1");
                textBox_steerTargetPos.Text = (pos.targetPos/10.0f).ToString("f1");
            });
        }

        private void ParseSteerStatus(MevMsg msg)
        {
            RcvSteerStatus status = new RcvSteerStatus();
            _comm.ParseSteerStatus(msg, out status);
            Invoke((MethodInvoker)delegate
            {
                if (status.mode == 0x00)
                    textBox_steerMode.Text = "Manual";
                else if (status.mode == 0x01)
                    textBox_steerMode.Text = "Program";
                if (status.contMode == 0x00)
                    textBox_reactContMode.Text = "Position";
                else if (status.contMode == 0x02)
                    textBox_reactContMode.Text = "Torque";
                if (status.reactServo == 0x00)
                    textBox_reactServo.Text = "OFF";
                else
                    textBox_reactServo.Text = "ON";
                if (status.steerServo == 0x00)
                    textBox_steerServo.Text = "OFF";
                else
                    textBox_steerServo.Text = "ON";
                textBox_steerErrCode.Text = status.errCode.ToString("x");
            });
        }

        /*
         *  Config tab 
         */
        private void button_velocPGainRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.VelocityGainP, 1));
            _readConfTable = ConfigTable.VelocityGainP;
            _readConfLen = 1;
        }

        private void button_velocPGainWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.VelocityGainP, (int)numericUpDown_velocPgain.Value));
        }

        private void button_velocIGainRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.VelocityGainI, 1));
            _readConfTable = ConfigTable.VelocityGainI;
            _readConfLen = 1;
        }

        private void button_velocIGainWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.VelocityGainI, (int)numericUpDown_velocIgain.Value));
        }

        private void button_velocDGainRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.VelocityGainD, 1));
            _readConfTable = ConfigTable.VelocityGainD;
            _readConfLen = 1;
        }

        private void button_velocDGainWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.VelocityGainD, (int)numericUpDown_velocDgain.Value));
        }

        private void button_driveVelocLimitRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.LimitVelocity, 1));
            _readConfTable = ConfigTable.LimitVelocity;
            _readConfLen = 1;
        }

        private void button_driveVelocLimitWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.LimitVelocity, (int)numericUpDown_velocLimit.Value));
        }

        private void button_driveTorqueLimitRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.LimitTorque, 1));
            _readConfTable = ConfigTable.LimitTorque;
            _readConfLen = 1;
        }

        private void button_driveTorqueLimitWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.LimitTorque, (int)numericUpDown_driveTorqueLimit.Value));
        }

        private void button_driveLimitSUMRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.SumLimit, 1));
            _readConfTable = ConfigTable.SumLimit;
            _readConfLen = 1;
        }

        private void button_driveLimitSUMWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.SumLimit, (int)numericUpDown_SUMLimit.Value));
        }

        private void button_accRawMaxRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.AccRawMax, 1));
            _readConfTable = ConfigTable.AccRawMax;
            _readConfLen = 1;
        }

        private void button_accRawMaxWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.AccRawMax, (int)numericUpDown_accRawMax.Value));
        }

        private void button_accRawMinRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.AccRawMin, 1));
            _readConfTable = ConfigTable.AccRawMin;
            _readConfLen = 1;
        }

        private void button_accRawMinWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.AccRawMin, (int)numericUpDown_accRawMin.Value));
        }

        private void button_driveKeepAliveRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.DriveKeepAlive, 1));
            _readConfTable = ConfigTable.DriveKeepAlive;
            _readConfLen = 1;
        }

        private void button_driveKeepAliveWrite_Click(object sender, EventArgs e)
        {
            if (comboBox_driveKeepAlive.Text == "disable")
                _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.DriveKeepAlive, (int)KeepAliveParam.disable));
            else
                _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.DriveKeepAlive, (int)KeepAliveParam.SteerControl));
        }

        private void button_steerVelocRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.SteerVelocity, 1));
            _readConfTable = ConfigTable.SteerVelocity;
            _readConfLen = 1;
        }

        private void button_steerVelocWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.SteerVelocity, (int)numericUpDown_steerVeloc.Value));
        }

        private void button_steerGainRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.SteerGain, 1));
            _readConfTable = ConfigTable.SteerGain;
            _readConfLen = 1;
        }

        private void button_steerGainWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.SteerGain, (int)numericUpDown_steerGain.Value));
        }

        private void button_reactAccRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.ReactionAcc, 1));
            _readConfTable = ConfigTable.ReactionAcc;
            _readConfLen = 1;
        }

        private void button_reactAccWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.ReactionAcc, (int)numericUpDown_reactAcc.Value));
        }

        private void button_reactVelocRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.ReactionVelocity, 1));
            _readConfTable = ConfigTable.ReactionVelocity;
            _readConfLen = 1;
        }

        private void button_reactVelocWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.ReactionVelocity, (int)numericUpDown_reactVeloc.Value));
        }

        private void button_manualSteerVelocRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.ManualSteerVelocity, 1));
            _readConfTable = ConfigTable.ManualSteerVelocity;
            _readConfLen = 1;
        }

        private void button_manualSteerVelocWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.ManualSteerVelocity, (int)numericUpDown_manualSteerVeloc.Value));
        }

        private void button_manualSteerGainRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.ManualSteerGain, 1));
            _readConfTable = ConfigTable.ManualSteerGain;
            _readConfLen = 1;
        }

        private void button_manualSteerGainWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.ManualSteerGain, (int)numericUpDown_manualSteerGain.Value));
        }

        private void button_manualReactionGainRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.ManualReactGain, 1));
            _readConfTable = ConfigTable.ManualReactGain;
            _readConfLen = 1;
        }

        private void button_manualReactionGainWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.ManualReactGain, (int)numericUpDown_manualReactGain.Value));
        }

        private void button_steerKeepAliveRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.SteerKeepAlive, 1));
            _readConfTable = ConfigTable.SteerKeepAlive;
            _readConfLen = 1;
        }

        private void button_steerKeepAliveWrite_Click(object sender, EventArgs e)
        {
            if (comboBox_steerKeepAlive.Text == "disable")
                _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.SteerKeepAlive, (int)KeepAliveParam.disable));
            else
                _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.SteerKeepAlive, (int)KeepAliveParam.DriveControl));
        }

        private void button_configSave_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSaveConfig());
        }

        private void button_configReadAll_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.VelocityGainP, 1));
            _readConfTable = ConfigTable.VelocityGainP;
            _readConfLen = 1;
            _readConfAll = true;
        }

        private void button_getRawPedal_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.ReqDriveRawPedal());
        }

        private void button_hostIntervalLimitRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.HostIntervalLimit, 1));
            _readConfTable = ConfigTable.HostIntervalLimit;
            _readConfLen = 1;
        }

        private void button_hostIntervalLimitWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.HostIntervalLimit, (int)numericUpDown_hostIntervalLimit.Value));
        }

        private void button_steerOffsetRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.SteerOffset, 1));
            _readConfTable = ConfigTable.SteerOffset;
            _readConfLen = 1;
        }

        private void button_steerOffsetWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.SteerOffset, (int)numericUpDown_steerOffset.Value));
        }

        private void button_reactOffsetRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.ReactionOffset, 1));
            _readConfTable = ConfigTable.ReactionOffset;
            _readConfLen = 1;
        }

        private void button_reactOffsetWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.ReactionOffset, (int)numericUpDown_reactionOffset.Value));
        }

        private void button_manualRatioRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.ManualRatio, 1));
            _readConfTable = ConfigTable.ManualRatio;
            _readConfLen = 1;
        }

        private void button_manualRatioWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.ManualRatio, (int)numericUpDown_manualRatio.Value));
        }

        private void button_manualLockTorqueRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.ManualLockTorque, 1));
            _readConfTable = ConfigTable.ManualLockTorque;
            _readConfLen = 1;
        }

        private void button_manualLockTorqueWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.ManualLockTorque, (int)numericUpDown_manualLockTorque.Value));
        }

        private void button_manualReactionVGainRead_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndReadConfig((int)ConfigTable.ManualReactVGain, 1));
            _readConfTable = ConfigTable.ManualReactVGain;
            _readConfLen = 1;
        }

        private void button_manualReactionVGainWrite_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SndSetConfig((int)ConfigTable.ManualReactVGain, (int)numericUpDown_manualReactVGain.Value));
        }

/*
 * Config receive
 */
        private void ParseDriveRawPedal(MevMsg msg)
        {
            int rawPedal;
            _comm.ParseDriveRawPedal(msg, out rawPedal);
            Invoke((MethodInvoker)delegate
            {
                textbox_drivieRawPedalInput.Text = rawPedal.ToString();
            });
        }

        private void ParseSyscomConfig(MevMsg msg)
        {
            RcvSyscomConfig config = new RcvSyscomConfig();
            _comm.ParseSyscomConfig(msg, out config);
            for (int i = 0; i < _readConfLen; i++)
            {
                SelectConfigTable((ConfigTable)config.index, i, config.data[i]);
            }
            if (_readConfAll == true)
            {
                switch (_readConfTable)
                {
                    case ConfigTable.VelocityGainP: _readConfTable = ConfigTable.VelocityGainI; _readConfLen = 1; break;
                    case ConfigTable.VelocityGainI: _readConfTable = ConfigTable.VelocityGainD; _readConfLen = 1; break;
                    case ConfigTable.VelocityGainD: _readConfTable = ConfigTable.LimitVelocity; _readConfLen = 1; break;
                    case ConfigTable.LimitVelocity: _readConfTable = ConfigTable.LimitTorque; _readConfLen = 1; break;
                    case ConfigTable.LimitTorque: _readConfTable = ConfigTable.SumLimit; _readConfLen = 1; break;
                    case ConfigTable.SumLimit: _readConfTable = ConfigTable.AccRawMax; _readConfLen = 1; break;
                    case ConfigTable.AccRawMax: _readConfTable = ConfigTable.AccRawMin; _readConfLen = 1; break;
                    case ConfigTable.AccRawMin: _readConfTable = ConfigTable.HostIntervalLimit; _readConfLen = 1; break;
                    case ConfigTable.HostIntervalLimit: _readConfTable = ConfigTable.DriveKeepAlive; _readConfLen = 1; break;
                    case ConfigTable.DriveKeepAlive: _readConfTable = ConfigTable.SteerVelocity; _readConfLen = 1; break;

                    case ConfigTable.SteerVelocity: _readConfTable = ConfigTable.SteerGain; _readConfLen = 1; break;
                    case ConfigTable.SteerGain: _readConfTable = ConfigTable.ReactionAcc; _readConfLen = 1; break;
                    case ConfigTable.ReactionAcc: _readConfTable = ConfigTable.ReactionVelocity; _readConfLen = 1; break;
                    case ConfigTable.ReactionVelocity: _readConfTable = ConfigTable.ManualSteerVelocity; _readConfLen = 1; break;
                    case ConfigTable.ManualSteerVelocity: _readConfTable = ConfigTable.ManualSteerGain; _readConfLen = 1; break;
                    case ConfigTable.ManualSteerGain: _readConfTable = ConfigTable.ManualReactGain; _readConfLen = 1; break;
                    case ConfigTable.ManualReactGain: _readConfTable = ConfigTable.ManualReactVGain; _readConfLen = 1; break;
                    case ConfigTable.ManualReactVGain: _readConfTable = ConfigTable.ManualRatio; _readConfLen = 1; break;
                    case ConfigTable.ManualRatio: _readConfTable = ConfigTable.ManualLockTorque; _readConfLen = 1; break;
                    case ConfigTable.ManualLockTorque: _readConfTable = ConfigTable.SteerOffset; _readConfLen = 1; break;
                    case ConfigTable.SteerOffset: _readConfTable = ConfigTable.ReactionOffset; _readConfLen = 1; break;
                    case ConfigTable.ReactionOffset: _readConfTable = ConfigTable.SteerKeepAlive; _readConfLen = 1; break;
                    case ConfigTable.SteerKeepAlive: _readConfTable = ConfigTable.VelocityGainP; _readConfLen = 0; _readConfAll = false; break;
                    default: _readConfTable = ConfigTable.VelocityGainP; _readConfLen = 0; _readConfAll = false; break;
                }
                if(_readConfAll == true)
                    _comm.Send(MevPacket.SndReadConfig((int)_readConfTable, 1));
            }
        }

        private void SelectConfigTable(ConfigTable confTable, int index, int data)
        {
            switch (confTable + index)
            {
                case ConfigTable.VelocityGainP:
                    Invoke((MethodInvoker)delegate { numericUpDown_velocPgain.Value = data; });
                    break;
                case ConfigTable.VelocityGainI:
                    Invoke((MethodInvoker)delegate { numericUpDown_velocIgain.Value = data; });
                    break;
                case ConfigTable.VelocityGainD:
                    Invoke((MethodInvoker)delegate { numericUpDown_velocDgain.Value = data; });
                    break;
                case ConfigTable.LimitVelocity:
                    Invoke((MethodInvoker)delegate { numericUpDown_velocLimit.Value = data; });
                    break;
                case ConfigTable.LimitTorque:
                    Invoke((MethodInvoker)delegate { numericUpDown_driveTorqueLimit.Value = data; });
                    break;
                case ConfigTable.SumLimit:
                    Invoke((MethodInvoker)delegate { numericUpDown_SUMLimit.Value = data; });
                    break;
                case ConfigTable.AccRawMax:
                    Invoke((MethodInvoker)delegate { numericUpDown_accRawMax.Value = data; });
                    break;
                case ConfigTable.AccRawMin:
                    Invoke((MethodInvoker)delegate { numericUpDown_accRawMin.Value = data; });
                    break;
                case ConfigTable.DriveKeepAlive:
                    if (data == 0x00)
                    {
                        Invoke((MethodInvoker)delegate
                        {
                            comboBox_driveKeepAlive.SelectedIndex = 0;
                            comboBox_driveKeepAlive.Text = "disable";
                        });
                    }
                    else
                    {
                        Invoke((MethodInvoker)delegate
                        {
                            comboBox_driveKeepAlive.SelectedIndex = 1;
                            comboBox_driveKeepAlive.Text = "Steer";
                        });
                    }
                    break;
                case ConfigTable.HostIntervalLimit:
                    Invoke((MethodInvoker)delegate { numericUpDown_hostIntervalLimit.Value = data; });
                    break;
                case ConfigTable.SteerVelocity:
                    Invoke((MethodInvoker)delegate { numericUpDown_steerVeloc.Value = data; });
                    break;
                case ConfigTable.SteerGain:
                    Invoke((MethodInvoker)delegate { numericUpDown_steerGain.Value = data; });
                    break;
                case ConfigTable.ReactionAcc:
                    Invoke((MethodInvoker)delegate { numericUpDown_reactAcc.Value = data; });
                    break;
                case ConfigTable.ReactionVelocity:
                    Invoke((MethodInvoker)delegate { numericUpDown_reactVeloc.Value = data; });
                    break;
                case ConfigTable.ManualSteerVelocity:
                    Invoke((MethodInvoker)delegate { numericUpDown_manualSteerVeloc.Value = data; });
                    break;
                case ConfigTable.ManualSteerGain:
                    Invoke((MethodInvoker)delegate { numericUpDown_manualSteerGain.Value = data; });
                    break;
                case ConfigTable.ManualReactGain:
                    Invoke((MethodInvoker)delegate { numericUpDown_manualReactGain.Value = data; });
                    break;
                case ConfigTable.ManualReactVGain:
                    Invoke((MethodInvoker)delegate { numericUpDown_manualReactVGain.Value = data; });
                    break;
                case ConfigTable.ManualRatio:
                    Invoke((MethodInvoker)delegate { numericUpDown_manualRatio.Value = data; });
                    break;
                case ConfigTable.ManualLockTorque:
                    Invoke((MethodInvoker)delegate { numericUpDown_manualLockTorque.Value = data; });
                    break;
                case ConfigTable.SteerKeepAlive:
                    if (data == 0x00)
                    {
                        Invoke((MethodInvoker)delegate
                        {
                            comboBox_steerKeepAlive.SelectedIndex = 0;
                            comboBox_steerKeepAlive.Text = "disable";
                        });
                    }
                    else
                    {
                        Invoke((MethodInvoker)delegate
                        {
                            comboBox_steerKeepAlive.SelectedIndex = 0;
                            comboBox_steerKeepAlive.Text = "Drive";
                        });
                    }
                    break;
                case ConfigTable.SteerOffset:
                    Invoke((MethodInvoker)delegate { numericUpDown_steerOffset.Value = data; });
                    break;
                case ConfigTable.ReactionOffset:
                    Invoke((MethodInvoker)delegate { numericUpDown_reactionOffset.Value = data; });
                    break;
                default:
                    break;
            }
        }

        private void ParseSyscomEcho(MevMsg msg)
        {
            RcvSyscomEcho echo = new RcvSyscomEcho();
            _comm.ParseSyscomEcho(msg, out echo);
            Invoke((MethodInvoker)delegate
            {
            });
        }

/*
 * IMU tab
 */
        private void button_getIMUStatus_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.ReqImuStatus());
        }

        private void button_setImuStatus_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.SetImuPeriod((int)numericUpDown_ImuPeriod.Value));
            ImuAccRange acc = (ImuAccRange)comboBox_ImuAccRange.SelectedIndex;
            ImuGyroRange gyro = (ImuGyroRange)comboBox_ImuGyroRange.SelectedIndex;
            ImuCompRange comp = (ImuCompRange)comboBox_ImuCompRange.SelectedIndex;
            _comm.Send(MevPacket.SetImuRange((int)acc, (int)gyro, (int)comp));

        }

        private void button_GetImuProfile_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.ReqImuDeviceProfile());
        }

        private void button_ImuReqEcho_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.ReqImuEcho());
        }

        private void button_ImuResetTimeStamp_Click(object sender, EventArgs e)
        {
            _comm.Send(MevPacket.ResetTimeStamp());
        }

/*
 * Imu receive
 */
        private void ParseImuMeasurementAcc(MevMsg msg)
        {
            RcvImuAcc acc = new RcvImuAcc();
            _comm.ParseImuMeasurementAcc(msg, out acc);
            Invoke((MethodInvoker)delegate
            {
                textBox_AccX.Text = acc.accX.ToString();
                textBox_accY.Text = acc.accY.ToString();
                textBox_accZ.Text = acc.accZ.ToString();
            });
        }

        private void ParseImuMeasurementAccG(MevMsg msg)
        {
            ImuAccRange range = ImuAccRange.AccRange_2G;
            Invoke((MethodInvoker)delegate
            {
                range = (ImuAccRange)comboBox_ImuAccRange.SelectedIndex;
            });
            RcvImuAcc acc = new RcvImuAcc();
            _comm.ParseImuMeasurementAccG(msg, (byte)range, out acc);
            Invoke((MethodInvoker)delegate
            {
                textBox_AccX.Text = acc.accX.ToString();
                textBox_accY.Text = acc.accY.ToString();
                textBox_accZ.Text = acc.accZ.ToString();
            });
        }

        private void ParseImuMeasurementGyro(MevMsg msg)
        {
            RcvImuGyro gyro = new RcvImuGyro();
            _comm.ParseImuMeasurementGyro(msg, out gyro);
            Invoke((MethodInvoker)delegate
            {
                textBox_gyroX.Text = gyro.gyroX.ToString();
                textBox_gyroY.Text = gyro.gyroY.ToString();
                textBox_gyroZ.Text = gyro.gyroZ.ToString();
            });
        }

        private void ParseImuMeasurementGyroDeg(MevMsg msg)
        {
            ImuGyroRange range = ImuGyroRange.GyroRange_30;
            byte hard = 0;
            Invoke((MethodInvoker)delegate
            {
                if(comboBox_ImuAccRange.SelectedIndex >= 0)
                    range = (ImuGyroRange)comboBox_ImuGyroRange.SelectedIndex;
                if(textBox_imuHard.Text != "")
                    hard = byte.Parse(textBox_imuHard.Text);
            });
            RcvImuGyro gyro = new RcvImuGyro();
            _comm.ParseImuMeasurementGyroDeg(msg, (byte)range, (byte)hard, out gyro);
            Invoke((MethodInvoker)delegate
            {
                textBox_gyroX.Text = gyro.gyroX.ToString();
                textBox_gyroY.Text = gyro.gyroY.ToString();
                textBox_gyroZ.Text = gyro.gyroZ.ToString();
            });
        }

        private void ParseImuMeasurementComp(MevMsg msg)
        {
            RcvImuComp comp = new RcvImuComp();
            _comm.ParseImuMeasurementComp(msg, out comp);
            Invoke((MethodInvoker)delegate
            {
                textBox_compX.Text = comp.compX.ToString();
                textBox_compY.Text = comp.compY.ToString();
                textBox_compZ.Text = comp.compZ.ToString();
            });
        }

        private void ParseImuMeasurementCompGa(MevMsg msg)
        {
            ImuCompRange range = ImuCompRange.CompRange_10;
            Invoke((MethodInvoker)delegate
            {
                range = (ImuCompRange)comboBox_ImuCompRange.SelectedIndex;
            });
            RcvImuComp comp = new RcvImuComp();
            _comm.ParseImuMeasurementCompGa(msg, (byte)range, out comp);
            Invoke((MethodInvoker)delegate
            {
                textBox_compX.Text = comp.compX.ToString();
                textBox_compY.Text = comp.compY.ToString();
                textBox_compZ.Text = comp.compZ.ToString();
            });
        }

        private void ParseImuDeviceProfile(MevMsg msg)
        {
            RcvImuDeviceProfile profile = new RcvImuDeviceProfile();
            _comm.ParseImuDeviceProfile(msg, out profile);
            Invoke((MethodInvoker)delegate
            {
                textBox_imuHard.Text = profile.hard.ToString();
                textBox_imuFirm.Text = profile.firm.ToString();
                textBox_imuBtAdr.Text = "";
                for (int i = 3; i < 6; i++)
                {
                    textBox_imuBtAdr.Text += profile.btadr[i].ToString("x2");
                }
            });
        }

        private void ParseImuEcho(MevMsg msg)
        {
            RcvImuEcho echo = new RcvImuEcho();
            _comm.ParseImuEcho(msg, out echo);
            Invoke((MethodInvoker)delegate
            {
            });
        }

        private void ParseImuStatus(MevMsg msg)
        {
            RcvImuStatus status = new RcvImuStatus();
            _comm.ParseImuStatus(msg, out status);
            Invoke((MethodInvoker)delegate
            {
                if (status.role == 0x00)
                    textBox_ImuRole.Text = "SingleBT";
                else if (status.role == 0x01)
                    textBox_ImuRole.Text = "CanMasterBT";
                else if (status.role == 0x02)
                    textBox_ImuRole.Text = "CanSlave";

                numericUpDown_ImuPeriod.Value = status.period * 10;
                if(status.rangeAcc == 0x00){
                    comboBox_ImuAccRange.SelectedIndex = 0x00;
                    comboBox_ImuAccRange.Text = "-2～2G";
                }
                else if (status.rangeAcc == 0x01)
                {
                    comboBox_ImuAccRange.SelectedIndex = 0x01;
                    comboBox_ImuAccRange.Text = "-4～4G";
                }
                else if (status.rangeAcc == 0x02)
                {
                    comboBox_ImuAccRange.SelectedIndex = 0x02;
                    comboBox_ImuAccRange.Text = "-8～8G";
                }

                if (status.rangeGyro == 0x00)
                {
                    comboBox_ImuGyroRange.SelectedIndex = 0x00;
                    comboBox_ImuGyroRange.Text = "-30～30deg/sec";
                }
                else if (status.rangeGyro == 0x01)
                {
                    comboBox_ImuAccRange.SelectedIndex = 0x01;
                    comboBox_ImuAccRange.Text = "-120～120deg/sec";
                }
                if (status.rangeComp == 0x00)
                {
                    comboBox_ImuCompRange.SelectedIndex = 0x00;
                    comboBox_ImuCompRange.Text = "-0.7～0.7gauss";
                }
                else if (status.rangeComp == 0x01)
                {
                    comboBox_ImuCompRange.SelectedIndex = 0x01;
                    comboBox_ImuCompRange.Text = "-1.0～1.0gauss";
                }
                else if (status.rangeComp == 0x02)
                {
                    comboBox_ImuCompRange.SelectedIndex = 0x02;
                    comboBox_ImuCompRange.Text = "-1.5～1.5gauss";
                }
                else if (status.rangeComp == 0x03)
                {
                    comboBox_ImuCompRange.SelectedIndex = 0x03;
                    comboBox_ImuCompRange.Text = "-2.0～2.0gauss";
                }
                else if (status.rangeComp == 0x04)
                {
                    comboBox_ImuCompRange.SelectedIndex = 0x04;
                    comboBox_ImuCompRange.Text = "-3.2～3.2gauss";
                }
                else if (status.rangeComp == 0x05)
                {
                    comboBox_ImuCompRange.SelectedIndex = 0x05;
                    comboBox_ImuCompRange.Text = "-3.8～3.8gauss";
                }
                else if (status.rangeComp == 0x06)
                {
                    comboBox_ImuCompRange.SelectedIndex = 0x06;
                    comboBox_ImuCompRange.Text = "-4.5～4.5gauss";
                }
                textBox_ImuBattery.Text = status.batt.ToString();
                if (status.binary == 0x00)
                    textBox_ImuBinary.Text = "text";
                else
                    textBox_ImuBinary.Text = "binary";

            });
        }

	}

    public class connectConfig
    {
        public connectConfig() { }
        public string HostName { get; set; }
    }
}
