﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zmp.Rcz.Communication
{
    /// <summary>
    /// MEV message ID
    /// </summary>
	public enum MsgId
	{
        /// <summary>
        /// Set drive velocity message ID
        /// </summary>
        MEVMSG_ID_SET_DRIVE_VELOCITY = 0x01,
        /// <summary>
        /// Set drive velocity2 message ID
        /// </summary>
        MEVMSG_ID_SET_DRIVE_VELOCITY2 = 0x02,
        /// <summary>
        /// Set drive torque message ID
        /// </summary>
        MEVMSG_ID_SET_DRIVE_TORQUE = 0x03,
        /// <summary>
        /// Set drive torque2 message ID
        /// </summary>
        MEVMSG_ID_SET_DRIVE_TORQUE2 = 0x04,
        /// <summary>
        /// Set drive control mode message ID
        /// </summary>
        MEVMSG_ID_SET_DRIVE_CONTMODE = 0x05,
        /// <summary>
        /// Set drive servo message ID
        /// </summary>
        MEVMSG_ID_SET_DRIVE_SERVO = 0x06,
        /// <summary>
        /// Get drive status request message ID
        /// </summary>
        MEVMSG_ID_REQ_DRIVE_STATUS = 0x07,
//        MEVMSG_ID_REQ_DRIVE_PEDALINPUT = 0x08,
//        MEVMSG_ID_REQ_DRIVE_SWSTATUS = 0x09,
        /// <summary>
        /// Get drive raw pedal request message ID
        /// </summary>
        MEVMSG_ID_REQ_DRIVE_RAWPEDAL = 0x0a,
        /// <summary>
        /// Set drive velocity(km) message ID
        /// </summary>
        MEVMSG_ID_SET_DRIVE_VELOCITYKM = 0x0b,
        /// <summary>
        /// Set drive velocity2(km) message ID
        /// </summary>
        MEVMSG_ID_SET_DRIVE_VELOCITYKM2 = 0x0c,

        /// <summary>
        /// Receive drive motor velocity message ID
        /// </summary>
        MEVMSG_ID_RCV_DRIVE_MOTORV = 0x10,
        /// <summary>
        /// Receive drive encoder message ID
        /// </summary>
        MEVMSG_ID_RCV_DRIVE_ENCODER = 0x11,
        /// <summary>
        /// Receive drive status message ID
        /// </summary>
        MEVMSG_ID_RCV_DRIVE_STATUS = 0x12,
        /// <summary>
        /// Receive drive pedal input message ID
        /// </summary>
        MEVMSG_ID_RCV_DRIVE_PEDALINPUT = 0x13,
        /// <summary>
        /// Receive drive switch status message ID
        /// </summary>
        MEVMSG_ID_RCV_DRIVE_SWSTATUS = 0x14,
        /// <summary>
        /// Receive drive raw pedal message ID
        /// </summary>
        MEVMSG_ID_RCV_DRIVE_RAWPEDAL = 0x15,
        /// <summary>
        /// Receive drive battery message ID
        /// </summary>
        MEVMSG_ID_RCV_DRIVE_BATT = 0x16,

        /// <summary>
        /// Set reaction servo message ID
        /// </summary>
        MEVMSG_ID_SET_REACTION_SERVO = 0x20,
        /// <summary>
        /// Set reaction position message ID
        /// </summary>
        MEVMSG_ID_SET_REACTION_POSITION = 0x21,
        /// <summary>
        /// Set reaction torque message ID
        /// </summary>
        MEVMSG_ID_SET_REACTION_TORQUE = 0x22,
        /// <summary>
        /// Set reaction control mode message ID
        /// </summary>
        MEVMSG_ID_SET_REACTION_CONTMODE = 0x23,

        /// <summary>
        /// Receive reaction position data message ID
        /// </summary>
        MEVMSG_ID_RCV_REACTION_DATA1 = 0x30,
        /// <summary>
        /// Receive reaction torque data message ID
        /// </summary>
        MEVMSG_ID_RCV_REACTION_DATA2 = 0x31,

        // Steer
        /// <summary>
        /// Set steer servo message ID
        /// </summary>
        MEVMSG_ID_SET_STEER_SERVO = 0x40,
        /// <summary>
        /// Set steer position message ID
        /// </summary>
        MEVMSG_ID_SET_STEER_POSITION = 0x41,
//        MEVMSG_ID_SET_STEER_ZEROFLG = 0x42,
        /// <summary>
        /// Get steer status request message ID
        /// </summary>
        MEVMSG_ID_REQ_STEER_STATUS = 0x43,

        /// <summary>
        /// Receive steer status message ID
        /// </summary>
        MEVMSG_ID_RCV_STEER_STATUS = 0x50,
        /// <summary>
        /// Receive steer position message ID
        /// </summary>
        MEVMSG_ID_RCV_STEER_DATA = 0x51,

        // Brake
//        MEVMSG_ID_SET_BRAKE_TORQUE = 0x60,
//        MEVMSG_ID_REQ_BRAKE_PEDALINPUT = 0x61,

//        MEVMSG_ID_RCV_BRAKE_PEDALINPUT = 0x70,

        // System Common
        /// <summary>
        /// System common echo request message ID
        /// </summary>
        MEVMSG_ID_REQ_SYSCOM_ECHO = 0x80,
        /// <summary>
        /// Read config data request message ID
        /// </summary>
        MEVMSG_ID_READ_SYSCOM_CONFIG = 0x81,
        /// <summary>
        /// Set config data message ID
        /// </summary>
        MEVMSG_ID_SET_SYSCOM_CONFIG = 0x82,
        /// <summary>
        /// Save config data meddage ID
        /// </summary>
        MEVMSG_ID_SAVE_SYSCOM_CONFIG = 0x83,
//        MEVMSG_ID_SET_LOG_DATA = 0x84,
        /// <summary>
        /// Log start message ID
        /// </summary>
        MEVMSG_ID_REQ_LOG_START = 0x85,
        /// <summary>
        /// Log stop message ID
        /// </summary>
        MEVMSG_ID_REQ_LOG_STOP = 0x86,

        /// <summary>
        /// Receive system common echo message ID
        /// </summary>
        MEVMSG_ID_RES_SYSCOM_ECHO = 0x90,
        /// <summary>
        /// Receive config data message ID
        /// </summary>
        MEVMSG_ID_RES_SYSCOM_CONFIG = 0x91,

        // IMU
        /// <summary>
        /// IMU echo request message ID
        /// </summary>
        MEVMSG_ID_REQ_IMU_ECHO = 0xa0,
        /// <summary>
        /// Get IMU status request message ID
        /// </summary>
        MEVMSG_ID_REQ_IMU_STATUS = 0xa1,
//        MEVMSG_ID_SND_IMU_SAVE = 0xa2,
//        MEVMSG_ID_SND_IMU_FACTRESET = 0xa3,
//        MEVMSG_ID_SET_IMU_BINARY = 0xa4,
//        MEVMSG_ID_SET_IMU_ROLE = 0xa5,
        /// <summary>
        /// Set IMU period message ID
        /// </summary>
        MEVMSG_ID_SET_IMU_PERIOD = 0xa6,
        /// <summary>
        /// Set IMU range message ID
        /// </summary>
        MEVMSG_ID_SET_IMU_RANGE = 0xa7,
        /// <summary>
        /// IMU reset time stamp message ID
        /// </summary>
        MEVMSG_ID_SND_IMU_RESETTIMESTAMP = 0xa8,
        /// <summary>
        /// Set IMU measurement state message ID
        /// </summary>
        MEVMSG_ID_SET_IMU_MEASUREMENTSTATE = 0xa9,
        /// <summary>
        /// Get IMU device profile request message ID
        /// </summary>
        MEVMSG_ID_REQ_IMU_DEVICEPROFILE = 0xaa,
        /// <summary>
        /// Receive IMU echo message ID
        /// </summary>
        MEVMSG_ID_RES_IMU_ECHO = 0xb0,
        /// <summary>
        /// Receive IMU status message ID
        /// </summary>
        MEVMSG_ID_RES_IMU_STATUS = 0xb1,
        /// <summary>
        /// Receive IMU device profile message ID
        /// </summary>
        MEVMSG_ID_RES_IMU_DEVICEPROFILE = 0xb2,
        /// <summary>
        /// Receive IMU measurement acc data message ID
        /// </summary>
        MEVMSG_ID_REP_IMU_MEASUREMENTACC = 0xb3,
        /// <summary>
        /// Receive IMU measurement gyro data message ID
        /// </summary>
        MEVMSG_ID_REP_IMU_MEASUREMENTGYRO = 0xb4,
        /// <summary>
        /// Receive IMU measurement comp data message ID
        /// </summary>
        MEVMSG_ID_REP_IMU_MEASUREMENTCOMP = 0xb5,

        // PositionZ
        /// <summary>
        /// PositionZ echo message ID
        /// </summary>
        MEVMSG_ID_REQ_POS_ECHO = 0xc0,
        /// <summary>
        /// Get PositionZ status request message ID
        /// </summary>
        MEVMSG_ID_REQ_POS_STATUS = 0xc1,
        /// <summary>
        /// Get PositionZ device profile message ID
        /// </summary>
        MEVMSG_ID_REQ_POS_DEVICEPROFILE = 0xc2,
//        MEVMSG_ID_SND_POS_FACTORYRESET = 0xc3,
        /// <summary>
        /// Set PositionZ measurement state message ID
        /// </summary>
        MEVMSG_ID_SET_POS_MEASUREMENTSTATE = 0xc4,
        /// <summary>
        /// Set PositionZ period message ID
        /// </summary>
        MEVMSG_ID_SET_POS_PERIOD = 0xc5,

        /// <summary>
        /// Receive PositionZ echo message ID
        /// </summary>
        MEVMSG_ID_RES_POS_ECHO = 0xd0,
        /// <summary>
        /// Receive PositionZ status message ID
        /// </summary>
        MEVMSG_ID_RES_POS_STATUS = 0xd1,
        /// <summary>
        /// Receive PositionZ device profile message ID
        /// </summary>
        MEVMSG_ID_RES_POS_DEVICE_PROFILE = 0xd2,
        /// <summary>
        /// Receive PositionZ GPS data message ID
        /// </summary>
        MEVMSG_ID_REP_POS_GPS = 0xd3,
        /// <summary>
        /// Receive PositionZ pressure data message ID
        /// </summary>
        MEVMSG_ID_REP_POS_PRESSURE = 0xd4,
        /// <summary>
        /// Receive PositionZ humidity data message ID
        /// </summary>
        MEVMSG_ID_REP_POS_HUMIDITY = 0xd5,
	}

//	public struct RczMsg
//	{
//		public MsgId MsgId { get; set; }
//	}
    /// <summary>
    /// MEV message format
    /// </summary>
    public class MevMsg
    {
        /// <summary>
        /// message header(2byte, 0xac 0xca)
        /// </summary>
        public byte[] header{get; set;}
        /// <summary>
        /// message length
        /// </summary>
        public ulong len { get; set; }
        /// <summary>
        /// message id(enum MsgId)
        /// </summary>
        public byte id { get; set; }
        /// <summary>
        /// message data
        /// </summary>
        public byte[] data { get; set; }
    }

	/*
	 * struct RczHMsg {
     *     uchar   header[2];
     *     ulong   length;
     *     uchar   msg_id;
	 * };
     * //MEVMSG_ID_SET_DRIVE_STATUS
	 * struct MevHMsgSetDriveStatus : public RczHMsg
	 * {
	 *     DRIVE_CONTROL_MODE mode; // 0:Veloc 1:Torque
	 * };
	 *
	 * //MEVMSG_ID_SET_DRIVE_SERVO
	 * struct MevHMsgSetDriveServo : public RczHMsg
	 * {
	 *     bool enable;
	 * };
	 *
	 * //MEVMSG_ID_SET_DRIVE_SPEED2
	 * struct MevHMsgSetDriveSpeed2 : public RczHMsg
	 * {
	 *     float rightSpeed;
	 *     float leftSpeed;
	 * };
	 * 
	 * //MEVMSG_ID_SET_STEER_SERVO
	 * struct MevHMsgSetSteerServo : public RczHMsg
	 * {
	 *     bool enable;
	 * };
	 * 
	 * // MEVMSG_ID_SET_STEER_POSITION
	 * struct MevHMsgSetSteerPosition : public RczHMsg
	 * {
	 *     float position;
	 * };
	 * 
	 * //MEVMSG_ID_SET_REACTION_CONTMODE
	 * struct MevHMsgSetReactionContMode : public RczHMsg
	 * {
	 *     int mode;
	 * };
	 * 
	 * //MEVMSG_ID_SET_REACTION_SERVO
	 * struct MevHMsgSetReactionServo : public RczHMsg
	 * {
	 *     bool enable;
	 * };
	 * 
	 * //MEVMSG_ID_SET_REACTION_POSITION
	 * struct MevHMsgSetReactionPosition : public RczHMsg
	 * {
	 *     float position;
	 * };
	 * 
	 */
    /// <summary>
    /// MEV message generation class.
    /// </summary>
	public static class MevPacket
	{
        /// <summary>
        /// Set drive velocity
        /// </summary>
        /// <param name="vr">right velocity[rev/sec](-6.0～12.0)</param>
        /// <param name="vl">left velocity[rev/sec](-6.0～12.0)</param>
        /// <returns>message</returns>
        public static byte[] SetDriveVelocity(float vr, float vl)
        {
            int len = 7 + 8;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_SET_DRIVE_VELOCITY2;
            BitConverter.GetBytes((float)vr).CopyTo(pkt, 7);
            BitConverter.GetBytes((float)vl).CopyTo(pkt, 11);
            return pkt;
        }
        /// <summary>
        /// Set drive velocity[Km]
        /// </summary>
        /// <param name="vr">right velocity[km](-30.0～60.0)</param>
        /// <param name="vl">left velocity[km](-30.0～60.0)</param>
        /// <returns>message</returns>
        public static byte[] SetDriveVelocityKm(float vr, float vl)
        {
            int len = 7 + 8;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_SET_DRIVE_VELOCITYKM2;
            BitConverter.GetBytes((float)vr).CopyTo(pkt, 7);
            BitConverter.GetBytes((float)vl).CopyTo(pkt, 11);
            return pkt;
        }
        /// <summary>
        /// Set drive torque
        /// </summary>
        /// <param name="tr">right torque(-1.0～1.0)</param>
        /// <param name="tl">left torque(-1.0～1.0)</param>
        /// <returns>message</returns>
        public static byte[] SetDriveTorque(float tr, float tl)
        {
            int len = 7 + 8;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_SET_DRIVE_TORQUE2;
            BitConverter.GetBytes((float)tr).CopyTo(pkt, 7);
            BitConverter.GetBytes((float)tl).CopyTo(pkt, 11);
            return pkt;
        }
        /// <summary>
		/// Set drive control mode
		/// </summary>
		/// <param name="mode">control mode(0:Veloc 1:Torque)</param>
		/// <returns>message</returns>
        public static byte[] SetDriveMode(byte mode)
		{
			int len = 7 + 4;
			byte[] pkt = new byte[len];
			pkt[0] = 0xac;
			pkt[1] = 0xca;
			BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
			pkt[6] = (byte)MsgId.MEVMSG_ID_SET_DRIVE_CONTMODE;
            BitConverter.GetBytes((uint)mode).CopyTo(pkt, 7);
            return pkt;
		}
        /// <summary>
        /// Set drive servo
        /// </summary>
        /// <param name="on">drive servo(ON/OFF)</param>
        /// <returns>message</returns>
		public static byte[] SetDriveServo(bool on)
		{
			int len = 7 + 1;
			byte[] pkt = new byte[len];
			pkt[0] = 0xac;
			pkt[1] = 0xca;
			BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
			pkt[6] = (byte)MsgId.MEVMSG_ID_SET_DRIVE_SERVO;
			pkt[7] = (byte)(on ? 0x01 : 0x00);
			return pkt;
		}
        /// <summary>
        /// Get drive status request
        /// </summary>
        /// <returns>message</returns>
        public static byte[] ReqDriveStatus()
        {
            int len = 7;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_REQ_DRIVE_STATUS;
            return pkt;
        }
        /// <summary>
        /// Get drive raw pedal request
        /// </summary>
        /// <returns>message</returns>
        public static byte[] ReqDriveRawPedal()
        {
            int len = 7;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_REQ_DRIVE_RAWPEDAL;
            return pkt;
        }
        /// <summary>
        /// Set reaction torque
        /// </summary>
        /// <param name="torque">target torque(-1.0～1.0)</param>
        /// <returns>message</returns>
        public static byte[] SetReactTorque(float torque)
        {
            int len = 7 + 4;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_SET_REACTION_TORQUE;
            BitConverter.GetBytes((float)torque).CopyTo(pkt, 7);
            return pkt;
        }
        /// <summary>
        /// Set reaction position
        /// </summary>
        /// <param name="deg">target position[deg] Left(+450) - Center(0) - Right(-450)</param>
        /// <returns>message</returns>
        public static byte[] SetReactPosition(float deg)
        {
            int len = 7 + 4;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_SET_REACTION_POSITION;
            BitConverter.GetBytes((float)deg).CopyTo(pkt, 7);
            return pkt;
        }
        /// <summary>
        /// Set reaction servo
        /// </summary>
        /// <param name="on">reaction servo(ON/OFF)</param>
        /// <returns>message</returns>
        public static byte[] SetReactServo(bool on)
        {
            int len = 7 + 1;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_SET_REACTION_SERVO;
            pkt[7] = (byte)(on ? 0x01 : 0x00);
            return pkt;
        }
        /// <summary>
        /// Set reaction control mode
        /// </summary>
        /// <param name="mode">control mode(0:Pos 2:Torque)</param>
        /// <returns>message</returns>
        public static byte[] SetReactMode(byte mode)
        {
            int len = 7 + 4;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_SET_REACTION_CONTMODE;
            BitConverter.GetBytes((uint)mode).CopyTo(pkt, 7);
            return pkt;
        }
        /// <summary>
        /// Set steer servo
        /// </summary>
        /// <param name="on">steer servo(ON/OFF)</param>
        /// <returns>message</returns>
        public static byte[] SetSteerServo(bool on)
		{
			int len = 7 + 1;
			byte[] pkt = new byte[len];
			pkt[0] = 0xac;
			pkt[1] = 0xca;
			BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
			pkt[6] = (byte)MsgId.MEVMSG_ID_SET_STEER_SERVO;
			pkt[7] = (byte)(on ? 0x01 : 0x00);
			return pkt;
		}
		/// <summary>
		/// Set steer position
		/// </summary>
		/// <param name="deg">target position[deg] Left(+450) - Center(0) - Right(-450)</param>
		/// <returns>message</returns>
		public static byte[] SetSteerPosition(float deg)
		{
			int len = 7 + 4;
			byte[] pkt = new byte[len];
			pkt[0] = 0xac;
			pkt[1] = 0xca;
			BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
			pkt[6] = (byte)MsgId.MEVMSG_ID_SET_STEER_POSITION;
			BitConverter.GetBytes((float)deg).CopyTo(pkt, 7);
			return pkt;
		}
        /// <summary>
        /// Get steer status request
        /// </summary>
        /// <returns>message</returns>
        public static byte[] ReqSteerStatus()
        {
            int len = 7;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_REQ_STEER_STATUS;
            return pkt;
        }
        /// <summary>
        /// System common echo request
        /// </summary>
        /// <returns>message</returns>
        public static byte[] SndEchoRequest()
        {
            int len = 7;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_REQ_SYSCOM_ECHO;
            return pkt;
        }
        /// <summary>
        /// Read config request
        /// </summary>
        /// <param name="index">config table index</param>
        /// <param name="num">number of data</param>
        /// <returns>message</returns>
        public static byte[] SndReadConfig(int index, int num)
        {
            int len = 7 + 8;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_READ_SYSCOM_CONFIG;
            BitConverter.GetBytes((int)index).CopyTo(pkt, 7);
            BitConverter.GetBytes((int)num).CopyTo(pkt, 11);
            return pkt;
        }
        /// <summary>
        /// Set config data
        /// </summary>
        /// <param name="index">config table index</param>
        /// <param name="data">config data</param>
        /// <returns>message</returns>
        public static byte[] SndSetConfig(int index, int data)
        {
            int len = 7 + 8;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_SET_SYSCOM_CONFIG;
            BitConverter.GetBytes((int)index).CopyTo(pkt, 7);
            BitConverter.GetBytes((int)data).CopyTo(pkt, 11);
            return pkt;
        }
        /// <summary>
        /// Config save request
        /// </summary>
        /// <returns>message</returns>
        public static byte[] SndSaveConfig()
        {
            int len = 7;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_SAVE_SYSCOM_CONFIG;
            return pkt;
        }
        /// <summary>
        /// IMU echo request
        /// </summary>
        /// <returns>message</returns>
        public static byte[] ReqImuEcho()
        {
            int len = 7;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_REQ_IMU_ECHO;
            return pkt;
        }
        /// <summary>
        /// Get IMU status request
        /// </summary>
        /// <returns>message</returns>
        public static byte[] ReqImuStatus()
        {
            int len = 7;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_REQ_IMU_STATUS;
            return pkt;
        }
        /// <summary>
        /// Set IMU period
        /// </summary>
        /// <param name="period">period[ms](10～10000)</param>
        /// <returns>message</returns>
        public static byte[] SetImuPeriod(int period)
        {
            int len = 7 + 4;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_SET_IMU_PERIOD;
            BitConverter.GetBytes((int)period).CopyTo(pkt, 7);
            return pkt;
        }
        /// <summary>
        /// Set IMU range
        /// </summary>
        /// <param name="accRange">Acc range</param>
        /// <param name="gyroRange">gyro range</param>
        /// <param name="compRange">comp range</param>
        /// <returns>message</returns>
        public static byte[] SetImuRange(int accRange, int gyroRange, int compRange)
        {
            int len = 7 + 12;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_SET_IMU_RANGE;
            BitConverter.GetBytes((int)accRange).CopyTo(pkt, 7);
            BitConverter.GetBytes((int)gyroRange).CopyTo(pkt, 11);
            BitConverter.GetBytes((int)compRange).CopyTo(pkt, 15);
            return pkt;
        }
        /// <summary>
        /// Reset IMU time stamp
        /// </summary>
        /// <returns>message</returns>
        public static byte[] ResetTimeStamp()
        {
            int len = 7;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_SND_IMU_RESETTIMESTAMP;
            return pkt;
        }
        /// <summary>
        /// Set IMU Measurement state
        /// </summary>
        /// <param name="enable">measurement state(true/false)</param>
        /// <returns>message</returns>
        public static byte[] SetImuMeasurementState(bool enable)
        {
            int len = 7 + 1;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_SET_IMU_MEASUREMENTSTATE;
            pkt[7] = (byte)(enable ? 0x01 : 0x00);
            return pkt;
        }
        /// <summary>
        /// Get IMU device Profile request
        /// </summary>
        /// <returns>message</returns>
        public static byte[] ReqImuDeviceProfile()
        {
            int len = 7;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_REQ_IMU_DEVICEPROFILE;
            return pkt;
        }
        /// <summary>
        /// PositionZ echo request
        /// </summary>
        /// <returns>message</returns>
        public static byte[] ReqPosEcho()
        {
            int len = 7;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_REQ_POS_ECHO;
            return pkt;
        }
        /// <summary>
        /// Get PositionZ status request
        /// </summary>
        /// <returns>message</returns>
        public static byte[] ReqPosStatus()
        {
            int len = 7;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_REQ_POS_STATUS;
            return pkt;
        }
        /// <summary>
        /// Set PositionZ measurement state
        /// </summary>
        /// <param name="enable">measurement state(true/false)</param>
        /// <param name="gpsType">gps type(simple/ALL)</param>
        /// <returns>message</returns>
        public static byte[] SetPosMeasurementState(bool enable, byte gpsType)
        {
            int len = 7 + 2;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_SET_POS_MEASUREMENTSTATE;
            pkt[7] = (byte)(enable ? 0x01 : 0x00);
            pkt[8] = gpsType;
            return pkt;
        }
        /// <summary>
        /// Set PositionZ period
        /// </summary>
        /// <param name="gps">gps period[ms]</param>
        /// <param name="press">press period[ms]</param>
        /// <param name="humid">humid period[ms]</param>
        /// <returns>message</returns>
        public static byte[] SetPosPeriod(int gps, int press, int humid)
        {
            int len = 7 + 6;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_SET_POS_PERIOD;
            BitConverter.GetBytes((short)gps).CopyTo(pkt, 7);
            BitConverter.GetBytes((short)press).CopyTo(pkt, 9);
            BitConverter.GetBytes((short)humid).CopyTo(pkt, 11);
            return pkt;
        }
        /// <summary>
        /// Get PositionZ device pofile request
        /// </summary>
        /// <returns>message</returns>
        public static byte[] ReqPosDeviceProfile()
        {
            int len = 7;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_REQ_POS_DEVICEPROFILE;
            return pkt;
        }
        /// <summary>
        /// Log start request
        /// </summary>
        /// <returns>message</returns>
        public static byte[] ReqLogStart()
        {
            int len = 7;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_REQ_LOG_START;
            return pkt;
        }
        /// <summary>
        /// Log stop request
        /// </summary>
        /// <returns>message</returns>
        public static byte[] ReqLogStop()
        {
            int len = 7;
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)MsgId.MEVMSG_ID_REQ_LOG_STOP;
            return pkt;
        }
	}
}
