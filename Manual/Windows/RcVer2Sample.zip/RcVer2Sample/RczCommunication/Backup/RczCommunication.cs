﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zmp.Rcz.Communication
{
    /// <summary>
    /// GPS data type
    /// </summary>
    public enum GPS_DATA_TYPE
    {
        /// <summary>
        /// Global positioning system fix data.
        /// (UTC time, latitude, longitude, quality, satellite num, hdop, sea level altitude, geoid level, age of DGPS, DGPS station ID)
        /// </summary>
        GPS_DATA_GGA,
        /// <summary>
        /// Date and time.
        /// (UTC time, UTC date)
        /// </summary>
        GPS_DATA_ZDA,
        /// <summary>
        /// Geographic position, latitude/longitude.
        /// (latitude, longitude, UTC time, receive status, quality)
        /// </summary>
        GPS_DATA_GLL,
        /// <summary>
        /// GPS DOP and active satellites.
        /// (mode, status, satellite num[12], pdop, hdop, vdop)
        /// </summary>
        GPS_DATA_GSA,
        /// <summary>
        /// GPS satellites view
        /// (number of message, number of satellite, satellite information[4])
        /// </summary>
        GPS_DATA_GSV,
        /// <summary>
        /// Vector track an speed over the ground.
        /// (direction of true north, direction of magnetic north, ground speed knots, ground speed kilometers per hour)
        /// </summary>
        GPS_DATA_VTG,
        /// <summary>
        /// Recommended minimum specific GPS/TRNSIT data.
        /// (UTC time, latitude, longitude, speed
        /// </summary>
        GPS_DATA_RMC,
    };
    /// <summary>
    /// GPS quality type
    /// </summary>
    public enum GPS_QUALITY_TYPE
    {
        /// <summary>
        /// not valiable.
        /// </summary>
        GPS_QUALITY_NOTAVAILABLE,
        /// <summary>
        /// stand alone.
        /// </summary>
        GPS_QUALITY_STANDALONE,
        /// <summary>
        /// DGPS.
        /// </summary>
        GPS_QUALITY_DGPS,
    };
    /// <summary>
    /// GPS receive status
    /// </summary>
    public enum GPS_RECEIVE_STATUS
    {
        /// <summary>
        /// available.
        /// </summary>
        GPS_RECEIVE_AVAILABLE,
        /// <summary>
        /// void.
        /// </summary>
        GPS_RECEIVE_VOID,
    };
    /// <summary>
    /// GPS measurement mode.
    /// </summary>
    public enum GPS_MEASUREMENT_MODE
    {
        /// <summary>
        /// auto detect.
        /// </summary>
        GPS_MODE_AUTODETECT,
        /// <summary>
        /// manual select.
        /// </summary>
        GPS_MODE_MANUALSELECT,
    };
    /// <summary>
    /// GPS measurement status.
    /// </summary>
    public enum GPS_MEASUREMENT_STATUS
    {
        /// <summary>
        /// void.
        /// </summary>
        GPS_STATUS_VOID,
        /// <summary>
        /// two dimension.
        /// </summary>
        GPS_STATUS_TWODIMENSION,
        /// <summary>
        /// three dimension.
        /// </summary>
        GPS_STATUS_THREEDIMENSION,
    };
    /// <summary>
    /// GPS satellite information
    /// </summary>
    public struct GpsSatelliteInfo
    {
        /// <summary>
        /// satellite number.
        /// </summary>
        public int satteliteNo;
        /// <summary>
        /// elevation.
        /// </summary>
        public double elevation;
        /// <summary>
        /// 
        /// </summary>
        public double azimuth;
        /// <summary>
        /// 
        /// </summary>
        public float snr;
    };
    /// <summary>
    /// Drive encoder data.
    /// </summary>
    public struct RcvDriveEncoder
    {
        /// <summary>
        /// drive encoder[4].(enc[0]=left front, enc[1]=right front, enc[2]=left rear, enc[3]=right rear)
        /// </summary>
        public int[] enc;
    };
    /// <summary>
    /// Drive motor velocity
    /// </summary>
    public struct RcvDriveMotorV
    {
        /// <summary>
        /// target velocity of right motor.
        /// </summary>
        public float targetVR;
        /// <summary>
        /// target velocity of left motor.
        /// </summary>
        public float targetVL;
        /// <summary>
        /// actual velocity of right motor.
        /// </summary>
        public float actualVR;
        /// <summary>
        /// actual velocity of left motor.
        /// </summary>
        public float actualVL;
    };
    /// <summary>
    /// Drive status.
    /// </summary>
    public struct RcvDriveStatus
    {
        /// <summary>
        /// system mode.(manual/program)
        /// </summary>
        public int mode;
        /// <summary>
        /// control mode.(velocity/torque)
        /// </summary>
        public int contMode;
        /// <summary>
        /// drive servo.(ON/OFF)
        /// </summary>
        public byte servo;
        /// <summary>
        /// error code.(2byte)
        /// </summary>
        public short errCode;
    };
    /// <summary>
    /// Drive switch status
    /// </summary>
    public struct RcvDriveSwStatus
    {
        /// <summary>
        /// brake pedal status.(ON/OFF)
        /// </summary>
        public bool sw1;
        /// <summary>
        /// neutral status.(ON/OFF)
        /// </summary>
        public bool sw2;
        /// <summary>
        /// reverse status.(ON/OFF)
        /// </summary>
        public bool sw3;
        /// <summary>
        /// drive status.(ON/OFF)
        /// </summary>
        public bool sw4;
        /// <summary>
        /// 
        /// </summary>
        public byte mode1;
        /// <summary>
        /// 
        /// </summary>
        public byte mode2;
    };
    /// <summary>
    /// Reaction motor position.
    /// </summary>
    public struct RcvReactPos
    {
        /// <summary>
        /// target position.
        /// </summary>
        public float targetPos;
        /// <summary>
        /// actual position.
        /// </summary>
        public float actualPos;
    };
    /// <summary>
    /// Reaction motor torque.
    /// </summary>
    public struct RcvReactTorque
    {
        /// <summary>
        /// target torque.
        /// </summary>
        public float targetTorque;
        /// <summary>
        /// actual torque.
        /// </summary>
        public float actualTorque;
    };
    /// <summary>
    /// Steer motor position.
    /// </summary>
    public struct RcvSteerPos
    {
        /// <summary>
        /// target position.
        /// </summary>
        public float targetPos;
        /// <summary>
        /// actual position.
        /// </summary>
        public float actualPos;
    };
    /// <summary>
    /// .Steer status.
    /// </summary>
    public struct RcvSteerStatus
    {
        /// <summary>
        /// system mode.(manual/program)
        /// </summary>
        public int mode;
        /// <summary>
        /// control mode.(position/torque)
        /// </summary>
        public int contMode;
        /// <summary>
        /// reaction servo.(ON/OFF)
        /// </summary>
        public byte reactServo;
        /// <summary>
        /// steer servo.(ON/OFF)
        /// </summary>
        public byte steerServo;
        /// <summary>
        /// error code.(2byte)
        /// </summary>
        public short errCode;
    };
    /// <summary>
    /// Config data.
    /// </summary>
    public struct RcvSyscomConfig
    {
        /// <summary>
        /// config table index.
        /// </summary>
        public int index;
        /// <summary>
        /// config data.
        /// </summary>
        public int[] data;
    };
    /// <summary>
    /// System common echo.
    /// </summary>
    public struct RcvSyscomEcho
    {
        /// <summary>
        /// message group.
        /// </summary>
        public int group;
        /// <summary>
        /// device number.
        /// </summary>
        public int num;
    };
    /// <summary>
    /// IMU Acc data.
    /// </summary>
    public struct RcvImuAcc
    {
        /// <summary>
        /// X axis.
        /// </summary>
        public double accX;
        /// <summary>
        /// Y axis.
        /// </summary>
        public double accY;
        /// <summary>
        /// Z axis.
        /// </summary>
        public double accZ;
        /// <summary>
        /// time.
        /// </summary>
        public int time;
    };
    /// <summary>
    /// IMU gyro data.
    /// </summary>
    public struct RcvImuGyro
    {
        /// <summary>
        /// X axis.
        /// </summary>
        public double gyroX;
        /// <summary>
        /// Y axis.
        /// </summary>
        public double gyroY;
        /// <summary>
        /// Z axis.
        /// </summary>
        public double gyroZ;
        /// <summary>
        /// time.
        /// </summary>
        public int time;
    };
    /// <summary>
    /// IMU comp data.
    /// </summary>
    public struct RcvImuComp
    {
        /// <summary>
        /// X axis.
        /// </summary>
        public double compX;
        /// <summary>
        /// Y axis.
        /// </summary>
        public double compY;
        /// <summary>
        /// Z axis.
        /// </summary>
        public double compZ;
        /// <summary>
        /// time.
        /// </summary>
        public int time;
    };
    /// <summary>
    /// IMU device profile.
    /// </summary>
    public struct RcvImuDeviceProfile
    {
        /// <summary>
        /// hardware version.
        /// </summary>
        public byte hard;
        /// <summary>
        /// firmware version.
        /// </summary>
        public byte firm;
        /// <summary>
        /// Bluetooth address[6].
        /// </summary>
        public byte[] btadr;
    };
    /// <summary>
    /// IMU status.
    /// </summary>
    public struct RcvImuStatus
    {
        /// <summary>
        /// role.(0=Single bluetooth, 1=CAN master bluetooth, 2=CAN slave)
        /// </summary>
        public byte role;
        /// <summary>
        /// period.(1=10[ms])
        /// </summary>
        public int period;
        /// <summary>
        /// acc range.(0=±2[G], 1=±4[G], 2=±8[G])
        /// </summary>
        public byte rangeAcc;
        /// <summary>
        /// gyro range.(0=±30[deg/sec], 1=±120[deg/sec])
        /// </summary>
        public byte rangeGyro;
        /// <summary>
        /// compuss range.(0=±0.7[Ga], 1=±1.0[Ga], 2=±1.5[Ga], 3=±2.0[Ga], 4=±3.2[Ga], 5=±3.8[Ga], 6=±4.5[Ga])
        /// </summary>
        public byte rangeComp;
        /// <summary>
        /// battery  volt.((bat * 16.0) * 2.5 / 4096) / (3.3 / (3.3 + 10))=[V]
        /// </summary>
        public byte batt;
        /// <summary>
        /// binary.(1=binary format, 0=text format)
        /// </summary>
        public byte binary;
    };
    /// <summary>
    /// IMU ehco.
    /// </summary>
    public struct RcvImuEcho
    {
        /// <summary>
        /// message group.
        /// </summary>
        public int group;
        /// <summary>
        /// message number.
        /// </summary>
        public int num;
    };
    /// <summary>
    /// PositionZ GPS GGA.
    /// (Global positioning system fix data.
    /// </summary>
    public struct RcvPosGpsGGA
    {
        /// <summary>
        /// node number.
        /// </summary>
        public int nodeNo;
        /// <summary>
        /// data type(GPS_DATA_GGA).
        /// </summary>
        public GPS_DATA_TYPE type;
        /// <summary>
        /// UTC time.(hour)
        /// </summary>
        public int utc_time_h;
        /// <summary>
        /// UTC time.(minutes)
        /// </summary>
        public int utc_time_m;
        /// <summary>
        /// UTC time.(second)
        /// </summary>
        public int utc_time_s;
        /// <summary>
        /// UTC time.(millisecond)
        /// </summary>
        public int utc_time_ms;
        /// <summary>
        /// latitude.
        /// </summary>
        public double latitude;
        /// <summary>
        /// longitude.
        /// </summary>
        public double longitude;
        /// <summary>
        /// quality type.(0=invalid, 1=stand alone, 2=DGPS)
        /// </summary>
        public GPS_QUALITY_TYPE quality;
        /// <summary>
        /// number of satellites.
        /// </summary>
        public int numOfSatelites;
        /// <summary>
        /// horizontal dilution of precision.
        /// </summary>
        public float hdop;
        /// <summary>
        /// sea level altitude.
        /// </summary>
        public double seaLevelAltitude;
        /// <summary>
        ///geoid level. 
        /// </summary>
        public double geoidLevel;
        /// <summary>
        /// Time since last DGPS update.
        /// </summary>
        public int ageOfDgps;
        /// <summary>
        /// DGPS station ID.
        /// </summary>
        public int dgpsStationId;
    };
    /// <summary>
    /// PositionZ GPS ZDA.
    /// (Date and time)
    /// </summary>
    public struct RcvPosGpsZDA
    {
        /// <summary>
        /// Node number
        /// </summary>
        public int nodeNo;
        /// <summary>
        /// GPS data type
        /// </summary>
        public GPS_DATA_TYPE type;
        /// <summary>
        /// UTC time(hour)
        /// </summary>
        public int utc_time_h;
        /// <summary>
        /// UTC time(minuts)
        /// </summary>
        public int utc_time_m;
        /// <summary>
        /// UTC time(second)
        /// </summary>
        public int utc_time_s;
        /// <summary>
        /// UTC time(mili second)
        /// </summary>
        public int utc_time_ms;
        /// <summary>
        /// UTC date(year)
        /// </summary>
        public int utc_date_year;
        /// <summary>
        /// UTC date(month)
        /// </summary>
        public int utc_date_month;
        /// <summary>
        /// UTC date(day)
        /// </summary>
        public int utc_date_day;
        /// <summary>
        /// UTC date(time zone)
        /// </summary>
        public float utc_date_timeZone;
    };
    /// <summary>
    /// PositionZ GPS GLL
    /// (Geographic position, latitude/longitude)
    /// </summary>
    public struct RcvPosGpsGLL
    {
        /// <summary>
        /// Node number
        /// </summary>
        public int nodeNo;
        /// <summary>
        /// GPS data type(GPS_TYPE_GLL)
        /// </summary>
        public GPS_DATA_TYPE type;
        /// <summary>
        /// latitude
        /// </summary>
        public double latitude;
        /// <summary>
        /// longitude
        /// </summary>
        public double longitude;
        /// <summary>
        /// UTC time(hour)
        /// </summary>
        public int utc_time_h;
        /// <summary>
        /// UTC time(minuts)
        /// </summary>
        public int utc_time_m;
        /// <summary>
        /// UTC time(second)
        /// </summary>
        public int utc_time_s;
        /// <summary>
        /// UTC time(mili second)
        /// </summary>
        public int utc_time_ms;
        /// <summary>
        /// GPS receive status.(0=available, 1=void)
        /// </summary>
        public GPS_RECEIVE_STATUS receiveStatus;
        /// <summary>
        /// GPS quality type.(0=not available, 1=stand alone, 2=DGPS)
        /// </summary>
        public GPS_QUALITY_TYPE quality;
    };
    /// <summary>
    /// PositionZ GPS GSA.
    /// (GPS DOP and active satellites)
    /// </summary>
    public struct RcvPosGpsGSA
    {
        /// <summary>
        /// Node number
        /// </summary>
        public int nodeNo;
        /// <summary>
        /// GPS data type.(GPS_DATA_GSA)
        /// </summary>
        public GPS_DATA_TYPE type;
        /// <summary>
        /// GPS measurement mode.(0=auto detect, 1=mnual select)
        /// </summary>
        public GPS_MEASUREMENT_MODE mode;
        /// <summary>
        /// GPS measurement status.(0=void, 1=two dimension, 2=three dimension)
        /// </summary>
        public GPS_MEASUREMENT_STATUS status;
        /// <summary>
        /// satellite number[12].
        /// </summary>
        public int[] satelliteNo;
        /// <summary>
        /// Position dilution of precision.
        /// </summary>
        public float pdop;
        /// <summary>
        /// Horizontal dilution of precision.
        /// </summary>
        public float hdop;
        /// <summary>
        /// Vertical dilution of precision.
        /// </summary>
        public float vdop;
    };
    /// <summary>
    /// PositionZ GPS GSV.
    /// (GPS satellites in view)
    /// </summary>
    public struct RcvPosGpsGSV
    {
        /// <summary>
        /// Node number
        /// </summary>
        public int nodeNo;
        /// <summary>
        /// GPS data type.(GPS_DATA_GSV)
        /// </summary>
        public GPS_DATA_TYPE type;
        /// <summary>
        /// Total number of message of this type in this cycle.
        /// </summary>
        public int numOfMsg;
        /// <summary>
        /// message number
        /// </summary>
        public int msgNo;
        /// <summary>
        /// number of satellites
        /// </summary>
        public int numOfSatellite;
        /// <summary>
        /// GPS satellite information1
        /// </summary>
        public GpsSatelliteInfo satelliteInfo1;
        /// <summary>
        /// GPS satellite information2
        /// </summary>
        public GpsSatelliteInfo satelliteInfo2;
        /// <summary>
        /// GPS satellite information3
        /// </summary>
        public GpsSatelliteInfo satelliteInfo3;
        /// <summary>
        /// GPS satellite information4
        /// </summary>
        public GpsSatelliteInfo satelliteInfo4;
    };
    /// <summary>
    /// PositionZ GPS VTG.
    /// (Track made good and ground speed)
    /// </summary>
    public struct RcvPosGpsVTG
    {
        /// <summary>
        /// Node number.
        /// </summary>
        public int nodeNo;
        /// <summary>
        /// GPS data type.(GPS_DATA_VTG)
        /// </summary>
        public GPS_DATA_TYPE type;
        /// <summary>
        /// true track made good.(degrees)
        /// </summary>
        public double directionOfTrueNorth;
        /// <summary>
        /// magnetic track made good.
        /// </summary>
        public double directionOfMagneticNorth;
        /// <summary>
        /// Ground speed, knots.
        /// </summary>
        public double speedKnot;
        /// <summary>
        /// Ground speed, kilometers per hour.
        /// </summary>
        public double speedKmph;
        /// <summary>
        /// GPS quality type.(0=not available, 1=stand alone, 2=DGPS)
        /// </summary>
        public GPS_QUALITY_TYPE quality;
    };
    /// <summary>
    /// PositionZ GPS RMC.
    /// (recommended minimum data for gps)
    /// </summary>
    public struct RcvPosGpsRMC
    {
        /// <summary>
        /// Node number.
        /// </summary>
        public int nodeNo;
        /// <summary>
        /// GPS data type.(GPS_DATA_RMC)
        /// </summary>
        public GPS_DATA_TYPE type;
        /// <summary>
        /// UTC time.(hour)
        /// </summary>
        public int utc_time_h;
        /// <summary>
        /// UTC time.(minuts)
        /// </summary>
        public int utc_time_m;
        /// <summary>
        /// UTC time.(second)
        /// </summary>
        public int utc_time_s;
        /// <summary>
        /// UTC time.(millisecond)
        /// </summary>
        public int utc_time_ms;
        /// <summary>
        /// latitude.
        /// </summary>
        public double latitude;
        /// <summary>
        /// longitude.
        /// </summary>
        public double longitude;
        /// <summary>
        /// Speed over ground, Knots.
        /// </summary>
        public double speedKnot;
        /// <summary>
        /// Track angle in degrees true.
        /// </summary>
        public double directionOfTrueNorth;
        /// <summary>
        /// UTC date(year)
        /// </summary>
        public int utc_date_year;
        /// <summary>
        /// UTC data(month)
        /// </summary>
        public int utc_date_month;
        /// <summary>
        /// UTC data(day)
        /// </summary>
        public int utc_date_day;
        /// <summary>
        /// UTC data(time zone)
        /// </summary>
        public float utc_date_timeZone;
        /// <summary>
        /// GPS receive status(0=available, 1=void)
        /// </summary>
        public GPS_RECEIVE_STATUS status;
        /// <summary>
        /// GPS quality type(0=not available, 1=stand alone, 2=DGPS)
        /// </summary>
        public GPS_QUALITY_TYPE quality;
        /// <summary>
        /// magnetic variation.
        /// </summary>
        public double magneticDeviation;
    };
    /// <summary>
    /// PositionZ pressure.
    /// </summary>
    public struct RcvPosPressure
    {
        /// <summary>
        /// Node number
        /// </summary>
        public int nodeNo;
        /// <summary>
        /// pressure[hPa]
        /// </summary>
        public float pressure;
        /// <summary>
        /// temperature[℃]
        /// </summary>
        public float temperature;
    };
    /// <summary>
    /// PositionZ humidity.
    /// </summary>
    public struct RcvPosHumidity
    {
        /// <summary>
        /// Node Number
        /// </summary>
        public int nodeNo;
        /// <summary>
        /// temperature[℃]
        /// </summary>
        public float temperature;
        /// <summary>
        /// humidity[%]
        /// </summary>
        public float humidity;
    };
    /// <summary>
    /// PositionZ status
    /// </summary>
    public struct RcvPosStatus
    {
        /// <summary>
        /// GPS period.(1=10[ms])
        /// </summary>
        public int gpsPeriod;
        /// <summary>
        /// Pressure period.(1=10[ms])
        /// </summary>
        public int pressurePeriod;
        /// <summary>
        /// Humidity period.(1=10[ms])
        /// </summary>
        public int humidityPeriod;
        /// <summary>
        /// GPS type(0=simple, 1=all)
        /// </summary>
        public byte gpsType;
    };
    /// <summary>
    /// PositionZ device profile.
    /// </summary>
    public struct RcvPosDeviceProfile
    {
        /// <summary>
        /// hardware version
        /// </summary>
        public byte hardware;
        /// <summary>
        /// firmware version
        /// </summary>
        public byte firmware;
    };
    /// <summary>
    /// PositionZ echo.
    /// </summary>
    public struct RcvPosEcho
    {
        /// <summary>
        /// message group.
        /// </summary>
        public int group;
        /// <summary>
        /// device number.
        /// </summary>
        public int num;
    };
    /// <summary>
    /// MEV communication class.
    /// </summary>
    public class RczCommunication : AsyncSockClient
	{
		/// <summary>
		/// Receive handler.
		/// </summary>
		/// <param name="sender">object.</param>
		/// <param name="msg">MEV message.</param>
		public delegate void ReceivedHandler(object sender, MevMsg msg);
        /// <summary>
        /// Open close handler.
        /// </summary>
        /// <param name="sender">object.</param>
        /// <param name="bOpen">open(true/false)</param>
		public delegate void OpenCloseHandler(object sender, bool bOpen);
        /// <summary>
        /// constructer
        /// </summary>
		public RczCommunication()
		{
		}

        /// <summary>
        /// Open processing.
        /// </summary>
        /// <returns>true/false</returns>
		public bool Open()
		{
			return base.Connect();
		}
        /// <summary>
        /// Close processing.
        /// </summary>
		public void Close()
		{
			base.Disconnect();
		}
        /// <summary>
        /// receive handler.
        /// </summary>
		public ReceivedHandler Received
		{
			get;
			set;
		}
        /// <summary>
        /// open close handler.
        /// </summary>
		public OpenCloseHandler OpenedOrClosed
		{
			get;
			set;
		}
        /// <summary>
        /// Message send.
        /// </summary>
        /// <param name="pkt">message.</param>
        /// <returns>true/false</returns>
		public new bool Send(byte[] pkt)
		{
			try
			{
				if (base.IsConnect)
				{
					base.Send(pkt);
					return true;
				}
				else
				{
					return false;
				}
			}
			catch (Exception exp)
			{
				return false;
			}
		}


        /// <summary>
        /// Socket message receive handler.
        /// </summary>
        /// <param name="fifo">receive queue.</param>
		protected override void socket_ReceivedHandler(Queue<byte> fifo)
		{
			if (Received != null)
			{
                byte[] data = new byte[fifo.Count];
                data = fifo.ToArray();
                int dataIndex = 0;
                while (dataIndex < data.Length)
                {
                    for (; dataIndex < data.Length; dataIndex++)
                    {
                        if (dataIndex >= data.Length - 1)
                            break;
                        if (data[dataIndex] == 0xac && data[dataIndex + 1] == 0xca)
                            break;
                    }
                    if (dataIndex + 7 >= data.Length)
                        break;
                    MevMsg msg = new MevMsg();
                    msg.header = new byte[2];
                    msg.header[0] = data[dataIndex];
                    msg.header[1] = data[dataIndex + 1];
                    msg.len = (ulong)data[dataIndex + 2] + ((ulong)data[dataIndex + 3] << 8) + ((ulong)data[dataIndex + 4] << 16) + ((ulong)data[dataIndex + 5] << 24);
                    if (dataIndex + (int)msg.len >= data.Length)
                        break;
                    msg.id = data[dataIndex + 6];
                    msg.data = new byte[msg.len - 7];
                    for (int i = 7; i < (int)msg.len; i++)
                    {
                        msg.data[i - 7] = data[dataIndex + i];
                    }
                    Received(this, msg);
                    dataIndex = dataIndex + (int)msg.len;
                }
			}
		}
		/// <summary>
		/// オープンクローズハンドラ処理
		/// </summary>
		/// <param name="bOpened"></param>
		protected override void socket_ConnectedHandler(bool bOpened)
		{
			if (OpenedOrClosed != null)
			{
				OpenedOrClosed(this, bOpened);
			}
		}


        /// <summary>
        /// Parse drive battery data
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="batt">battery</param>
        /// <returns></returns>
        public bool ParseDriveBatt(MevMsg msg, out float batt)
        {
            batt = (float)(BitConverter.ToInt32(msg.data, 0)) / 2.0f;
            return true;
        }

        /// <summary>
        /// Pase drive encoder
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="enc">encoder enc[0]=left front, enc[1]=right front, enc[2]=left rear, enc[3]=right rear</param>
        /// <returns></returns>
        public bool ParseDriveEncoder(MevMsg msg, out RcvDriveEncoder enc)
        {
            enc.enc = new int[4];
            enc.enc[0] = BitConverter.ToInt32(msg.data, 0);
            enc.enc[1] = BitConverter.ToInt32(msg.data, 4);
            enc.enc[2] = BitConverter.ToInt32(msg.data, 8);
            enc.enc[3] = BitConverter.ToInt32(msg.data, 12);
            return true;
        }

        /// <summary>
        /// Parse drive motor velocity[rev/sec]
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="veloc">motor velocity(right target, left target, right actual, left actual</param>
        /// <returns></returns>
        public bool ParseDriveMotorV(MevMsg msg, out RcvDriveMotorV veloc)
        {
            RcvDriveMotorV data = new RcvDriveMotorV();
            data.targetVR = BitConverter.ToSingle(msg.data, 0);
            data.targetVL = BitConverter.ToSingle(msg.data, 4);
            data.actualVR = BitConverter.ToSingle(msg.data, 8);
            data.actualVL = BitConverter.ToSingle(msg.data, 12);
            veloc = data;
            return true;
        }

        /// <summary>
        /// Parse drive motor velocity[Km]
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="targetVR">right target</param>
        /// <param name="targetVL">left target</param>
        /// <param name="actualVR">right actual</param>
        /// <param name="actualVL">left actual</param>
        /// <returns></returns>
        public bool ParseDriveMotorVKm(MevMsg msg, out float targetVR, out float targetVL, out float actualVR, out float actualVL)
        {
            targetVR = BitConverter.ToSingle(msg.data, 0);
            targetVL = BitConverter.ToSingle(msg.data, 4);
            actualVR = BitConverter.ToSingle(msg.data, 8);
            actualVL = BitConverter.ToSingle(msg.data, 12);

            return true;
        }

        /// <summary>
        /// Parse drive pedal input
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="input">pedal input</param>
        /// <returns></returns>
        public bool ParseDrivePedalInput(MevMsg msg, out int input)
        {
            input = BitConverter.ToInt32(msg.data, 0);
            return true;
        }

        /// <summary>
        /// Parse drive raw pedal
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="rawPedal">raw pedal input</param>
        /// <returns></returns>
        public bool ParseDriveRawPedal(MevMsg msg, out int rawPedal)
        {
            rawPedal = BitConverter.ToInt32(msg.data, 0);
            return true;
        }

        /// <summary>
        /// Parse drive status
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="status">drive status(system mode, control mode, servo On/Off, error code)</param>
        /// <returns></returns>
        public bool ParseDriveStatus(MevMsg msg, out RcvDriveStatus status)
        {
            status.mode = msg.data[0];
            status.contMode = msg.data[1];
            status.servo = msg.data[2];
            status.errCode = BitConverter.ToInt16(msg.data, 3);
            return true;
        }

        /// <summary>
        /// Parse drive status
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="swStatus">switch status(sw1=brake, sw2=neutral, sw3=reverse, sw4=drive, mode1, mode2)</param>
        /// <returns></returns>
        public bool ParseDriveSwStatus(MevMsg msg, out RcvDriveSwStatus swStatus)
        {
            swStatus.sw1 = BitConverter.ToBoolean(msg.data, 0);
            swStatus.sw2 = BitConverter.ToBoolean(msg.data, 1);
            swStatus.sw3 = BitConverter.ToBoolean(msg.data, 2);
            swStatus.sw4 = BitConverter.ToBoolean(msg.data, 3);
            swStatus.mode1 = msg.data[4];
            swStatus.mode2 = msg.data[5];
            return true;
        }

        /// <summary>
        /// Parse reaction position
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="pos">target position, actual position</param>
        /// <returns></returns>
        public bool ParseReactPos(MevMsg msg, out RcvReactPos pos)
        {
            RcvReactPos data = new RcvReactPos();
            data.targetPos = BitConverter.ToSingle(msg.data, 0);
            data.actualPos = BitConverter.ToSingle(msg.data, 4);
            pos = data;
            return true;
        }

        /// <summary>
        /// Parse reaction torque
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="torque">target torque, actual torque</param>
        /// <returns></returns>
        public bool ParseReactTorque(MevMsg msg, out RcvReactTorque torque)
        {
            torque.targetTorque = BitConverter.ToSingle(msg.data, 0);
            torque.actualTorque = BitConverter.ToSingle(msg.data, 4);
            return true;
        }

        /// <summary>
        /// Parse Steer position
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="pos">target position, actual position</param>
        /// <returns></returns>
        public bool ParseSteerPos(MevMsg msg, out RcvSteerPos pos)
        {
            pos.targetPos = BitConverter.ToSingle(msg.data, 0);
            pos.actualPos = BitConverter.ToSingle(msg.data, 4);
            return true;
        }

        /// <summary>
        /// Parse steer status
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="status">steer status(system mode, steer On/Off, control mode, reaction On/Off, error code)</param>
        /// <returns></returns>
        public bool ParseSteerStatus(MevMsg msg, out RcvSteerStatus status)
        {
            status.mode = msg.data[0];
            status.steerServo = msg.data[1];
            status.contMode = msg.data[2];
            status.reactServo = msg.data[3];
            status.errCode = BitConverter.ToInt16(msg.data, 4);
            return true;
        }

        /// <summary>
        /// Parse cconfig data
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="config">config data(index, data[0], data[1], data[2])</param>
        /// <returns></returns>
        public bool ParseSyscomConfig(MevMsg msg, out RcvSyscomConfig config)
        {
            config.data = new int[3];
            config.index = BitConverter.ToInt32(msg.data, 0);
            config.data[0] = BitConverter.ToInt16(msg.data, 4);
            config.data[1] = BitConverter.ToInt16(msg.data, 6);
            config.data[2] = BitConverter.ToInt16(msg.data, 8);
            return true;
        }

        /// <summary>
        /// Parse Echo
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="echo">echo(group, number)</param>
        /// <returns></returns>
        public bool ParseSyscomEcho(MevMsg msg, out RcvSyscomEcho echo)
        {
            echo.group = BitConverter.ToInt32(msg.data, 0);
            echo.num = BitConverter.ToInt32(msg.data, 4);
            return true;
        }

        /// <summary>
        /// Parse IMU Acceleration
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="acc">acceleration data(X axis, Y axis, Z axis, time)</param>
        /// <returns></returns>
        public bool ParseImuMeasurementAcc(MevMsg msg, out RcvImuAcc acc)
        {
            acc.accX = BitConverter.ToInt32(msg.data, 0);
            acc.accY = BitConverter.ToInt32(msg.data, 4);
            acc.accZ = BitConverter.ToInt32(msg.data, 8);
            acc.time = BitConverter.ToInt32(msg.data, 12);
            return true;
        }

        /// <summary>
        /// Parse IMU Acceleration[G]
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="range">range(0=±2G, 1=±4G, 2=±8G)</param>
        /// <param name="acc">acceleration data(X axis[G], Y axis[G], Z axis[G], time)</param>
        /// <returns></returns>
        public bool ParseImuMeasurementAccG(MevMsg msg, byte range, out RcvImuAcc acc)
        {
            double ran = 1.0;
            switch (range)
            {
                case 0: ran = 1.0; break;
                case 1: ran = 2.0; break;
                case 2: ran = 3.9; break;
                default: ran = 1.0; break;
            }

            acc.accX = (double)(BitConverter.ToInt32(msg.data, 0)) / (1.0 * 1000.0) * ran;
            acc.accY = (double)(BitConverter.ToInt32(msg.data, 4)) / (1.0 * 1000.0) * ran;
            acc.accZ = (double)(BitConverter.ToInt32(msg.data, 8)) / (1.0 * 1000.0) * ran;
            acc.time = BitConverter.ToInt32(msg.data, 12);
            return true;
        }

        /// <summary>
        /// Parse IMU Gyro
        /// </summary>
        /// <param name="msg">parase message</param>
        /// <param name="gyro">gyro data(X axis, Y axis, Z axis, time)</param>
        /// <returns></returns>
        public bool ParseImuMeasurementGyro(MevMsg msg, out RcvImuGyro gyro)
        {
            gyro.gyroX = BitConverter.ToInt32(msg.data, 0);
            gyro.gyroY = BitConverter.ToInt32(msg.data, 4);
            gyro.gyroZ = BitConverter.ToInt32(msg.data, 8);
            gyro.time = BitConverter.ToInt32(msg.data, 12);
            return true;
        }
        /// <summary>
        /// Parse IMU Gyro[deg/sec]
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="range">range(0=±50[deg/sec], 1=±120[deg/sec])</param>
        /// <param name="hard">hardwere version(1=IMU-Z, 2=IMU-Z for RC)</param>
        /// <param name="gyro">gyro data(X axis[deg/sec], Y axis[deg/sec], Z axis[deg/sec], time)</param>
        /// <returns></returns>
        public bool ParseImuMeasurementGyroDeg(MevMsg msg, byte range, byte hard, out RcvImuGyro gyro)
        {
            double ran = 33.3;
            double ratio = 1.0;
            switch (range)
            {
                case 0: ran = 33.3; ratio = 1.0; break;
                case 1: ran = 8.3; ratio = 4.0;  break;
                default: ran = 33.3; ratio = 1.0; break;
            }
            gyro.gyroX = ((double)(BitConverter.ToInt32(msg.data, 0)) * 2.5 / 4096.0) / (ran / 1000.0) * ratio;
            gyro.gyroY = ((double)(BitConverter.ToInt32(msg.data, 4)) * 2.5 / 4096.0) / (ran / 1000.0) * ratio;
            gyro.gyroZ = ((double)(BitConverter.ToInt32(msg.data, 8)) * 2.5 / 4096.0) / (ran / 1000.0) * ratio;
            gyro.time = BitConverter.ToInt32(msg.data, 12);
            return true;
        }

        /// <summary>
        /// Parse IMU Comp
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="comp">comp data(X axis, Y axis, Z axis, time)</param>
        /// <returns></returns>
        public bool ParseImuMeasurementComp(MevMsg msg, out RcvImuComp comp)
        {
            comp.compX = BitConverter.ToInt32(msg.data, 0);
            comp.compY = BitConverter.ToInt32(msg.data, 4);
            comp.compZ = BitConverter.ToInt32(msg.data, 8);
            comp.time = BitConverter.ToInt32(msg.data, 12);
            return true;
        }
        /// <summary>
        /// Parse IMU Comp[Ga]
        /// </summary>
        /// <param name="msg">parase essage</param>
        /// <param name="range">range(0=±0.7[Ga], 1=±1.0[Ga], 2=±1.5[Ga], 3=±2.0[Ga], 4=±3.2[Ga], 5=±3.8[Ga], 6=±4.5[Ga]</param>
        /// <param name="comp">comp data(X axis[Ga], Y axis[Ga], Z axis[Ga], time</param>
        /// <returns></returns>
        /// 
        public bool ParseImuMeasurementCompGa(MevMsg msg, byte range, out RcvImuComp comp)
        {
            double ran = 1.0;
            switch (range)
            {
                case 0: ran = 1620; break;
                case 1: ran = 1300; break;
                case 2: ran = 970; break;
                case 3: ran = 780; break;
                case 4: ran = 530; break;
                case 5: ran = 460; break;
                case 6: ran = 390; break;
                default: ran = 1300; break;
            }
            comp.compX = (double)(BitConverter.ToInt32(msg.data, 0)) * 1.0/ran;
            comp.compY = (double)(BitConverter.ToInt32(msg.data, 4)) * 1.0/ran;
            comp.compZ = (double)(BitConverter.ToInt32(msg.data, 8)) * 1.0/ran;
            comp.time = BitConverter.ToInt32(msg.data, 12);
            return true;
        }
        /// <summary>
        /// Parse IMU device profile
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="profile">device profile(hard version, fir version, bluetooth address[6]</param>
        /// <returns></returns>
        public bool ParseImuDeviceProfile(MevMsg msg, out RcvImuDeviceProfile profile)
        {
            profile.hard = msg.data[0];
            profile.firm = msg.data[1];
            profile.btadr = new byte[6];
            profile.btadr[0] = msg.data[2];
            profile.btadr[1] = msg.data[3];
            profile.btadr[2] = msg.data[4];
            profile.btadr[3] = msg.data[5];
            profile.btadr[4] = msg.data[6];
            profile.btadr[5] = msg.data[7];
            return true;
        }
        /// <summary>
        /// Parse IMU echo
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="echo">echo data(group, number)</param>
        /// <returns></returns>
        public bool ParseImuEcho(MevMsg msg, out RcvImuEcho echo)
        {
            echo.group = BitConverter.ToInt32(msg.data, 0);
            echo.num = BitConverter.ToInt32(msg.data, 4);
            return true;
        }
        /// <summary>
        /// Parse IMU status
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="status">IMU status(role, period, AccRange, GyroRange, CompRange, battery, binary)</param>
        /// <returns></returns>
        public bool ParseImuStatus(MevMsg msg, out RcvImuStatus status)
        {
            RcvImuStatus data = new RcvImuStatus();
            data.role = msg.data[0];
            data.period = BitConverter.ToInt32(msg.data, 1);
            data.rangeAcc = msg.data[5];
            data.rangeGyro = msg.data[6];
            data.rangeComp = msg.data[7];
            data.batt = msg.data[8];
            data.binary = msg.data[9];
            status = data;
            return true;
        }
        /// <summary>
        /// Parse PositionZ GPS GGA
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="gga">gga data(nodeNo, GPS data type, UTC time, latitude, longitude, 
        ///                            quality, sattelite num, hdop, sea livel altitude, 
        ///                            geoil level, age of dgps, dgps station id)</param>
        /// <returns></returns>
        public bool ParsePosGpsGGA(MevMsg msg, out RcvPosGpsGGA gga)
        {
            RcvPosGpsGGA data = new RcvPosGpsGGA();
            data.nodeNo = BitConverter.ToInt32(msg.data, 0);
            data.type = (GPS_DATA_TYPE)BitConverter.ToInt32(msg.data, 4);
            data.utc_time_h = BitConverter.ToInt32(msg.data, 8);
            data.utc_time_m = BitConverter.ToInt32(msg.data, 12);
            data.utc_time_s = BitConverter.ToInt32(msg.data, 16);
            data.utc_time_ms = BitConverter.ToInt32(msg.data, 20);
            data.latitude = BitConverter.ToDouble(msg.data, 24);
            data.longitude = BitConverter.ToDouble(msg.data, 32);
            data.quality = (GPS_QUALITY_TYPE)BitConverter.ToInt32(msg.data, 40);
            data.numOfSatelites = BitConverter.ToInt32(msg.data, 44);
            data.hdop = BitConverter.ToSingle(msg.data, 48);
            data.seaLevelAltitude = BitConverter.ToDouble(msg.data, 52);
            data.geoidLevel = BitConverter.ToDouble(msg.data, 60);
            data.ageOfDgps = BitConverter.ToInt32(msg.data, 68);
            data.dgpsStationId = BitConverter.ToInt32(msg.data, 72);
            gga = data;
            return true;
        }
        /// <summary>
        /// Parse PositionZ GPS ZDA
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="zda">zda data(nodeNo, GPS data type, UTC time, UTC date)</param>
        /// <returns></returns>
        public bool ParsePosGpsZDA(MevMsg msg, out RcvPosGpsZDA zda)
        {
            RcvPosGpsZDA data = new RcvPosGpsZDA();
            data.nodeNo = BitConverter.ToInt32(msg.data, 0);
            data.type = (GPS_DATA_TYPE)BitConverter.ToInt32(msg.data, 4);
            data.utc_time_h = BitConverter.ToInt32(msg.data, 8);
            data.utc_time_m = BitConverter.ToInt32(msg.data, 12);
            data.utc_time_s = BitConverter.ToInt32(msg.data, 16);
            data.utc_time_ms = BitConverter.ToInt32(msg.data, 20);
            data.utc_date_year = BitConverter.ToInt32(msg.data, 24);
            data.utc_date_month = BitConverter.ToInt32(msg.data, 28);
            data.utc_date_day = BitConverter.ToInt32(msg.data, 32);
            data.utc_date_timeZone = BitConverter.ToSingle(msg.data, 36);
            zda = data;
            return true;
        }
        /// <summary>
        /// Parse PositionZ GPS GLL
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="gll">gll data(nodeNo, GPS data type, latitude, longitude, UTC time, receive status, quality)</param>
        /// <returns></returns>
        public bool ParsePosGpsGLL(MevMsg msg, out RcvPosGpsGLL gll)
        {
            RcvPosGpsGLL data = new RcvPosGpsGLL();
            data.nodeNo = BitConverter.ToInt32(msg.data, 0);
            data.type = (GPS_DATA_TYPE)BitConverter.ToInt32(msg.data, 4);
            data.latitude = BitConverter.ToDouble(msg.data, 8);
            data.longitude = BitConverter.ToDouble(msg.data, 16);
            data.utc_time_h = BitConverter.ToInt32(msg.data, 24);
            data.utc_time_m = BitConverter.ToInt32(msg.data, 28);
            data.utc_time_s = BitConverter.ToInt32(msg.data, 32);
            data.utc_time_ms = BitConverter.ToInt32(msg.data, 36);
            data.receiveStatus = (GPS_RECEIVE_STATUS)BitConverter.ToInt32(msg.data, 40);
            data.quality = (GPS_QUALITY_TYPE)BitConverter.ToInt32(msg.data, 44);
            gll = data;
            return true;
        }
        /// <summary>
        /// Parse PositionZ GPS GSA
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="gsa">gsa data(nodeNo, GPS data type, GPS measurement mode, GPS measurement status,
        ///                            sattelite No[12], pdop, hdop, vdop)</param>
        /// <returns></returns>
        public bool ParsePosGpsGSA(MevMsg msg, out RcvPosGpsGSA gsa)
        {
            RcvPosGpsGSA data = new RcvPosGpsGSA();
            data.nodeNo = BitConverter.ToInt32(msg.data, 0);
            data.type = (GPS_DATA_TYPE)BitConverter.ToInt32(msg.data, 4);
            data.mode = (GPS_MEASUREMENT_MODE)BitConverter.ToInt32(msg.data, 8);
            data.status = (GPS_MEASUREMENT_STATUS)BitConverter.ToInt32(msg.data, 12);
            data.satelliteNo = new int[12];
            for (int i = 0; i < 12; i++)
            {
                data.satelliteNo[i] = BitConverter.ToInt32(msg.data, 16 + (4 * i));
            }
            data.pdop = BitConverter.ToSingle(msg.data, 64);
            data.hdop = BitConverter.ToSingle(msg.data, 68);
            data.vdop = BitConverter.ToSingle(msg.data, 72);
            gsa = data;
            return true;
        }
        /// <summary>
        /// Parse PositionZ GPS GSV
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="gsv">gsv data(nodeNo, GPS data type, numOfMsg, msgNo, sattelite information[4])</param>
        /// <returns></returns>
        public bool ParsePosGpsGSV(MevMsg msg, out RcvPosGpsGSV gsv)
        {
            RcvPosGpsGSV data = new RcvPosGpsGSV();
            data.nodeNo = BitConverter.ToInt32(msg.data, 0);
            data.type = (GPS_DATA_TYPE)BitConverter.ToInt32(msg.data, 4);
            data.numOfMsg = BitConverter.ToInt32(msg.data, 8);
            data.msgNo = BitConverter.ToInt32(msg.data, 12);
            data.numOfSatellite = BitConverter.ToInt32(msg.data, 16);
            data.satelliteInfo1.satteliteNo = BitConverter.ToInt32(msg.data, 20);
            data.satelliteInfo1.elevation = BitConverter.ToDouble(msg.data, 24);
            data.satelliteInfo1.azimuth = BitConverter.ToDouble(msg.data, 32);
            data.satelliteInfo1.snr = BitConverter.ToSingle(msg.data, 40);
            data.satelliteInfo2.satteliteNo = BitConverter.ToInt32(msg.data, 44);
            data.satelliteInfo2.elevation = BitConverter.ToDouble(msg.data, 48);
            data.satelliteInfo2.azimuth = BitConverter.ToDouble(msg.data, 56);
            data.satelliteInfo2.snr = BitConverter.ToSingle(msg.data, 64);
            data.satelliteInfo3.satteliteNo = BitConverter.ToInt32(msg.data, 68);
            data.satelliteInfo3.elevation = BitConverter.ToDouble(msg.data, 72);
            data.satelliteInfo3.azimuth = BitConverter.ToDouble(msg.data, 80);
            data.satelliteInfo3.snr = BitConverter.ToSingle(msg.data, 88);
            data.satelliteInfo4.satteliteNo = BitConverter.ToInt32(msg.data, 92);
            data.satelliteInfo4.elevation = BitConverter.ToDouble(msg.data, 96);
            data.satelliteInfo4.azimuth = BitConverter.ToDouble(msg.data, 104);
            data.satelliteInfo4.snr = BitConverter.ToSingle(msg.data, 112);
            gsv = data;
            return true;
        }
        /// <summary>
        /// Parse PositionZ GPS VTG
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="vtg">vtg data(nodeNo, GPS data type, direction of true north,
        ///                            direction of magnetic north, speedKnot, speedKmph, 
        ///                            GPS quality type)</param>
        /// <returns></returns>
        public bool ParsePosGpsVTG(MevMsg msg, out RcvPosGpsVTG vtg)
        {
            RcvPosGpsVTG data = new RcvPosGpsVTG();
            data.nodeNo = BitConverter.ToInt32(msg.data, 0);
            data.type = (GPS_DATA_TYPE)BitConverter.ToInt32(msg.data, 4);
            data.directionOfTrueNorth = BitConverter.ToDouble(msg.data, 8);
            data.directionOfMagneticNorth = BitConverter.ToDouble(msg.data, 16);
            data.speedKnot = BitConverter.ToDouble(msg.data, 24);
            data.speedKmph = BitConverter.ToDouble(msg.data, 32);
            data.quality = (GPS_QUALITY_TYPE)BitConverter.ToInt32(msg.data, 40);
            vtg = data;
            return true;
        }
        /// <summary>
        /// Parse PositionZ GPS RMC
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="rmc">rmc data(nodeNo, GPS data type, UTC time, latitude, longitude,
        ///                            speedKnot, direction of true north, UTC date,
        ///                            GPS receive status, GPS quality type, magnetic deviation)</param>
        /// <returns></returns>
        public bool ParsePosGpsRMC(MevMsg msg, out RcvPosGpsRMC rmc)
        {
            RcvPosGpsRMC data = new RcvPosGpsRMC();
            data.nodeNo = BitConverter.ToInt32(msg.data, 0);
            data.type = (GPS_DATA_TYPE)BitConverter.ToInt32(msg.data, 4);
            data.utc_time_h = BitConverter.ToInt32(msg.data, 8);
            data.utc_time_m = BitConverter.ToInt32(msg.data, 12);
            data.utc_time_s = BitConverter.ToInt32(msg.data, 16);
            data.utc_time_ms = BitConverter.ToInt32(msg.data, 20);
            data.latitude = BitConverter.ToDouble(msg.data, 24);
            data.longitude = BitConverter.ToDouble(msg.data, 32);
            data.speedKnot = BitConverter.ToDouble(msg.data, 40);
            data.directionOfTrueNorth = BitConverter.ToDouble(msg.data, 48);
            data.utc_date_year = BitConverter.ToInt32(msg.data, 56);
            data.utc_date_month = BitConverter.ToInt32(msg.data, 60);
            data.utc_date_day = BitConverter.ToInt32(msg.data, 64);
            data.utc_date_timeZone = BitConverter.ToSingle(msg.data, 68);
            data.status = (GPS_RECEIVE_STATUS)BitConverter.ToInt32(msg.data, 72);
            data.quality = (GPS_QUALITY_TYPE)BitConverter.ToInt32(msg.data, 76);
            data.magneticDeviation = BitConverter.ToDouble(msg.data, 80);
            rmc = data;
            return true;
        }
        /// <summary>
        /// Parse PositionZ humidity
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="humidity">humidity data(nodeNo, temperature, humidity)</param>
        /// <returns></returns>
        public bool ParsePosHumidity(MevMsg msg, out RcvPosHumidity humidity)
        {
            RcvPosHumidity data = new RcvPosHumidity();
            data.nodeNo = BitConverter.ToInt32(msg.data, 0);
            data.temperature = BitConverter.ToSingle(msg.data, 4);
            data.humidity = BitConverter.ToSingle(msg.data, 8);
            humidity = data;
            return true;
        }
        /// <summary>
        /// Parse PositionZ pressure
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="pressure">pressure data(nodeNo, pressure, temperature)</param>
        /// <returns></returns>
        public bool ParsePosPressure(MevMsg msg, out RcvPosPressure pressure)
        {
            RcvPosPressure data = new RcvPosPressure();
            data.nodeNo = BitConverter.ToInt32(msg.data, 0);
            data.pressure = BitConverter.ToSingle(msg.data, 4);
            data.temperature = BitConverter.ToSingle(msg.data, 8);
            pressure = data;
            return true;
        }
        /// <summary>
        /// Perase PositionZ device profile
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="profile">profile data(hardware version, firmware version)</param>
        /// <returns></returns>
        public bool ParsePosDeviceProfile(MevMsg msg, out RcvPosDeviceProfile profile)
        {
            RcvPosDeviceProfile data = new RcvPosDeviceProfile();
            data.hardware = msg.data[0];
            data.firmware = msg.data[1];
            profile = data;
            return true;
        }
        /// <summary>
        /// Parse PositionZ echo
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="echo">echo data(group, number)</param>
        /// <returns></returns>
        public bool ParsePosEcho(MevMsg msg, out RcvPosEcho echo)
        {
            echo.group = BitConverter.ToInt32(msg.data, 0);
            echo.num = BitConverter.ToInt32(msg.data, 4);
            return true;
        }
        /// <summary>
        /// Parse PositionZ Status
        /// </summary>
        /// <param name="msg">parse message</param>
        /// <param name="status">status data(GPS period, Pressure period, Humidity period, GPS type)</param>
        /// <returns></returns>
        public bool ParsePosStatus(MevMsg msg, out RcvPosStatus status)
        {
            RcvPosStatus data = new RcvPosStatus();
            data.gpsPeriod = BitConverter.ToInt32(msg.data, 0);
            data.pressurePeriod = BitConverter.ToInt32(msg.data, 4);
            data.humidityPeriod = BitConverter.ToInt32(msg.data, 8);
            data.gpsType = msg.data[12];
            status = data;
            return true;
        }
    
    }
}
