﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;


namespace Zmp.Rcz.Communication
{
	/// <summary>
	/// 非同期ソケットクライアントクラス
	/// </summary>
	public class AsyncSockClient
	{
		/// <summary>
		/// コンストラクタ デフォルトサイズ(1000byte)のバッファ確保。
		/// </summary>
		public AsyncSockClient()
		{
			_recvBuffer = new byte[_recvBuffSize];
		}
		/// <summary>
		/// コンストラクタ。指定したサイズでバッファ確保。
		/// </summary>
		/// <param name="buffSize">受信バッファの長さ</param>
		public AsyncSockClient(int buffSize)
		{
			_recvBuffSize = buffSize;
			_recvBuffer = new byte[_recvBuffSize];
		}
		private int _recvBuffSize = 1000000;
		private byte[] _recvBuffer;

		private ManualResetEvent connectDone = new ManualResetEvent(false);
		private ManualResetEvent disconnectDone = new ManualResetEvent(false);
	
		private Socket _sock;
		private bool _isConnect = false;
		/// <summary>
		/// 接続しているかどうかを表す。
		/// </summary>
		public bool IsConnect
		{
			get { return _isConnect; }
		}

		private IPAddress _ipAddress;
		/// <summary>
		/// 接続先ホスト名。IPアドレスの形式の文字列。(ex)192.168.100.100
		/// </summary>
		public string HostName
		{
			set { _ipAddress = IPAddress.Parse(value); }
			get { return _ipAddress.ToString() ; }
		}
		/// <summary>
		/// 接続先IPアドレス。
		/// </summary>
		public IPAddress IpAddress
		{
			set { _ipAddress = value; }
			get { return _ipAddress; }
		}
		private int _portNo;
		/// <summary>
		/// port number.
		/// </summary>
		public int PortNo
		{
			set { _portNo = value; }
			get { return _portNo; }
		}
        /// <summary>
        /// Connect processing.
        /// </summary>
        /// <returns></returns>
		public bool Connect()
		{
			// Connect to a remote device.
			try
			{
				IPEndPoint remoteEP = new IPEndPoint(_ipAddress, _portNo);

				// Create a TCP/IP socket.
				_sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

				// Connect to the remote endpoint.
				_sock.BeginConnect(remoteEP, new AsyncCallback(ConnectCallback), _sock);
				if (!connectDone.WaitOne(5 * 1000))
				{
					return false;
				}


				beginReceive();
				_isConnect = true;
			}
			catch (Exception e)
			{
				Console.WriteLine(e.ToString());
				return false;
			}
			return true;
		}
        /// <summary>
        /// connect call back.
        /// </summary>
        /// <param name="ar"></param>
		protected void ConnectCallback(IAsyncResult ar)
		{
			try
			{
				// Complete the connection.
				_sock.EndConnect(ar);

				Console.WriteLine("Socket connected to {0}", _sock.RemoteEndPoint.ToString());

				// Signal that the connection has been made.
				connectDone.Set();

				socket_ConnectedHandler(true);
			}
			catch (Exception e)
			{
				Console.WriteLine(e.ToString());
			}
		}

        /// <summary>
        /// receive queue.
        /// </summary>
		protected Queue<byte> _fifo = new Queue<byte>();
        /// <summary>
        /// receive processing.
        /// </summary>
		protected void beginReceive()
		{
			try
			{
				// Begin receiving the data from the remote device.
				_sock.BeginReceive(_recvBuffer, 0, _recvBuffSize, 0, new AsyncCallback(receiveCallback), _sock);
			}
			catch (Exception e)
			{
				Console.WriteLine(e.ToString());
			}
		}
        /// <summary>
        /// receive call back.
        /// </summary>
        /// <param name="ar"></param>
		protected void receiveCallback(IAsyncResult ar)
		{
			try
			{
				// Read data from the remote device.
				int bytesRead = _sock.EndReceive(ar);
                if (bytesRead >= _recvBuffer.Length)
                    bytesRead = _recvBuffer.Length;
				for (int i = 0; i < bytesRead; i++)
				{
					_fifo.Enqueue(_recvBuffer[i]);
				}
				socket_ReceivedHandler(_fifo);
                for (int i = 0; _fifo.Count != 0; i++)
                {
                    _fifo.Dequeue();
                }
				_sock.BeginReceive(_recvBuffer, 0, _recvBuffSize, 0, new AsyncCallback(receiveCallback), _sock);
			}
			catch (Exception e)
			{
				Console.WriteLine(e.ToString());
			}
		}
        /// <summary>
        /// send processing.
        /// </summary>
        /// <param name="str"></param>
		public void Send(string str)
		{
			Send(Encoding.ASCII.GetBytes(str));
		}
        /// <summary>
        /// send processing.
        /// </summary>
        /// <param name="data">message</param>
		public void Send(byte[] data)
		{
			// Begin sending the data to the remote device.
			_sock.BeginSend(data, 0, data.Length, 0, new AsyncCallback(SendCallback), _sock);
		}
        /// <summary>
        /// send call back
        /// </summary>
        /// <param name="ar"></param>
		protected void SendCallback(IAsyncResult ar)
		{
		}
        /// <summary>
        /// Disconnect.
        /// </summary>
		public void Disconnect()
		{
			_sock.BeginDisconnect(true, new AsyncCallback(DisconnectCallback), _sock);
			disconnectDone.WaitOne();
			_isConnect = false;
		}
        /// <summary>
        /// Disconnect call back.
        /// </summary>
        /// <param name="ar"></param>
		protected void DisconnectCallback(IAsyncResult ar)
		{
			disconnectDone.Set();
			socket_ConnectedHandler(false);

		}


        /// <summary>
        /// socket receive handler.
        /// </summary>
        /// <param name="fifo">receive queue.</param>
		protected virtual void socket_ReceivedHandler(Queue<byte>fifo)
		{
		}
        /// <summary>
        /// socket connected handler.
        /// </summary>
        /// <param name="bOpened">true/false</param>
		protected virtual void socket_ConnectedHandler(bool bOpened)
		{
		}
	}
}
