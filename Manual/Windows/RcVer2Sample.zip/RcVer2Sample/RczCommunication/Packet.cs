﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zmp.Rcz.Communication
{
    /// <summary>
    /// MEV message ID
    /// </summary>
	public enum RCZHMSG_ID
	{
        RCZHMSG_ID_LOAD_PROGRAM = 1,
        RCZHMSG_ID_SET_IMAGE_REPORT_FLAG,
        RCZHMSG_ID_SET_RESULT_REPORT_FLAG,
        RCZHMSG_ID_SET_IPM_STEREO_PARAM,
        RCZHMSG_ID_UPDATE_DATAFILE,
        RCZHMSG_ID_SET_INT_INTERVAL,

        RCZHMSG_ID_SET_TORQUE_ENABLE,
        RCZHMSG_ID_SET_DRIVE_SPEED,
        RCZHMSG_ID_SET_STEER_ANGLE,
        RCZHMSG_ID_SET_CONTROL_MODE,
        RCZHMSG_ID_SET_ANGLE_ZERO_OFFSET,
        RCZHMSG_ID_SET_LANE_KEEPING_PARAM,

        RCZHMSG_ID_SET_SERVO_ONOFF,
        RCZHMSG_ID_SET_MOTOR_ONOFF,
        RCZHMSG_ID_SET_CAMBER_ONOFF,
        RCZHMSG_ID_SET_CAMBER_ANGLE,
        RCZHMSG_ID_GET_SENSOR_INFO,
        RCZHMSG_ID_GET_SENSOR_INFO_RES,
        RCZHMSG_ID_GET_OBSTACLE_INFO,
        RCZHMSG_ID_GET_OBSTACLE_INFO_RES,
        RCZHMSG_ID_GET_POWER_INFO,
        RCZHMSG_ID_GET_POWER_INFO_RES,
        RCZHMSG_ID_GET_LRS_INFO,
        RCZHMSG_ID_GET_LRS_INFO_RES,
        RCZHMSG_ID_SET_CURRENT_OFFSET,
        RCZHMSG_ID_SET_GYRO_OFFSET,
        RCZHMSG_ID_GET_CAMBER_INFO_RES,
        RCZHMSG_ID_GET_SERVO_INFO,
        RCZHMSG_ID_GET_SERVO_INFO_RES,
        RCZHMSG_ID_GET_THERMO_INFO,
        RCZHMSG_ID_GET_THERMO_INFO_RES,
        RCZHMSG_ID_SET_STEER_OFFSET,
        RCZHMSG_ID_SET_CAMBER_OFFSET,

        RCZHMSG_ID_BEGIN_MOTION,
        RCZHMSG_ID_SET_OBSTACLE_AVOIDANCE_PARAM,

        RCZHMSG_ID_SET_DRIVE_TORQUE,
        RCZHMSG_ID_SET_DRIVE_MODE,
        //	RCZHMSG_ID_SET_COMMUNICATION_CONFIG,
        //    RCZHMSG_ID_SET_CONTROL_CONFIG,
        //	RCZHMSG_ID_START_VIDEO_LOG,
        //    RCZHMSG_ID_STOP_VIDEO_LOG,
        //	RCZHMSG_ID_START_SENSOR_LOG,
        //	RCZHMSG_ID_STOP_SENSOR_LOG,
        RCZHMSG_ID_SET_LPF_REQ,
        RCZHMSG_ID_GET_LPF_REQ,
        RCZHMSG_ID_REP_LPF,
        RCZHMSG_ID_SND_DRAW_POS,

        RCZHMSG_ID_TEST = 128,
        RCZHMSG_ID_IMAGE,
        RCZHMSG_ID_LANE_RESULT,
        RCZHMSG_ID_STEREO_RESULT_HIST,
        RCZHMSG_ID_STEREO_RESULT_HOUGH,
        RCZHMSG_ID_STEREO_RESULT_LABELING,
        RCZHMSG_ID_TEXT_MESSAGE,

        RCZHMSG_ID_IMAGE_JPEG,

        RCZHMSG_ID_DISPARITY_AVERAGE,
        RCZHMSG_ID_SET_COMMUNICATION_CONFIG,
        RCZHMSG_ID_SET_CONTROL_CONFIG,
        RCZHMSG_ID_START_VIDEO_LOG,
        RCZHMSG_ID_STOP_VIDEO_LOG,
        RCZHMSG_ID_START_SENSOR_LOG,
        RCZHMSG_ID_STOP_SENSOR_LOG,

        RCZHMSG_ID_SND_TIME,
        RCZHMSG_ID_RCV_TIME,
        RCZHMSG_ID_RCV_SENSOR_TIME,
        RCZHMSG_ID_RCV_IMAGE_TIME,
        RCZHMSG_ID_SND_DELTA_X,
        RCZHMSG_ID_SND_DELTA_Y,
        RCZHMSG_ID_SND_DELTA_Z,
        RCZHMSG_ID_SND_TIMESTAMP,

        RCZHMSG_ID_SET_OFFSET_DATA,


        RCZHMSG_ID_RC_COMMAND_BEG = RCZHMSG_ID_SET_TORQUE_ENABLE,
	}

//	public struct RczMsg
//	{
//		public RCZHMSG_ID MsgId { get; set; }
//	}
    /// <summary>
    /// RoboCar1/10 message format
    /// </summary>
    public class RczMsg
    {
        /// <summary>
        /// message header(2byte, 0xac 0xca)
        /// </summary>
        public byte[] header{get; set;}
        /// <summary>
        /// message length
        /// </summary>
        public ulong len { get; set; }
        /// <summary>
        /// message id(enum RCZHMSG_ID)
        /// </summary>
        public byte id { get; set; }
        /// <summary>
        /// message data
        /// </summary>
        public byte[] data { get; set; }
    }


    /// <summary>
    /// RoboCar1/10 message generation class.
    /// </summary>
	public static class RczPacket
	{
        public static byte[] SetDriveVelocity(int speed)
        {
            int len = 7 + sizeof(int);
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)RCZHMSG_ID.RCZHMSG_ID_SET_DRIVE_SPEED;
            BitConverter.GetBytes((int)speed).CopyTo(pkt, 7);
            return pkt;
        }

        public static byte[] SetSteerAngle(float angle)
		{
			int len = 7 + sizeof(float);
			byte[] pkt = new byte[len];
			pkt[0] = 0xac;
			pkt[1] = 0xca;
			BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
			pkt[6] = (byte)RCZHMSG_ID.RCZHMSG_ID_SET_STEER_ANGLE;
			BitConverter.GetBytes((float)angle).CopyTo(pkt, 7);
			return pkt;
		}

        public static byte[] SetSteerServo(int enable)
        {
            int len = 7 + sizeof(int);
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)RCZHMSG_ID.RCZHMSG_ID_SET_SERVO_ONOFF;
            BitConverter.GetBytes((int)enable).CopyTo(pkt, 7);
            return pkt;
        }

        public static byte[] SetDriveMotor(int enable)
        {
            int len = 7 + sizeof(int);
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)RCZHMSG_ID.RCZHMSG_ID_SET_MOTOR_ONOFF;
            BitConverter.GetBytes((int)enable).CopyTo(pkt, 7);
            return pkt;
        }


        public static byte[] SetCurrentOffset(float current)
        {
            int len = 7 + sizeof(float);
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)RCZHMSG_ID.RCZHMSG_ID_SET_CURRENT_OFFSET;
            BitConverter.GetBytes((float)current).CopyTo(pkt, 7);
            return pkt;
        }

        public static byte[] SetGyroOffset(float gyro)
        {
            int len = 7 + sizeof(float);
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)RCZHMSG_ID.RCZHMSG_ID_SET_GYRO_OFFSET;
            BitConverter.GetBytes((float)gyro).CopyTo(pkt, 7);
            return pkt;
        }

        public static byte[] SetSteerOffset(float steer)
        {
            int len = 7 + sizeof(float);
            byte[] pkt = new byte[len];
            pkt[0] = 0xac;
            pkt[1] = 0xca;
            BitConverter.GetBytes((uint)len).CopyTo(pkt, 2);
            pkt[6] = (byte)RCZHMSG_ID.RCZHMSG_ID_SET_STEER_OFFSET;
            BitConverter.GetBytes((float)steer).CopyTo(pkt, 7);
            return pkt;
        }
	}
}
