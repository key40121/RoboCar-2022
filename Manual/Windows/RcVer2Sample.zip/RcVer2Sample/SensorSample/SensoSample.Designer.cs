﻿namespace RczControl
{
    partial class SensorSampleForm
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.connectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox_drv_encoderM = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox_drv_encoderRR = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_drv_encoderRL = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_drv_encoderFR = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_drv_encoderFL = new System.Windows.Forms.TextBox();
            this.button_drv_setZero = new System.Windows.Forms.Button();
            this.button_drv_setSpeed = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_drv_speed = new System.Windows.Forms.TextBox();
            this.trackBar_drv_speed = new System.Windows.Forms.TrackBar();
            this.button_drv_off = new System.Windows.Forms.Button();
            this.button_drv_on = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button_str_setOffset = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox_srv_voltage = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox_srv_current = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox_srv_temp = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox_srv_angle = new System.Windows.Forms.TextBox();
            this.button_str_setAngle = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox_str_angle = new System.Windows.Forms.TextBox();
            this.button_str_setZero = new System.Windows.Forms.Button();
            this.trackBar_str_angle = new System.Windows.Forms.TrackBar();
            this.button_str_off = new System.Windows.Forms.Button();
            this.button_str_on = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button_imu_setOffset = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox_imu_accZ = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox_imu_accY = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox_imu_accX = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox_imu_gyro = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox_pwr_voltage = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.textBox_ir7 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.textBox_ir6 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.textBox_ir5 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.textBox_ir4 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.textBox_ir3 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox_ir2 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox_ir1 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.textBox_ir0 = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.textBox_thermo_fet2 = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.textBox_thermo_fet1 = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_drv_speed)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_str_angle)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.connectToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(657, 26);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // connectToolStripMenuItem
            // 
            this.connectToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.closeToolStripMenuItem});
            this.connectToolStripMenuItem.Name = "connectToolStripMenuItem";
            this.connectToolStripMenuItem.Size = new System.Drawing.Size(67, 22);
            this.connectToolStripMenuItem.Text = "Connect";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.toolStrip1.Location = new System.Drawing.Point(116, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(110, 25);
            this.toolStrip1.TabIndex = 36;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(98, 20);
            this.toolStripStatusLabel1.Text = "Not Connected.";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.textBox_drv_encoderM);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.textBox_drv_encoderRR);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.textBox_drv_encoderRL);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.textBox_drv_encoderFR);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBox_drv_encoderFL);
            this.groupBox1.Controls.Add(this.button_drv_setZero);
            this.groupBox1.Controls.Add(this.button_drv_setSpeed);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBox_drv_speed);
            this.groupBox1.Controls.Add(this.trackBar_drv_speed);
            this.groupBox1.Controls.Add(this.button_drv_off);
            this.groupBox1.Controls.Add(this.button_drv_on);
            this.groupBox1.Location = new System.Drawing.Point(12, 29);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(307, 270);
            this.groupBox1.TabIndex = 37;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Drive";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(197, 241);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 12);
            this.label12.TabIndex = 24;
            this.label12.Text = "[cycle/sec]";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 241);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(79, 12);
            this.label13.TabIndex = 23;
            this.label13.Text = "Motor Encoder";
            // 
            // textBox_drv_encoderM
            // 
            this.textBox_drv_encoderM.Location = new System.Drawing.Point(109, 238);
            this.textBox_drv_encoderM.Name = "textBox_drv_encoderM";
            this.textBox_drv_encoderM.ReadOnly = true;
            this.textBox_drv_encoderM.Size = new System.Drawing.Size(82, 19);
            this.textBox_drv_encoderM.TabIndex = 22;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(197, 216);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 12);
            this.label10.TabIndex = 21;
            this.label10.Text = "[mm/sec]";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 216);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 12);
            this.label11.TabIndex = 20;
            this.label11.Text = "Wheel Encoder RR";
            // 
            // textBox_drv_encoderRR
            // 
            this.textBox_drv_encoderRR.Location = new System.Drawing.Point(109, 213);
            this.textBox_drv_encoderRR.Name = "textBox_drv_encoderRR";
            this.textBox_drv_encoderRR.ReadOnly = true;
            this.textBox_drv_encoderRR.Size = new System.Drawing.Size(82, 19);
            this.textBox_drv_encoderRR.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(197, 191);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 12);
            this.label8.TabIndex = 18;
            this.label8.Text = "[mm/sec]";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 191);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 12);
            this.label9.TabIndex = 17;
            this.label9.Text = "Wheel Encoder RL";
            // 
            // textBox_drv_encoderRL
            // 
            this.textBox_drv_encoderRL.Location = new System.Drawing.Point(109, 188);
            this.textBox_drv_encoderRL.Name = "textBox_drv_encoderRL";
            this.textBox_drv_encoderRL.ReadOnly = true;
            this.textBox_drv_encoderRL.Size = new System.Drawing.Size(82, 19);
            this.textBox_drv_encoderRL.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(197, 166);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 12);
            this.label6.TabIndex = 15;
            this.label6.Text = "[mm/sec]";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 166);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(99, 12);
            this.label7.TabIndex = 14;
            this.label7.Text = "Wheel Encoder FR";
            // 
            // textBox_drv_encoderFR
            // 
            this.textBox_drv_encoderFR.Location = new System.Drawing.Point(109, 163);
            this.textBox_drv_encoderFR.Name = "textBox_drv_encoderFR";
            this.textBox_drv_encoderFR.ReadOnly = true;
            this.textBox_drv_encoderFR.Size = new System.Drawing.Size(82, 19);
            this.textBox_drv_encoderFR.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(197, 141);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 12);
            this.label5.TabIndex = 12;
            this.label5.Text = "[mm/sec]";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 141);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 12);
            this.label4.TabIndex = 11;
            this.label4.Text = "Wheel Encoder FL";
            // 
            // textBox_drv_encoderFL
            // 
            this.textBox_drv_encoderFL.Location = new System.Drawing.Point(109, 138);
            this.textBox_drv_encoderFL.Name = "textBox_drv_encoderFL";
            this.textBox_drv_encoderFL.ReadOnly = true;
            this.textBox_drv_encoderFL.Size = new System.Drawing.Size(82, 19);
            this.textBox_drv_encoderFL.TabIndex = 10;
            // 
            // button_drv_setZero
            // 
            this.button_drv_setZero.Location = new System.Drawing.Point(226, 18);
            this.button_drv_setZero.Name = "button_drv_setZero";
            this.button_drv_setZero.Size = new System.Drawing.Size(75, 23);
            this.button_drv_setZero.TabIndex = 8;
            this.button_drv_setZero.Text = "setZero";
            this.button_drv_setZero.UseVisualStyleBackColor = true;
            this.button_drv_setZero.Click += new System.EventHandler(this.button_drv_setZero_Click);
            // 
            // button_drv_setSpeed
            // 
            this.button_drv_setSpeed.Location = new System.Drawing.Point(226, 98);
            this.button_drv_setSpeed.Name = "button_drv_setSpeed";
            this.button_drv_setSpeed.Size = new System.Drawing.Size(75, 23);
            this.button_drv_setSpeed.TabIndex = 7;
            this.button_drv_setSpeed.Text = "setSpeed";
            this.button_drv_setSpeed.UseVisualStyleBackColor = true;
            this.button_drv_setSpeed.Click += new System.EventHandler(this.button_drv_setSpeed_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(272, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "2800";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "-2800";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(163, 103);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "[mm/sec]";
            // 
            // textBox_drv_speed
            // 
            this.textBox_drv_speed.Location = new System.Drawing.Point(87, 100);
            this.textBox_drv_speed.Name = "textBox_drv_speed";
            this.textBox_drv_speed.Size = new System.Drawing.Size(70, 19);
            this.textBox_drv_speed.TabIndex = 3;
            // 
            // trackBar_drv_speed
            // 
            this.trackBar_drv_speed.Location = new System.Drawing.Point(6, 47);
            this.trackBar_drv_speed.Maximum = 2800;
            this.trackBar_drv_speed.Minimum = -2800;
            this.trackBar_drv_speed.Name = "trackBar_drv_speed";
            this.trackBar_drv_speed.Size = new System.Drawing.Size(295, 45);
            this.trackBar_drv_speed.TabIndex = 2;
            this.trackBar_drv_speed.Scroll += new System.EventHandler(this.trackBar_drv_speed_Scroll);
            // 
            // button_drv_off
            // 
            this.button_drv_off.Location = new System.Drawing.Point(87, 18);
            this.button_drv_off.Name = "button_drv_off";
            this.button_drv_off.Size = new System.Drawing.Size(75, 23);
            this.button_drv_off.TabIndex = 1;
            this.button_drv_off.Text = "OFF";
            this.button_drv_off.UseVisualStyleBackColor = true;
            this.button_drv_off.Click += new System.EventHandler(this.button_drv_off_Click);
            // 
            // button_drv_on
            // 
            this.button_drv_on.Location = new System.Drawing.Point(6, 18);
            this.button_drv_on.Name = "button_drv_on";
            this.button_drv_on.Size = new System.Drawing.Size(75, 23);
            this.button_drv_on.TabIndex = 0;
            this.button_drv_on.Text = "ON";
            this.button_drv_on.UseVisualStyleBackColor = true;
            this.button_drv_on.Click += new System.EventHandler(this.button_drv_on_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox2.Controls.Add(this.button_str_setOffset);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.textBox_srv_voltage);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.textBox_srv_current);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.textBox_srv_temp);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.textBox_srv_angle);
            this.groupBox2.Controls.Add(this.button_str_setAngle);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.textBox_str_angle);
            this.groupBox2.Controls.Add(this.button_str_setZero);
            this.groupBox2.Controls.Add(this.trackBar_str_angle);
            this.groupBox2.Controls.Add(this.button_str_off);
            this.groupBox2.Controls.Add(this.button_str_on);
            this.groupBox2.Location = new System.Drawing.Point(334, 29);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(305, 270);
            this.groupBox2.TabIndex = 38;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Steer";
            // 
            // button_str_setOffset
            // 
            this.button_str_setOffset.Location = new System.Drawing.Point(224, 241);
            this.button_str_setOffset.Name = "button_str_setOffset";
            this.button_str_setOffset.Size = new System.Drawing.Size(75, 23);
            this.button_str_setOffset.TabIndex = 34;
            this.button_str_setOffset.Text = "setOffset";
            this.button_str_setOffset.UseVisualStyleBackColor = true;
            this.button_str_setOffset.Click += new System.EventHandler(this.button_str_setOffset_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(185, 216);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(30, 12);
            this.label15.TabIndex = 33;
            this.label15.Text = "[mV]";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(11, 216);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(75, 12);
            this.label16.TabIndex = 32;
            this.label16.Text = "Servo voltage";
            // 
            // textBox_srv_voltage
            // 
            this.textBox_srv_voltage.Location = new System.Drawing.Point(97, 213);
            this.textBox_srv_voltage.Name = "textBox_srv_voltage";
            this.textBox_srv_voltage.ReadOnly = true;
            this.textBox_srv_voltage.Size = new System.Drawing.Size(82, 19);
            this.textBox_srv_voltage.TabIndex = 31;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(185, 191);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(30, 12);
            this.label17.TabIndex = 30;
            this.label17.Text = "[mA]";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(11, 191);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(74, 12);
            this.label18.TabIndex = 29;
            this.label18.Text = "Servo current";
            // 
            // textBox_srv_current
            // 
            this.textBox_srv_current.Location = new System.Drawing.Point(97, 188);
            this.textBox_srv_current.Name = "textBox_srv_current";
            this.textBox_srv_current.ReadOnly = true;
            this.textBox_srv_current.Size = new System.Drawing.Size(82, 19);
            this.textBox_srv_current.TabIndex = 28;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(185, 166);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(25, 12);
            this.label19.TabIndex = 27;
            this.label19.Text = "[℃]";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(11, 166);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(63, 12);
            this.label20.TabIndex = 26;
            this.label20.Text = "Servo temp";
            // 
            // textBox_srv_temp
            // 
            this.textBox_srv_temp.Location = new System.Drawing.Point(97, 163);
            this.textBox_srv_temp.Name = "textBox_srv_temp";
            this.textBox_srv_temp.ReadOnly = true;
            this.textBox_srv_temp.Size = new System.Drawing.Size(82, 19);
            this.textBox_srv_temp.TabIndex = 25;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(185, 141);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(31, 12);
            this.label21.TabIndex = 24;
            this.label21.Text = "[deg]";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(11, 141);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 12);
            this.label22.TabIndex = 23;
            this.label22.Text = "Servo angle";
            // 
            // textBox_srv_angle
            // 
            this.textBox_srv_angle.Location = new System.Drawing.Point(97, 138);
            this.textBox_srv_angle.Name = "textBox_srv_angle";
            this.textBox_srv_angle.ReadOnly = true;
            this.textBox_srv_angle.Size = new System.Drawing.Size(82, 19);
            this.textBox_srv_angle.TabIndex = 22;
            // 
            // button_str_setAngle
            // 
            this.button_str_setAngle.Location = new System.Drawing.Point(224, 96);
            this.button_str_setAngle.Name = "button_str_setAngle";
            this.button_str_setAngle.Size = new System.Drawing.Size(75, 23);
            this.button_str_setAngle.TabIndex = 15;
            this.button_str_setAngle.Text = "setAngle";
            this.button_str_setAngle.UseVisualStyleBackColor = true;
            this.button_str_setAngle.Click += new System.EventHandler(this.button_str_setAngle_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(179, 101);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(31, 12);
            this.label14.TabIndex = 14;
            this.label14.Text = "[deg]";
            // 
            // textBox_str_angle
            // 
            this.textBox_str_angle.Location = new System.Drawing.Point(103, 98);
            this.textBox_str_angle.Name = "textBox_str_angle";
            this.textBox_str_angle.Size = new System.Drawing.Size(70, 19);
            this.textBox_str_angle.TabIndex = 13;
            // 
            // button_str_setZero
            // 
            this.button_str_setZero.Location = new System.Drawing.Point(226, 18);
            this.button_str_setZero.Name = "button_str_setZero";
            this.button_str_setZero.Size = new System.Drawing.Size(75, 23);
            this.button_str_setZero.TabIndex = 12;
            this.button_str_setZero.Text = "setZero";
            this.button_str_setZero.UseVisualStyleBackColor = true;
            this.button_str_setZero.Click += new System.EventHandler(this.button_str_setZero_Click);
            // 
            // trackBar_str_angle
            // 
            this.trackBar_str_angle.Location = new System.Drawing.Point(6, 47);
            this.trackBar_str_angle.Maximum = 300;
            this.trackBar_str_angle.Minimum = -300;
            this.trackBar_str_angle.Name = "trackBar_str_angle";
            this.trackBar_str_angle.Size = new System.Drawing.Size(295, 45);
            this.trackBar_str_angle.TabIndex = 11;
            this.trackBar_str_angle.Scroll += new System.EventHandler(this.trackBar_str_angle_Scroll);
            // 
            // button_str_off
            // 
            this.button_str_off.Location = new System.Drawing.Point(87, 18);
            this.button_str_off.Name = "button_str_off";
            this.button_str_off.Size = new System.Drawing.Size(75, 23);
            this.button_str_off.TabIndex = 10;
            this.button_str_off.Text = "OFF";
            this.button_str_off.UseVisualStyleBackColor = true;
            this.button_str_off.Click += new System.EventHandler(this.button_str_off_Click);
            // 
            // button_str_on
            // 
            this.button_str_on.Location = new System.Drawing.Point(6, 18);
            this.button_str_on.Name = "button_str_on";
            this.button_str_on.Size = new System.Drawing.Size(75, 23);
            this.button_str_on.TabIndex = 9;
            this.button_str_on.Text = "ON";
            this.button_str_on.UseVisualStyleBackColor = true;
            this.button_str_on.Click += new System.EventHandler(this.button_str_on_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox3.Controls.Add(this.button_imu_setOffset);
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.label30);
            this.groupBox3.Controls.Add(this.textBox_imu_accZ);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.textBox_imu_accY);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.textBox_imu_accX);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.textBox_imu_gyro);
            this.groupBox3.Location = new System.Drawing.Point(12, 315);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(307, 130);
            this.groupBox3.TabIndex = 39;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "IMU";
            // 
            // button_imu_setOffset
            // 
            this.button_imu_setOffset.Location = new System.Drawing.Point(217, 99);
            this.button_imu_setOffset.Name = "button_imu_setOffset";
            this.button_imu_setOffset.Size = new System.Drawing.Size(75, 23);
            this.button_imu_setOffset.TabIndex = 25;
            this.button_imu_setOffset.Text = "setOffset";
            this.button_imu_setOffset.UseVisualStyleBackColor = true;
            this.button_imu_setOffset.Click += new System.EventHandler(this.button_imu_setOffset_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(143, 102);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(21, 12);
            this.label29.TabIndex = 24;
            this.label29.Text = "[G]";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(9, 102);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(32, 12);
            this.label30.TabIndex = 23;
            this.label30.Text = "AccZ";
            // 
            // textBox_imu_accZ
            // 
            this.textBox_imu_accZ.Location = new System.Drawing.Point(51, 99);
            this.textBox_imu_accZ.Name = "textBox_imu_accZ";
            this.textBox_imu_accZ.ReadOnly = true;
            this.textBox_imu_accZ.Size = new System.Drawing.Size(82, 19);
            this.textBox_imu_accZ.TabIndex = 22;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(143, 77);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(21, 12);
            this.label27.TabIndex = 21;
            this.label27.Text = "[G]";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(9, 77);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(32, 12);
            this.label28.TabIndex = 20;
            this.label28.Text = "AccY";
            // 
            // textBox_imu_accY
            // 
            this.textBox_imu_accY.Location = new System.Drawing.Point(51, 74);
            this.textBox_imu_accY.Name = "textBox_imu_accY";
            this.textBox_imu_accY.ReadOnly = true;
            this.textBox_imu_accY.Size = new System.Drawing.Size(82, 19);
            this.textBox_imu_accY.TabIndex = 19;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(143, 52);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(21, 12);
            this.label25.TabIndex = 18;
            this.label25.Text = "[G]";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(9, 52);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(32, 12);
            this.label26.TabIndex = 17;
            this.label26.Text = "AccX";
            // 
            // textBox_imu_accX
            // 
            this.textBox_imu_accX.Location = new System.Drawing.Point(51, 49);
            this.textBox_imu_accX.Name = "textBox_imu_accX";
            this.textBox_imu_accX.ReadOnly = true;
            this.textBox_imu_accX.Size = new System.Drawing.Size(82, 19);
            this.textBox_imu_accX.TabIndex = 16;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(143, 27);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(55, 12);
            this.label23.TabIndex = 15;
            this.label23.Text = "[deg/sec]";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(9, 27);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(29, 12);
            this.label24.TabIndex = 14;
            this.label24.Text = "Gyro";
            // 
            // textBox_imu_gyro
            // 
            this.textBox_imu_gyro.Location = new System.Drawing.Point(51, 24);
            this.textBox_imu_gyro.Name = "textBox_imu_gyro";
            this.textBox_imu_gyro.ReadOnly = true;
            this.textBox_imu_gyro.Size = new System.Drawing.Size(82, 19);
            this.textBox_imu_gyro.TabIndex = 13;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox4.Controls.Add(this.label33);
            this.groupBox4.Controls.Add(this.label34);
            this.groupBox4.Controls.Add(this.textBox_pwr_voltage);
            this.groupBox4.Location = new System.Drawing.Point(12, 458);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(307, 72);
            this.groupBox4.TabIndex = 40;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "power";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(186, 46);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(21, 12);
            this.label33.TabIndex = 30;
            this.label33.Text = "[V]";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(9, 46);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(86, 12);
            this.label34.TabIndex = 29;
            this.label34.Text = "Battery Voltage";
            // 
            // textBox_pwr_voltage
            // 
            this.textBox_pwr_voltage.Location = new System.Drawing.Point(99, 43);
            this.textBox_pwr_voltage.Name = "textBox_pwr_voltage";
            this.textBox_pwr_voltage.ReadOnly = true;
            this.textBox_pwr_voltage.Size = new System.Drawing.Size(82, 19);
            this.textBox_pwr_voltage.TabIndex = 28;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox5.Controls.Add(this.label49);
            this.groupBox5.Controls.Add(this.label50);
            this.groupBox5.Controls.Add(this.textBox_ir7);
            this.groupBox5.Controls.Add(this.label47);
            this.groupBox5.Controls.Add(this.label48);
            this.groupBox5.Controls.Add(this.textBox_ir6);
            this.groupBox5.Controls.Add(this.label45);
            this.groupBox5.Controls.Add(this.label46);
            this.groupBox5.Controls.Add(this.textBox_ir5);
            this.groupBox5.Controls.Add(this.label43);
            this.groupBox5.Controls.Add(this.label44);
            this.groupBox5.Controls.Add(this.textBox_ir4);
            this.groupBox5.Controls.Add(this.label41);
            this.groupBox5.Controls.Add(this.label42);
            this.groupBox5.Controls.Add(this.textBox_ir3);
            this.groupBox5.Controls.Add(this.label39);
            this.groupBox5.Controls.Add(this.label40);
            this.groupBox5.Controls.Add(this.textBox_ir2);
            this.groupBox5.Controls.Add(this.label37);
            this.groupBox5.Controls.Add(this.label38);
            this.groupBox5.Controls.Add(this.textBox_ir1);
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.label36);
            this.groupBox5.Controls.Add(this.textBox_ir0);
            this.groupBox5.Location = new System.Drawing.Point(334, 315);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(151, 222);
            this.groupBox5.TabIndex = 41;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "IR Obstacle";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(110, 198);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(31, 12);
            this.label49.TabIndex = 39;
            this.label49.Text = "[mm]";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(14, 198);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(22, 12);
            this.label50.TabIndex = 38;
            this.label50.Text = "IR7";
            // 
            // textBox_ir7
            // 
            this.textBox_ir7.Location = new System.Drawing.Point(42, 195);
            this.textBox_ir7.Name = "textBox_ir7";
            this.textBox_ir7.ReadOnly = true;
            this.textBox_ir7.Size = new System.Drawing.Size(62, 19);
            this.textBox_ir7.TabIndex = 37;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(110, 173);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(31, 12);
            this.label47.TabIndex = 36;
            this.label47.Text = "[mm]";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(14, 173);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(22, 12);
            this.label48.TabIndex = 35;
            this.label48.Text = "IR6";
            // 
            // textBox_ir6
            // 
            this.textBox_ir6.Location = new System.Drawing.Point(42, 170);
            this.textBox_ir6.Name = "textBox_ir6";
            this.textBox_ir6.ReadOnly = true;
            this.textBox_ir6.Size = new System.Drawing.Size(62, 19);
            this.textBox_ir6.TabIndex = 34;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(110, 148);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(31, 12);
            this.label45.TabIndex = 33;
            this.label45.Text = "[mm]";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(14, 148);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(22, 12);
            this.label46.TabIndex = 32;
            this.label46.Text = "IR5";
            // 
            // textBox_ir5
            // 
            this.textBox_ir5.Location = new System.Drawing.Point(42, 145);
            this.textBox_ir5.Name = "textBox_ir5";
            this.textBox_ir5.ReadOnly = true;
            this.textBox_ir5.Size = new System.Drawing.Size(62, 19);
            this.textBox_ir5.TabIndex = 31;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(110, 123);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(31, 12);
            this.label43.TabIndex = 30;
            this.label43.Text = "[mm]";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(14, 123);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(22, 12);
            this.label44.TabIndex = 29;
            this.label44.Text = "IR4";
            // 
            // textBox_ir4
            // 
            this.textBox_ir4.Location = new System.Drawing.Point(42, 120);
            this.textBox_ir4.Name = "textBox_ir4";
            this.textBox_ir4.ReadOnly = true;
            this.textBox_ir4.Size = new System.Drawing.Size(62, 19);
            this.textBox_ir4.TabIndex = 28;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(110, 98);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(31, 12);
            this.label41.TabIndex = 27;
            this.label41.Text = "[mm]";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(14, 98);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(22, 12);
            this.label42.TabIndex = 26;
            this.label42.Text = "IR3";
            // 
            // textBox_ir3
            // 
            this.textBox_ir3.Location = new System.Drawing.Point(42, 95);
            this.textBox_ir3.Name = "textBox_ir3";
            this.textBox_ir3.ReadOnly = true;
            this.textBox_ir3.Size = new System.Drawing.Size(62, 19);
            this.textBox_ir3.TabIndex = 25;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(110, 73);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(31, 12);
            this.label39.TabIndex = 24;
            this.label39.Text = "[mm]";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(14, 73);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(22, 12);
            this.label40.TabIndex = 23;
            this.label40.Text = "IR2";
            // 
            // textBox_ir2
            // 
            this.textBox_ir2.Location = new System.Drawing.Point(42, 70);
            this.textBox_ir2.Name = "textBox_ir2";
            this.textBox_ir2.ReadOnly = true;
            this.textBox_ir2.Size = new System.Drawing.Size(62, 19);
            this.textBox_ir2.TabIndex = 22;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(110, 48);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(31, 12);
            this.label37.TabIndex = 21;
            this.label37.Text = "[mm]";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(14, 48);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(22, 12);
            this.label38.TabIndex = 20;
            this.label38.Text = "IR1";
            // 
            // textBox_ir1
            // 
            this.textBox_ir1.Location = new System.Drawing.Point(42, 45);
            this.textBox_ir1.Name = "textBox_ir1";
            this.textBox_ir1.ReadOnly = true;
            this.textBox_ir1.Size = new System.Drawing.Size(62, 19);
            this.textBox_ir1.TabIndex = 19;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(110, 23);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(31, 12);
            this.label35.TabIndex = 18;
            this.label35.Text = "[mm]";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(14, 23);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(22, 12);
            this.label36.TabIndex = 17;
            this.label36.Text = "IR0";
            // 
            // textBox_ir0
            // 
            this.textBox_ir0.Location = new System.Drawing.Point(42, 20);
            this.textBox_ir0.Name = "textBox_ir0";
            this.textBox_ir0.ReadOnly = true;
            this.textBox_ir0.Size = new System.Drawing.Size(62, 19);
            this.textBox_ir0.TabIndex = 16;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox6.Controls.Add(this.label53);
            this.groupBox6.Controls.Add(this.label54);
            this.groupBox6.Controls.Add(this.textBox_thermo_fet2);
            this.groupBox6.Controls.Add(this.label55);
            this.groupBox6.Controls.Add(this.label56);
            this.groupBox6.Controls.Add(this.textBox_thermo_fet1);
            this.groupBox6.Location = new System.Drawing.Point(491, 315);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(148, 85);
            this.groupBox6.TabIndex = 42;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Thermo";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(111, 59);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(25, 12);
            this.label53.TabIndex = 30;
            this.label53.Text = "[℃]";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(8, 59);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(32, 12);
            this.label54.TabIndex = 29;
            this.label54.Text = "FET2";
            // 
            // textBox_thermo_fet2
            // 
            this.textBox_thermo_fet2.Location = new System.Drawing.Point(46, 56);
            this.textBox_thermo_fet2.Name = "textBox_thermo_fet2";
            this.textBox_thermo_fet2.ReadOnly = true;
            this.textBox_thermo_fet2.Size = new System.Drawing.Size(59, 19);
            this.textBox_thermo_fet2.TabIndex = 28;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(111, 34);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(25, 12);
            this.label55.TabIndex = 27;
            this.label55.Text = "[℃]";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(8, 34);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(32, 12);
            this.label56.TabIndex = 26;
            this.label56.Text = "FET1";
            // 
            // textBox_thermo_fet1
            // 
            this.textBox_thermo_fet1.Location = new System.Drawing.Point(46, 31);
            this.textBox_thermo_fet1.Name = "textBox_thermo_fet1";
            this.textBox_thermo_fet1.ReadOnly = true;
            this.textBox_thermo_fet1.Size = new System.Drawing.Size(59, 19);
            this.textBox_thermo_fet1.TabIndex = 25;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // SensorSampleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(657, 556);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "SensorSampleForm";
            this.Text = "SensorSample";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_drv_speed)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_str_angle)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem connectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox_drv_encoderM;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox_drv_encoderRR;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_drv_encoderRL;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_drv_encoderFR;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_drv_encoderFL;
        private System.Windows.Forms.Button button_drv_setZero;
        private System.Windows.Forms.Button button_drv_setSpeed;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_drv_speed;
        private System.Windows.Forms.TrackBar trackBar_drv_speed;
        private System.Windows.Forms.Button button_drv_off;
        private System.Windows.Forms.Button button_drv_on;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button_str_setOffset;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox_srv_voltage;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox_srv_current;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox_srv_temp;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox_srv_angle;
        private System.Windows.Forms.Button button_str_setAngle;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox_str_angle;
        private System.Windows.Forms.Button button_str_setZero;
        private System.Windows.Forms.TrackBar trackBar_str_angle;
        private System.Windows.Forms.Button button_str_off;
        private System.Windows.Forms.Button button_str_on;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button_imu_setOffset;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox_imu_accZ;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox_imu_accY;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox_imu_accX;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox_imu_gyro;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox_pwr_voltage;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox textBox_ir7;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textBox_ir6;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox textBox_ir5;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox textBox_ir4;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox textBox_ir3;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox_ir2;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox_ir1;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox textBox_ir0;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox textBox_thermo_fet2;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox textBox_thermo_fet1;
        private System.Windows.Forms.Timer timer1;
    }
}

