﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;

//using System.Net;
using System.IO;
//using System.Web;

//using Zmp.Imuz.Communication;
//using Zmp.Imuz.Estimator;
using Zmp.Rcz.Communication;

namespace RczControl
{

    public partial class SensorSampleForm : Form
    {
        /// <summary>
        /// Connect
        /// </summary>
        private connectConfig _config = new connectConfig();
        private RczCommunication _comm = new RczCommunication();

        /// <summary>
        /// config tab
        /// </summary>
//        ConfigTable _readConfTable;
        int _readConfLen;
        bool _readConfAll;
        int _offsetCnt;
        int _sndSpeed;

        public SensorSampleForm()
        {
            InitializeComponent();
            textBox_str_angle.Text = "0";
            textBox_drv_speed.Text = "0";

//            _readConfTable = ConfigTable.VelocityGainP;
            _readConfLen = 0;
            _readConfAll = false;
            _offsetCnt = -1;
        }

        private void onReceived(object sender, RczMsg msg)
        {
            try
            {
                switch ((RCZHMSG_ID)msg.id)
                {
                    case RCZHMSG_ID.RCZHMSG_ID_GET_SENSOR_INFO_RES:
                        ParseSensorInf(msg);
                        break;
                    case RCZHMSG_ID.RCZHMSG_ID_GET_OBSTACLE_INFO_RES:
                        ParseObstacleInf(msg);
                        break;
                    case RCZHMSG_ID.RCZHMSG_ID_GET_POWER_INFO_RES:
                        ParsePowerInf(msg);
                        break;
/*                    case RCZHMSG_ID.RCZHMSG_ID_GET_LRS_INFO_RES:
                        ParseLaneResult(msg);
                        break;
                    case RCZHMSG_ID.RCZHMSG_ID_GET_CAMBER_INFO_RES:
                        ParseCamberInf(msg);
                        break;*/
                    case RCZHMSG_ID.RCZHMSG_ID_GET_SERVO_INFO_RES:
                        ParseServoInf(msg);
                        break;
                    case RCZHMSG_ID.RCZHMSG_ID_GET_THERMO_INFO_RES:
                        ParseThermoInf(msg);
                        break;

/*                    case RCZHMSG_ID.RCZHMSG_ID_IMAGE:
                        ParseImage(msg);
                        break;
                    case RCZHMSG_ID.RCZHMSG_ID_LANE_RESULT:
                        ParseLaneResult(msg);
                        break;
                    case RCZHMSG_ID.RCZHMSG_ID_STEREO_RESULT_HIST:
                        ParseStereoResultHist(msg);
                        break;
                    case RCZHMSG_ID.RCZHMSG_ID_STEREO_RESULT_HOUGH:
                        ParseStereoResultHough(msg);
                        break;
                    case RCZHMSG_ID.RCZHMSG_ID_STEREO_RESULT_LABELING:
                        ParseStereoResultLabeling(msg);
                        break;*/

                    default: break;
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }


/*
 * Connect
 */
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_comm.IsConnect)
            {
                return;
            }
            serializeConfig(false);

            OpenDialog dlg = new OpenDialog();
            if (_config.HostName == null)
                dlg.HostName = "192.168.1.35";
            else
                dlg.HostName = _config.HostName;

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                _config.HostName = dlg.HostName;
                serializeConfig(true);

                if (dlg.HostName == "")
                {
                    return;
                }
                else if (dlg.HostName.IndexOf("COM") == 0)
                {
                    _comm = new RczCommunication();
                    _comm.HostName = dlg.HostName;
                }
                else if (dlg.HostName.IndexOf("Vector") != -1 || dlg.HostName.IndexOf("Case") != -1 || dlg.HostName.IndexOf("XL") != -1)
                {
                    _comm = new RczCommunication();
                }
                else if (dlg.HostName.IndexOf(".") != -1)
                {
                    _comm = new RczCommunication();
                    _comm.PortNo = 9292;
                    _comm.HostName = string.Format("{0}", dlg.HostName);
                }
                _comm.Received += onReceived;
                _comm.OpenedOrClosed += onOpenedorClosed;
                if (_comm.Open())
                {
                }
                else
                {
                    MessageBox.Show("Can not open.");
                }
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_comm.IsConnect)
            {
                _comm.Close();
            }
        }

        private void onReceived(object sender)
        {
            string str = "Connect. (Data recieveing.)";
            toolStripStatusLabel1.Text = str;
        }

        private void onOpenedorClosed(object sender, bool bOpened)
        {
            string str;
            if (bOpened)
            {
                str = "Connect.";
                toolStripStatusLabel1.Text = str;
            }
            else
            {
                str = "Disonnect.";
            }
        }

        private void serializeConfig(bool save)
        {
            try
            {
                string path = Application.StartupPath + @"\PortOpenDialog.config.xml";
                XmlSerializer serializer = new XmlSerializer(typeof(connectConfig));
                if (save)
                {
                    FileStream fs = new FileStream(path, FileMode.Create);
                    serializer.Serialize(fs, _config);
                    fs.Close();
                }
                else
                {
                    FileStream fs = new FileStream(path, FileMode.Open);
                    _config = (connectConfig)serializer.Deserialize(fs);
                    fs.Close();
                }
            }
            catch (Exception)
            {
                // Ignore any.
            }

        }

/* drive control */
        private void button_drv_on_Click(object sender, EventArgs e)
        {
            _comm.Send(RczPacket.SetDriveMotor(1));
            _offsetCnt = 30;
        }

        private void button_drv_off_Click(object sender, EventArgs e)
        {
            _comm.Send(RczPacket.SetDriveMotor(0));
            _sndSpeed = 0;
        }

        private void button_drv_setZero_Click(object sender, EventArgs e)
        {
            _comm.Send(RczPacket.SetDriveVelocity(0));
            trackBar_drv_speed.Value = 0;
            textBox_drv_speed.Text = "0";
            _sndSpeed = 0;
        }

        private void button_drv_setSpeed_Click(object sender, EventArgs e)
        {
            if (textBox_drv_speed.Text == "")
                return;
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox_drv_speed.Text, @"([^-0123456789.])"))
                return;
            if (textBox_drv_speed.Text.IndexOf("-") > 0)
                return;
            int speed = int.Parse(textBox_drv_speed.Text);
            _comm.Send(RczPacket.SetDriveVelocity(speed));
            trackBar_drv_speed.Value = speed;
            _sndSpeed = speed;
        }

        private void trackBar_drv_speed_Scroll(object sender, EventArgs e)
        {
            int speed = trackBar_drv_speed.Value;
            _comm.Send(RczPacket.SetDriveVelocity(speed));
            textBox_drv_speed.Text = speed.ToString();
            _sndSpeed = speed;
        }


/* parse */
        private void ParseSensorInf(RczMsg msg)
        {
            RcvSensorInf sensor;
            _comm.ParseSensorInf(msg, out sensor);
            Invoke((MethodInvoker)delegate
            {
                textBox_imu_accX.Text = sensor.acc_x.ToString("f5");
                textBox_imu_accY.Text = sensor.acc_y.ToString("f5");
                textBox_imu_accZ.Text = sensor.acc_z.ToString("f5");
                textBox_imu_gyro.Text = sensor.gyro.ToString("f5");
                textBox_drv_encoderM.Text = sensor.motor_enc.ToString("f2");
                textBox_drv_encoderFL.Text = sensor.wheel_enc1.ToString("f2");
                textBox_drv_encoderFR.Text = sensor.wheel_enc2.ToString("f2");
                textBox_drv_encoderRL.Text = sensor.wheel_enc3.ToString("f2");
                textBox_drv_encoderRR.Text = sensor.wheel_enc4.ToString("f2");
            });

        }

        private void ParsePowerInf(RczMsg msg)
        {
/*            if (_offsetCnt > 1)
                _offsetCnt -= 1;
            else if(_offsetCnt > 0){
                float offset = float.Parse(textBox_pwr_current.Text);
                _comm.Send(RczPacket.SetCurrentOffset(offset));
                _offsetCnt = -1;
            }*/
            RcvPowerInf power;
            _comm.ParsePowerInf(msg, out power);
            Invoke((MethodInvoker)delegate
            {
//                textBox_pwr_current.Text = power.motor_current.ToString("f2");
                textBox_pwr_voltage.Text = power.batt_voltage.ToString("f2");
            });
        }

        private void ParseObstacleInf(RczMsg msg)
        {
            RcvObstacleInf ir;
            _comm.ParseObstacleInf(msg, out ir);
            Invoke((MethodInvoker)delegate
            {
                textBox_ir0.Text = ir.ir_obstacle[0].ToString();
                textBox_ir1.Text = ir.ir_obstacle[1].ToString();
                textBox_ir2.Text = ir.ir_obstacle[2].ToString();
                textBox_ir3.Text = ir.ir_obstacle[3].ToString();
                textBox_ir4.Text = ir.ir_obstacle[4].ToString();
                textBox_ir5.Text = ir.ir_obstacle[5].ToString();
                textBox_ir6.Text = ir.ir_obstacle[6].ToString();
                textBox_ir7.Text = ir.ir_obstacle[7].ToString();
            });
        }

/*        private void ParseLrsInf(RczMsg msg)
        {
            LRSResult lrs;
            _comm.ParseLrsInf(msg, out lrs);
        }
*/

        /*
        private void ParseCamberInf(RczMsg msg)
        {
        }
        */

        private void ParseServoInf(RczMsg msg)
        {
            RcvServoInf servo;
            _comm.ParseServoInf(msg, out servo);
            Invoke((MethodInvoker)delegate
            {
                textBox_srv_angle.Text = servo.present_position.ToString("f1");
                textBox_srv_current.Text = servo.present_current.ToString();
                textBox_srv_temp.Text = servo.present_temperature.ToString();
                textBox_srv_voltage.Text = servo.present_volts.ToString();
            });
            
        }

        private void ParseThermoInf(RczMsg msg)
        {
            RcvThermoInf thermo;
            _comm.ParseThermoInf(msg, out thermo);
            Invoke((MethodInvoker)delegate
            {
                textBox_thermo_fet1.Text = thermo.thermo_fet1.ToString("f1");
                textBox_thermo_fet2.Text = thermo.thermo_fet2.ToString("f1");
            });
        }

        /*
        private void ParseImage(RczMsg msg)
        {
        }

        private void ParseLaneResult(RczMsg msg)
        {
        }

        private void ParseStereoResultHist(RczMsg msg)
        {
        }

        private void ParseStereoResultHough(RczMsg msg)
        {
        }

        private void ParseStereoResultLabeling(RczMsg msg)
        {
        }
         */

/* steer control */
        private void button_str_on_Click(object sender, EventArgs e)
        {
            _comm.Send(RczPacket.SetSteerServo(1));
        }

        private void button_str_off_Click(object sender, EventArgs e)
        {
            _comm.Send(RczPacket.SetSteerServo(0));
        }

        private void button_str_setAngle_Click(object sender, EventArgs e)
        {
            if (textBox_str_angle.Text == "")
                return;
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox_str_angle.Text, @"([^-0123456789.])"))
                return;
            if (textBox_str_angle.Text.IndexOf("-") > 0)
                return;
            float angle = float.Parse(textBox_str_angle.Text);
            _comm.Send(RczPacket.SetSteerAngle(angle));
            trackBar_str_angle.Value = (int)angle * 10;
        }

        private void button_str_setZero_Click(object sender, EventArgs e)
        {
            _comm.Send(RczPacket.SetSteerAngle(0));
            trackBar_str_angle.Value = 0;
            textBox_str_angle.Text = "0";
        }

        private void trackBar_str_angle_Scroll(object sender, EventArgs e)
        {
            float angle = (float)trackBar_str_angle.Value / 10.0f;
            _comm.Send(RczPacket.SetSteerAngle(angle));
            textBox_str_angle.Text = angle.ToString("f1");
        }

/* steer offset */
        private void button_str_setOffset_Click(object sender, EventArgs e)
        {
            float offset = float.Parse(textBox_srv_angle.Text);
            _comm.Send(RczPacket.SetSteerOffset(offset));
        }

/* gyro offset */
        private void button_imu_setOffset_Click(object sender, EventArgs e)
        {
            float offset = float.Parse(textBox_imu_gyro.Text);
            _comm.Send(RczPacket.SetGyroOffset(offset));
        }

/* current offset */
/*        private void button_pwr_setOffset_Click(object sender, EventArgs e)
        {
            float offset = float.Parse(textBox_pwr_current.Text);
            _comm.Send(RczPacket.SetCurrentOffset(offset));
        }*/

        private void timer1_Tick(object sender, EventArgs e)
        {
            _comm.Send(RczPacket.SetDriveVelocity(_sndSpeed));
        }

        private void label31_Click(object sender, EventArgs e)
        {

        }


	}

    public class connectConfig
    {
        public connectConfig() { }
        public string HostName { get; set; }
    }
}
