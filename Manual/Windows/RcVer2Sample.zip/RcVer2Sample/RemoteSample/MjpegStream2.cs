﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RczControl
{
    public partial class MjpegStream2 : Form
    {
        public MjpegStream2()
        {
            InitializeComponent();
        }

        public void SetImage(Bitmap img)
        {
            Invoke((MethodInvoker)delegate
            {
                pictureBox1.Image = img;
            });
        }

        public PictureBox GetPicBox()
        {
            return pictureBox1;
        }
    
    }
}
