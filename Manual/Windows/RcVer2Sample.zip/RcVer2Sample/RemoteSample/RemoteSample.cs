﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;

using System.IO;
using Zmp.Rcz.Communication;
using MjpegProcessor;
using Microsoft.DirectX.DirectInput;



namespace RczControl
{

    public partial class RemoteSampleForm : Form
    {
        /// <summary>
        /// Connect
        /// </summary>
        private connectConfig _config = new connectConfig();
        private RczCommunication _comm = new RczCommunication();
        private controlSetting _setting = new controlSetting();

        /// <summary>
        /// config tab
        /// </summary>
//        ConfigTable _readConfTable;
        int _readConfLen;
        bool _readConfAll;
        MjpegDecoder m_jpegdecoder;
        MjpegStream _mStream;
//        MjpegDecoder m_jpegdecoder2;
//        MjpegStream _mStream2;
        Device _wheelCnt = null;
        bool _bwdFlg;
        int _maxVeloc = 500;
        int _sndSpeed = 0;
        int _offsetCnt = 0;

        public RemoteSampleForm()
        {
            InitializeComponent();
            textBox_str_angle.Text = "0";
            textBox_drv_speed.Text = "0";
            textBox_max_veloc.Text = "500";
            _offsetCnt = -1;

//            _readConfTable = ConfigTable.VelocityGainP;
            _readConfLen = 0;
            _readConfAll = false;
            _bwdFlg = false;

            _mStream = new MjpegStream();
            _mStream.Show();
//            _mStream2 = new MjpegStream();
//            _mStream2.Show();

            //インスタンスを作成する
            m_jpegdecoder = new MjpegDecoder();
            //フレーム取得ハンドラを設定する
            m_jpegdecoder.FrameReady += FrameReady;

            //インスタンスを作成する
//            m_jpegdecoder2 = new MjpegDecoder();
            //フレーム取得ハンドラを設定する
//            m_jpegdecoder2.FrameReady += FrameReady2;

            readSetting();
            directXInitial();
        }

        public void FrameReady(object sender, FrameReadyEventArgs e)
        {
            //取得した画像をimageに設定する
            //pictureBox1.Image = e.Bitmap;
            Bitmap tmp = new Bitmap(_mStream.GetPicBox().Width, _mStream.GetPicBox().Height);
            Graphics g = Graphics.FromImage(tmp);
            Image img = e.Bitmap;
            g.DrawImage(img, 0, 0, img.Width / 2, img.Height / 2);

            _mStream.SetImage(tmp);
        }

/*        public void FrameReady2(object sender, FrameReadyEventArgs e)
        {
            //取得した画像をimageに設定する
            //pictureBox1.Image = e.Bitmap;
            Bitmap tmp = new Bitmap(_mStream2.GetPicBox().Width, _mStream2.GetPicBox().Height);
            Graphics g = Graphics.FromImage(tmp);
            Image img = e.Bitmap;
            g.DrawImage(img, 0, 0, img.Width / 2, img.Height / 2);

            _mStream2.SetImage(tmp);
        }
*/
        private void onReceived(object sender, RczMsg msg)
        {
            try
            {
                switch ((RCZHMSG_ID)msg.id)
                {
                    case RCZHMSG_ID.RCZHMSG_ID_GET_SENSOR_INFO_RES:
                        ParseSensorInf(msg);
                        break;
                    case RCZHMSG_ID.RCZHMSG_ID_GET_OBSTACLE_INFO_RES:
                        ParseObstacleInf(msg);
                        break;
                    case RCZHMSG_ID.RCZHMSG_ID_GET_POWER_INFO_RES:
                        ParsePowerInf(msg);
                        break;
                    case RCZHMSG_ID.RCZHMSG_ID_GET_SERVO_INFO_RES:
                        ParseServoInf(msg);
                        break;

                    case RCZHMSG_ID.RCZHMSG_ID_GET_THERMO_INFO_RES:
                        ParseThermoInf(msg);
                        break;

                    default: break;
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }


/*
 * Connect
 */
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_comm.IsConnect)
            {
                return;
            }
            serializeConfig(false);

            OpenDialog dlg = new OpenDialog();
            if (_config.HostName == null)
                dlg.HostName = "192.168.1.35";
            else
                dlg.HostName = _config.HostName;

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                _config.HostName = dlg.HostName;
                serializeConfig(true);

                if (dlg.HostName == "")
                {
                    return;
                }
                else if (dlg.HostName.IndexOf("COM") == 0)
                {
                    _comm = new RczCommunication();
                    _comm.HostName = dlg.HostName;
                }
                else if (dlg.HostName.IndexOf("Vector") != -1 || dlg.HostName.IndexOf("Case") != -1 || dlg.HostName.IndexOf("XL") != -1)
                {
                    _comm = new RczCommunication();
                }
                else if (dlg.HostName.IndexOf(".") != -1)
                {
                    _comm = new RczCommunication();
                    _comm.PortNo = 9292;
                    _comm.HostName = string.Format("{0}", dlg.HostName);
                }
                _comm.Received += onReceived;
                _comm.OpenedOrClosed += onOpenedorClosed;
                if (_comm.Open())
                {
                }
                else
                {
                    MessageBox.Show("Can not open.");
                }

                m_jpegdecoder.ParseStream(new Uri("http://" + dlg.HostName + ":8080/?action=stream"));
//                m_jpegdecoder2.ParseStream(new Uri("http://" + dlg.HostName + ":8081/?action=stream"));
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_comm.IsConnect)
            {
                _comm.Close();
                string str = "not connect";
                toolStripStatusLabel1.Text = str; 
            }
        }

        private void onReceived(object sender)
        {
            string str = "Connect. (Data recieveing.)";
            toolStripStatusLabel1.Text = str;
        }

        private void onOpenedorClosed(object sender, bool bOpened)
        {
            string str;
            if (bOpened)
            {
                str = "Connect.";
                toolStripStatusLabel1.Text = str;
            }
            else
            {
                str = "Disonnect.";
            }
        }

        private void serializeConfig(bool save)
        {
            try
            {
                string path = Application.StartupPath + @"\PortOpenDialog.config.xml";
                XmlSerializer serializer = new XmlSerializer(typeof(connectConfig));
                if (save)
                {
                    FileStream fs = new FileStream(path, FileMode.Create);
                    serializer.Serialize(fs, _config);
                    fs.Close();
                }
                else
                {
                    FileStream fs = new FileStream(path, FileMode.Open);
                    _config = (connectConfig)serializer.Deserialize(fs);
                    fs.Close();
                }
            }
            catch (Exception)
            {
                // Ignore any.
            }

        }

/* drive control */
        private void button_drv_on_Click(object sender, EventArgs e)
        {
            _comm.Send(RczPacket.SetDriveMotor(1));
            _offsetCnt = 30;
        }

        private void button_drv_off_Click(object sender, EventArgs e)
        {
            _comm.Send(RczPacket.SetDriveMotor(0));
            _sndSpeed = 0;
        }

        private void button_drv_setZero_Click(object sender, EventArgs e)
        {
            _comm.Send(RczPacket.SetDriveVelocity(0));
            trackBar_drv_speed.Value = 0;
            textBox_drv_speed.Text = "0";
            _sndSpeed = 0;
        }

        private void button_drv_setSpeed_Click(object sender, EventArgs e)
        {
            if (textBox_drv_speed.Text == "")
                return;
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox_drv_speed.Text, @"([^-0123456789.])"))
                return;
            if (textBox_drv_speed.Text.IndexOf("-") > 0)
                return;
            int speed = int.Parse(textBox_drv_speed.Text);
            _comm.Send(RczPacket.SetDriveVelocity(speed));
            trackBar_drv_speed.Value = speed;
            _sndSpeed = speed;
        }

        private void trackBar_drv_speed_Scroll(object sender, EventArgs e)
        {
            int speed = trackBar_drv_speed.Value;
            _comm.Send(RczPacket.SetDriveVelocity(speed));
            textBox_drv_speed.Text = speed.ToString();
            _sndSpeed = speed;
        }


/* parse */
        private void ParseSensorInf(RczMsg msg)
        {
            RcvSensorInf sensor;
            _comm.ParseSensorInf(msg, out sensor);
            Invoke((MethodInvoker)delegate
            {
                textBox_imu_accX.Text = sensor.acc_x.ToString("f5");
                textBox_imu_accY.Text = sensor.acc_y.ToString("f5");
                textBox_imu_accZ.Text = sensor.acc_z.ToString("f5");
                textBox_imu_gyro.Text = sensor.gyro.ToString("f5");
                textBox_drv_encoderM.Text = sensor.motor_enc.ToString("f2");
                textBox_drv_encoderFL.Text = sensor.wheel_enc1.ToString("f2");
                textBox_drv_encoderFR.Text = sensor.wheel_enc2.ToString("f2");
                textBox_drv_encoderRL.Text = sensor.wheel_enc3.ToString("f2");
                textBox_drv_encoderRR.Text = sensor.wheel_enc4.ToString("f2");
            });

        }

        private void ParsePowerInf(RczMsg msg)
        {
            RcvPowerInf power;
/*            if (_offsetCnt > 1)
                _offsetCnt -= 1;
            else if (_offsetCnt > 0)
            {
                float offset = float.Parse(textBox_pwr_current.Text);
                _comm.Send(RczPacket.SetCurrentOffset(offset));
                _offsetCnt = -1;
            }*/
            _comm.ParsePowerInf(msg, out power);
            Invoke((MethodInvoker)delegate
            {
//                textBox_pwr_current.Text = power.motor_current.ToString("f2");
                textBox_pwr_voltage.Text = power.batt_voltage.ToString("f2");
            });
        }

        private void ParseObstacleInf(RczMsg msg)
        {
            RcvObstacleInf ir;
            _comm.ParseObstacleInf(msg, out ir);
            Invoke((MethodInvoker)delegate
            {
                textBox_ir0.Text = ir.ir_obstacle[0].ToString();
                textBox_ir1.Text = ir.ir_obstacle[1].ToString();
                textBox_ir2.Text = ir.ir_obstacle[2].ToString();
                textBox_ir3.Text = ir.ir_obstacle[3].ToString();
                textBox_ir4.Text = ir.ir_obstacle[4].ToString();
                textBox_ir5.Text = ir.ir_obstacle[5].ToString();
                textBox_ir6.Text = ir.ir_obstacle[6].ToString();
                textBox_ir7.Text = ir.ir_obstacle[7].ToString();
            });
        }

        private void ParseServoInf(RczMsg msg)
        {
            RcvServoInf servo;
            _comm.ParseServoInf(msg, out servo);
            Invoke((MethodInvoker)delegate
            {
                textBox_srv_angle.Text = servo.present_position.ToString("f1");
                textBox_srv_current.Text = servo.present_current.ToString();
                textBox_srv_temp.Text = servo.present_temperature.ToString();
                textBox_srv_voltage.Text = servo.present_volts.ToString();
            });
            
        }

        private void ParseThermoInf(RczMsg msg)
        {
            RcvThermoInf thermo;
            _comm.ParseThermoInf(msg, out thermo);
            Invoke((MethodInvoker)delegate
            {
                textBox_thermo_fet1.Text = thermo.thermo_fet1.ToString("f1");
                textBox_thermo_fet2.Text = thermo.thermo_fet2.ToString("f1");
            });
        }

        /*
        private void ParseImage(RczMsg msg)
        {
        }

        private void ParseLaneResult(RczMsg msg)
        {
        }

        private void ParseStereoResultHist(RczMsg msg)
        {
        }

        private void ParseStereoResultHough(RczMsg msg)
        {
        }

        private void ParseStereoResultLabeling(RczMsg msg)
        {
        }
         */

/* steer control */
        private void button_str_on_Click(object sender, EventArgs e)
        {
            _comm.Send(RczPacket.SetSteerServo(1));
        }

        private void button_str_off_Click(object sender, EventArgs e)
        {
            _comm.Send(RczPacket.SetSteerServo(0));
        }

        private void button_str_setAngle_Click(object sender, EventArgs e)
        {
            if (textBox_str_angle.Text == "")
                return;
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox_str_angle.Text, @"([^-0123456789.])"))
                return;
            if (textBox_str_angle.Text.IndexOf("-") > 0)
                return;
            float angle = float.Parse(textBox_str_angle.Text);
            _comm.Send(RczPacket.SetSteerAngle(angle));
            trackBar_str_angle.Value = (int)angle * 10;
        }

        private void button_str_setZero_Click(object sender, EventArgs e)
        {
            _comm.Send(RczPacket.SetSteerAngle(0));
            trackBar_str_angle.Value = 0;
            textBox_str_angle.Text = "0";
        }

        private void trackBar_str_angle_Scroll(object sender, EventArgs e)
        {
            float angle = (float)trackBar_str_angle.Value / 10.0f;
            _comm.Send(RczPacket.SetSteerAngle(angle));
            textBox_str_angle.Text = angle.ToString("f1");
        }

/* steer offset */
        private void button_str_setOffset_Click(object sender, EventArgs e)
        {
            float offset = float.Parse(textBox_srv_angle.Text);
            _comm.Send(RczPacket.SetSteerOffset(offset));
        }

/* gyro offset */
        private void button_imu_setOffset_Click(object sender, EventArgs e)
        {
            float offset = float.Parse(textBox_imu_gyro.Text);
            _comm.Send(RczPacket.SetGyroOffset(offset));
        }

/* current offset */
/*        private void button_pwr_setOffset_Click(object sender, EventArgs e)
        {
//            float offset = float.Parse(textBox_pwr_current.Text);
            _comm.Send(RczPacket.SetCurrentOffset(offset));
        }*/

/* game controler */
        private void readSetting()
        {
            serializeSetting(false);

        }

        private void directXInitial()
        {
            DeviceList devList;

            devList = Manager.GetDevices(DeviceType.Driving, EnumDevicesFlags.AllDevices);

            foreach (DeviceInstance dev in devList)
            {
                _wheelCnt = new Device(dev.InstanceGuid);
                _wheelCnt.SetCooperativeLevel(this, CooperativeLevelFlags.Background | CooperativeLevelFlags.NonExclusive);
                break;
            }
            if (_wheelCnt == null)
                return;
            _wheelCnt.SetDataFormat(DeviceDataFormat.Joystick);

            _wheelCnt.Acquire();
            timer_directX.Interval = 30;
            timer_directX.Start();
        }

        private void serializeSetting(bool save)
        {
            try
            {
                string path = Application.StartupPath + @"\contSetting.xml";
                XmlSerializer serializer = new XmlSerializer(typeof(controlSetting));
                if (save)
                {
                    FileStream fs = new FileStream(path, FileMode.Create);
                    serializer.Serialize(fs, _setting);
                    fs.Close();
                }
                else
                {
                    FileStream fs = new FileStream(path, FileMode.Open);
                    _setting = (controlSetting)serializer.Deserialize(fs);
                    fs.Close();
                }
            }
            catch (Exception)
            {
                // Ignore any.
            }

        }

        private void timer_directX_Tick(object sender, EventArgs e)
        {
            if (_wheelCnt == null)
            {
                return;
            }
            try
            {
                _wheelCnt.Poll();
                JoystickState state = _wheelCnt.CurrentJoystickState;
//                int str = state.X;
//                int brk = state.Rz;
//                int acc = state.Y;
                int str = 0;
                int brk = 0;
                int acc = 0;

                switch(_setting.acc_assing){
                    case 0: acc = state.ARx; break;
                    case 1: acc = state.ARy; break;
                    case 2: acc = state.ARz; break;
                    case 3: acc = state.AX; break;
                    case 4: acc = state.AY; break;
                    case 5: acc = state.AZ; break;
                    case 6: acc = state.FRx; break;
                    case 7: acc = state.FRy; break;
                    case 8: acc = state.FRz; break;
                    case 9: acc = state.FX; break;
                    case 10: acc = state.FY; break;
                    case 11: acc = state.FZ; break;
                    case 12: acc = state.Rx; break;
                    case 13: acc = state.Ry; break;
                    case 14: acc = state.Rz; break;
                    case 15: acc = state.VRx; break;
                    case 16: acc = state.VRy; break;
                    case 17: acc = state.VRz; break;
                    case 18: acc = state.VX; break;
                    case 19: acc = state.VY; break;
                    case 20: acc = state.VZ; break;
                    case 21: acc = state.X; break;
                    case 22: acc = state.Y; break;
                    case 23: acc = state.Z; break;
                    default: acc = state.Y; break;
                }
                switch(_setting.str_assing){
                    case 0: str = state.ARx; break;
                    case 1: str = state.ARy; break;
                    case 2: str = state.ARz; break;
                    case 3: str = state.AX; break;
                    case 4: str = state.AY; break;
                    case 5: str = state.AZ; break;
                    case 6: str = state.FRx; break;
                    case 7: str = state.FRy; break;
                    case 8: str = state.FRz; break;
                    case 9: str = state.FX; break;
                    case 10: str = state.FY; break;
                    case 11: str = state.FZ; break;
                    case 12: str = state.Rx; break;
                    case 13: str = state.Ry; break;
                    case 14: str = state.Rz; break;
                    case 15: str = state.VRx; break;
                    case 16: str = state.VRy; break;
                    case 17: str = state.VRz; break;
                    case 18: str = state.VX; break;
                    case 19: str = state.VY; break;
                    case 20: str = state.VZ; break;
                    case 21: str = state.X; break;
                    case 22: str = state.Y; break;
                    case 23: str = state.Z; break;
                    default: str = state.X; break;
                }
                switch(_setting.brk_assing){
                    case 0: brk = state.ARx; break;
                    case 1: brk = state.ARy; break;
                    case 2: brk = state.ARz; break;
                    case 3: brk = state.AX; break;
                    case 4: brk = state.AY; break;
                    case 5: brk = state.AZ; break;
                    case 6: brk = state.FRx; break;
                    case 7: brk = state.FRy; break;
                    case 8: brk = state.FRz; break;
                    case 9: brk = state.FX; break;
                    case 10: brk = state.FY; break;
                    case 11: brk = state.FZ; break;
                    case 12: brk = state.Rx; break;
                    case 13: brk = state.Ry; break;
                    case 14: brk = state.Rz; break;
                    case 15: brk = state.VRx; break;
                    case 16: brk = state.VRy; break;
                    case 17: brk = state.VRz; break;
                    case 18: brk = state.VX; break;
                    case 19: brk = state.VY; break;
                    case 20: brk = state.VZ; break;
                    case 21: brk = state.X; break;
                    case 22: brk = state.Y; break;
                    case 23: brk = state.Z; break;
                    default: brk = state.Rz; break;
                }

                textBox_input_acc.Text = acc.ToString();
                textBox_input_brk.Text = brk.ToString();
                textBox_input_str.Text = str.ToString();

                string buttonStr = "";
                int count = 0;
                foreach (byte button in state.GetButtons())
                {
                    if (button != 0)
                    {
                        buttonStr += count.ToString("D2");
                        buttonStr += ", ";
                    }
                    count += 1;
                }
                textBox_input_btn.Text = buttonStr;

                int targetVeloc = 0;
                float targetStr = 0.0f;
                if(_setting.acc_min > _setting.acc_max)
                    acc = (acc- _setting.acc_min) * -1;
                else
                    acc = acc- _setting.acc_min;
                if(_setting.brk_min > _setting.brk_max)
                    brk = (brk- _setting.brk_min) * -1;
                else
                    brk = brk - _setting.brk_min;
                targetVeloc = (int)(acc / (Math.Abs(_setting.acc_max - _setting.acc_min) /2800)) - (int)(brk / (Math.Abs(_setting.brk_max - _setting.brk_min) /2800));
//                targetVeloc = (int)((((acc - 65535) * -1) - ((brk - 65535) * -1)) / 23.5);
                if (targetVeloc < 0)
                    targetVeloc = 0;
//                if (Math.Abs(str - 32767) < 250)
                if (Math.Abs(str - _setting.str_max / 2) < _setting.str_max / 200)
                    targetStr = 0.0f;
                //                else if (str < 26214)
                else if (str < _setting.str_min)
                    targetStr = -30.0f;
                //                else if (str > 39320)
                else if (str > _setting.str_max)
                    targetStr = 30.0f;
                else
                    //                    targetStr = (str - 32767) / 220.0f;
                    targetStr = (str - (_setting.str_max / 2.0f)) / ((_setting.str_max / 2) / 30.0f);

                if (_bwdFlg)
                    targetVeloc *= -1;

                if (targetVeloc > _maxVeloc)
                    targetVeloc = _maxVeloc;
                else if (targetVeloc < _maxVeloc * -1)
                    targetVeloc = _maxVeloc * -1;

                textBox_target_str.Text = targetStr.ToString("f1");
                textBox_target_veloc.Text = targetVeloc.ToString();

                if (checkBox_directX.Checked)
                {
                    _comm.Send(RczPacket.SetDriveVelocity(targetVeloc));
                    _comm.Send(RczPacket.SetSteerAngle(targetStr));
                    trackBar_drv_speed.Value = targetVeloc;
                    trackBar_str_angle.Value = (int)(targetStr*10);
                    count = 0;
                    foreach (byte button in state.GetButtons())
                    {
                        if (_setting.fwd_assing == count)
                            _bwdFlg = false;
                        else if (_setting.bwd_assing == count)
                            _bwdFlg = true;
                        else if (_setting.mtrOff_assing == count)
                        {
                            _comm.Send(RczPacket.SetSteerServo(0));
                            _comm.Send(RczPacket.SetDriveMotor(0));
                        }
                        else if (_setting.mtrOn_assing == count)
                        {
                            _comm.Send(RczPacket.SetSteerServo(1));
                            _comm.Send(RczPacket.SetDriveMotor(1));
                        }
/*                        switch (count)
                        {
                            case 9:
                                if (button != 0)
                                {
                                    _comm.Send(RczPacket.SetSteerServo(1));
                                    _comm.Send(RczPacket.SetDriveMotor(1));
                                }
                                break;
                            case 08:
                                if (button != 0)
                                {
                                    _comm.Send(RczPacket.SetSteerServo(0));
                                    _comm.Send(RczPacket.SetDriveMotor(0));
                                }
                                break;
                            case 12:
                                if (button != 0)
                                {
                                    _bwdFlg = true;
                                }
                                break;
                            case 13:
                                if (button != 0)
                                {
                                    _bwdFlg = false;
                                }
                                break;
                            default:
                                break;
                        }
 */
                        count += 1;
                    }
                }
            }
            catch (Exception) { }
        }

        private void textBox_max_veloc_TextChanged(object sender, EventArgs e)
        {
            if (textBox_max_veloc.Text == "")
                return;
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox_max_veloc.Text, @"([^-0123456789.])"))
                return;
            if (textBox_max_veloc.Text.IndexOf("-") > 0)
                return;
            _maxVeloc = int.Parse(textBox_max_veloc.Text);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            _comm.Send(RczPacket.SetDriveVelocity(_sndSpeed));
        }

	}

    public class connectConfig
    {
        public connectConfig() { }
        public string HostName { get; set; }
    }

    public class controlSetting
    {
        public controlSetting() { }
        public int str_assing { get; set; }
        public int str_min { get; set; }
        public int str_max { get; set; }
        public int acc_assing { get; set; }
        public int acc_min { get; set; }
        public int acc_max { get; set; }
        public int brk_assing { get; set; }
        public int brk_min { get; set; }
        public int brk_max { get; set; }
        public int mtrOn_assing { get; set; }
        public int mtrOff_assing { get; set; }
        public int fwd_assing { get; set; }
        public int bwd_assing { get; set; }
    }
}
